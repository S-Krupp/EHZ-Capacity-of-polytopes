import numpy as np

def run():
	inobj = open('problem1.out','r')
	
	success = False
	
	for line in inobj:
		if 'phase.value = pdOPT' in line:
			success = True
		elif 'objValDual   =' in line:
			vline = line
	
	inobj.close()
	
	if not success:
		print 'SDPA_GMP solver did not succeed.'
		return [0,False]
	else:
		sol = float(vline[15:])
		return [sol,True]
	

import pickle
import main_no_cyclic_post as mncp
import setup_acuratesol as acusol
import sys

mncp.run()

acusol.run()

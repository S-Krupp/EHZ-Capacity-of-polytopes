import numpy as np
import multiprocessing as mp
import time
import pickle
import polarvert
import ownSDP as sdp
import ownSDP_post as sdppost
import scipy.misc
import sys

# Xraw = [ [+4.557395060730e-02,+1.228766217395e-02,+2.472454206615e-02,+3.736709787570e-02,+4.511754951989e-02,+4.840975773141e-02 ],
  # [+1.228766217395e-02,+3.313007330421e-03,+6.666236445503e-03,+1.007492936100e-02,+1.216460830309e-02,+1.305225588022e-02 ],
  # [+2.472454206615e-02,+6.666236445503e-03,+1.341343217820e-02,+2.027220233060e-02,+2.447693829225e-02,+2.626300983087e-02 ],
  # [+3.736709787570e-02,+1.007492936100e-02,+2.027220233060e-02,+3.063811756122e-02,+3.699288379417e-02,+3.969224108642e-02 ],
  # [+4.511754951989e-02,+1.216460830309e-02,+2.447693829225e-02,+3.699288379417e-02,+4.466572114081e-02,+4.792495787845e-02 ],
  # [+4.840975773141e-02,+1.305225588022e-02,+2.626300983087e-02,+3.969224108642e-02,+4.792495787845e-02,+5.142202604274e-02 ]   ]


def run(Xraw):
	X = np.array(Xraw)
	
	rank = np.linalg.matrix_rank(X,tol=10**(-6))
	print '\nMore accurate upper bound for min{rank(X) : X is optimal} is ' + str(rank) + '.\n\nThe Eigenvalues are:'
	
	[w,v] = np.linalg.eig(X)
	
	for lamb in w:
		print lamb
	

import sys
import mosek

# Since the value of infinity is ignored, we define it solely
# for symbolic purposes
inf = 0.0

############################################################
######################### Input ############################
############################################################

# Solves an SDP of the form:

# min < 1/2 * I_{2n},Y >
# s.t. Y_{i,n+j} = -X_{i,j}
#      < A,X > = 0
#      < J,X > = 1
#      < B,X > = alpha
#      X >= 0
#      X,Y psd

# Bound keys for constraints
bkc = [mosek.boundkey.fx,
       mosek.boundkey.fx,
       mosek.boundkey.fx]

b0 = 0.0
b1 = 1.0
alpha = 2.0

# Bound values for constraints
blc = [b0, b1, alpha]
buc = [b0, b1, alpha]

# matrixdim is the number of columns/rows of X
matrixdim = 2

# Number of elements in the upper right triangle of X (diagonal excluded)
uptri = matrixdim*(matrixdim-1)/2

# Number of elements in X:
block = matrixdim ** 2

bkc += [mosek.boundkey.fx] * block
blc += [0.0] * block
buc += [0.0] * block

bkc += [mosek.boundkey.lo] * uptri
blc += [0.0] * uptri
buc += [+inf] * uptri

C_k = [k for k in range(2*matrixdim)]
C_l = [l for l in range(2*matrixdim)]
C_v = [0.5] * (2*matrixdim)

A0_k = []
A0_l = []
A0_v = []

B_k = []
B_l = []
B_v = []

A1_k = []
A1_l = []
A1_v = []

for k in range(matrixdim):
	for l in range(k+1):
		A1_k += [k]
		A1_l += [l]
		A1_v += [1.0]

def setup(A0k, A0l, A0v, Bk, Bl, Bv, alph, matdim):
	global bkc, blc, buc, b0, b1, C_k, C_l, C_v, A0_k, A0_l, A0_v, A1_k, A1_l, A1_v, B_k, B_l, B_v, alpha, matrixdim, uptri, block
	matrixdim = matdim
	uptri = matrixdim*(matrixdim-1)/2
	block = matrixdim ** 2
	alpha = alph
	
	bkc = [mosek.boundkey.fx, mosek.boundkey.fx, mosek.boundkey.fx]	
	blc = [b0, b1, alpha]
	buc = [b0, b1, alpha]

	bkc += [mosek.boundkey.fx] * block
	blc += [0.0] * block
	buc += [0.0] * block
	
	bkc += [mosek.boundkey.lo] * uptri
	blc += [0.0] * uptri
	buc += [+inf] * uptri
	
	C_k = [k for k in range(2*matrixdim)]
	C_l = [l for l in range(2*matrixdim)]
	C_v = [0.5] * (2*matrixdim)
	
	B_k = Bk
	B_l = Bl
	B_v = Bv
	
	A0_k = A0k
	A0_l = A0l
	A0_v = A0v
	
	A1_k = []
	A1_l = []
	A1_v = []
	
	for k in range(matrixdim):
		for l in range(k+1):
			A1_k += [k]
			A1_l += [l]
			A1_v += [1.0]

#############################################################
######################### Mosek #############################
#############################################################

# Define a stream printer to grab output from MOSEK
def streamprinter(text):
    sys.stdout.write(text)
    sys.stdout.flush()

def main():
	# Make mosek environment
	with mosek.Env() as env:

		# Create a task object and attach log stream printer
		with env.Task(0, 0) as task:
			# Set log handler for debugging ootput
			#task.set_Stream(mosek.streamtype.log, streamprinter)
	
			# Append two symmetric variables of dimension matrixdim and 2*matrixdim
			barvardims = [matrixdim, 2*matrixdim]
			task.appendbarvars(barvardims)
	
			# Semidefinite part of objective function
			task.putbarcblocktriplet(
	            len(C_v),           # Number of entries
	            [1]*len(C_v),       # Which SDP variable (j)
	            C_k,                # Entries: (k,l)->v
	            C_l,
	            C_v,
	            )
	
			# Append 3 + block + uptri many constraints
			task.appendcons(3 + block + uptri)
	
			# First constraint (<A,X> = 0)
			task.putbarablocktriplet(
	            len(A0_v),           # Number of entries
	            [0]*len(A0_v),       # Which constraint (i = 0)
	            [0]*len(A0_v),       # Which SDP variable (j)
	            A0_k,                # Entries: (k,l)->v
	            A0_l,
	            A0_v,
	            )
			
	
			# Second constraint (<J,X> = 1)
			task.putbarablocktriplet(
	            len(A1_v),           # Number of entries
	            [1]*len(A1_v),       # Which constraint (i = 0)
	            [0]*len(A1_v),       # Which SDP variable (j)
	            A1_k,                # Entries: (k,l)->v
	            A1_l,
	            A1_v,
	            )
			
			# Third constraint (<B,X> = alpha)
			task.putbarablocktriplet(
	            len(B_v),           # Number of entries
	            [2]*len(B_v),       # Which constraint (i = 0)
	            [0]*len(B_v),       # Which SDP variable (j)
	            B_k,                # Entries: (k,l)->v
	            B_l,
	            B_v,
	            )
			
			concount = 3
			# Fourth group of constraints (Y_{i,n+j} = X_{i,j})
			# Note that for i=j X_{i,j} is an diagonal element but
			# Y_{i,n+j} is not.
			for i in range(matrixdim):
				for j in range(matrixdim):
					if i != j:
						task.putbarablocktriplet(
				            2,                          # Number of entries
				            [concount]*2,               # Which constraint
				            [0,1],                      # Which SDP variable
				            [max(i,j),matrixdim + i],   # Entries: (k,l)->v
				            [min(i,j),j],
				            [1.0,1.0],
				            )
					else:
						task.putbarablocktriplet(
				            2,                          # Number of entries
				            [concount]*2,               # Which constraint
				            [0,1],                      # Which SDP variable
				            [max(i,j),matrixdim + i],   # Entries: (k,l)->v
				            [min(i,j),j],
				            [2.0,1.0],
				            )
					concount += 1
			
			# Fifth group of constraints (X_{i,j} >= 0)
			for i in range(matrixdim):
				for j in range(i):
					task.putbarablocktriplet(
			            1,                          # Number of entries
			            [concount],                 # Which constraint
			            [0],                        # Which SDP variable
			            [i],                        # Entries: (k,l)->v
			            [j],
			            [1.0],
			            )
					concount += 1

			# Set bounds for constraints
			task.putconboundlist([r for r in range(concount)], bkc, blc, buc)
	
			# Write the problem for human inspection
			#task.writedata("test.ptf")
	
			# Optimize
			task.optimize()
			#task.solutionsummary(mosek.streamtype.msg)
	
			# Get status information about the solution
			solsta = task.getsolsta(mosek.soltype.itr)
	
			if solsta == mosek.solsta.optimal:
				# Assuming the optimization succeeded read solution
				solX = []
				for i in range(2):
					dim = int(barvardims[i]*(barvardims[i]+1)/2)
					X = [0.0] * dim
					task.getbarxj(mosek.soltype.itr, i, X)
					solX += [X]
					
				primalobj = task.getprimalobj(mosek.soltype.itr)
				return [1, primalobj, solX]
	
			elif (solsta == mosek.solsta.dual_infeas_cer or
                  solsta == mosek.solsta.prim_infeas_cer or
                  solsta == mosek.solsta.near_dual_infeas_cer or
                  solsta == mosek.solsta.near_prim_infeas_cer):
				#print("Primal or dual infeasibility certificate found.\n")
				return [2,0,[]]
			elif solsta == mosek.solsta.unknown:
				#print("Unknown solution status")
				return [3,0,[]]
			else:
				#print("Other solution status")
				return [4,0,[]]

# call the main function
def run():
	try:
    		return main()
	except mosek.MosekException as e:
    		print("ERROR: %s" % str(e.errno))
    		if e.msg is not None:
        		print("\t%s" % e.msg)
        		sys.exit(1)
	except:
    		import traceback
    		traceback.print_exc()
    		sys.exit(1)

#Example for use of setup:

# tAk=[1]
# tAl=[0]
# tAv=[1.0]

# tBk = [1]
# tBl = [1]
# tBv = [1]

# tmatdim = 2

# print("Test Setup started")
# setup(tAk,tAl,tAv,tBk,tBl,tBv,1.0,tmatdim)
# print("Test Setup done!")
# print run()

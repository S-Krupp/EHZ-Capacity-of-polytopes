import numpy as np
import pickle
import time
import random
import matplotlib.pyplot as plt

#Script meant to return a random 2-dim. polytope with 0 in its interior.
#The output are the vertices, ordered such that the i-th vertex and 
#the (i-1)-th vertex are endpoints of an edge. Thus, the output can be
#inserted into volume.py in order to calculate the volume of the random
#polytope.
#How the polytope is constructed: Start with a random point cloud (standard normal distribution).
#Assign each point to a random uniformly chosen length (so that point cloud isn't too round).
#Find an edge of the convex hull. Gradually find adjacent edges of the convex hull until polytope
#is completed.
#To make sure that 0 lies in its interior, 3 convenient points are added to the cloud.

#Output: - ordered (an array of suitably ordered vertices of a random polytope)
#        - badseed (a boolean which is True iff 3 points of the cloud happen to lie on a common line; happens with prob. 0)

#store ordered vertices and remaining vertices here.
ordered = []
rest = []

badseed = False

#convenient routine. Given points 'fix' and 'potv' examine,
#whether they form an edge of the convex hull.
def routine(potv,fix,vert,overwrite = True):
	global badseed, ordered, rest
	v = potv - fix
	n0 = v[1]
	n1 = -v[0]
	orth = np.array([n0,n1])
	scale = orth.dot(potv)
	sgn = 0
	isneigh = True
	
	#Consider line through potv and fix. Check whether all points of the cloud
	#lie in the same halfspace.
	for checkv in vert:
		
		if orth.dot(checkv) < scale - 10**(-6):
			
			if sgn == 0:
				sgn = -1
				
			elif sgn == 1:
				isneigh = False
		
		elif orth.dot(checkv) > scale + 10**(-6):
			
			if sgn == 0:
				sgn = 1
				
			elif sgn == -1:
				isneigh = False
		
		else:
			#fix, potv and checkv lie on a straight line. This is a bad seed!
			if (not np.allclose(checkv,potv)) and (not np.allclose(checkv,fix)):			
				badseed = True

	#if isneigh is True: fix and potv form an edge of the convex hull.
	if isneigh:
		if overwrite:
			ordered += [potv]
			
			for i in range(len(rest)):
				if np.allclose(potv,rest[i]):
					del rest[i]
					break
		#potv is neighbor of fix
		return True
	
	#potv is not a neighbor of fix
	return False

#Main function. Call this to run the script.
def main(seed,samplesize = 10,lenrange = [1,3]):
	
	global badseed, ordered, rest
	
	#reset global variables
	ordered = []
	rest = []
	badseed = False
	
	vert = []
	
	random.seed(seed)
	#Construct random point cloud.
	for i in range(samplesize):
		v = []
		
		for j in range(2):
			v += [random.gauss(0,1)]
		
		v = np.array(v)
		
		#adjust norm
		r = random.uniform(lenrange[0],lenrange[1])
		v = v * (r/np.linalg.norm(v))
		
		vert += [v]
	
	#make sure, that 0 lies in the interior of the convex hull of the sampled points by adding three
	#vertices such that 0 is in the interior of their convex hull.
	vert += [np.array([0.,0.2]),np.array([0.2,-0.2]),np.array([-0.2,-0.2])]
	
	rest = vert[:]
	
	#Determine an edge to start:
	stop = False
	
	for i in range(len(vert)):
		
		if stop:
			break
			
		for j in range(len(vert)):
			
			if i == j:
				continue
			
			u = vert[i]
			w = vert[j]
			
			#If out = True then u,w is the first edge. Precisely: ordered[0] = start = w and ordered[1] = u
			out = routine(u,w,vert,False)
			
			if out:
				stop = True
				ordered += [w,u]
				
				if i > j:
					del rest[i]
					del rest[j]
				else:
					del rest[j]
					del rest[i]		
				
				break
	
	#fix is the last vertex (of the convex hull) which has been found. start is the very first vertex which has been found.
	fix = u
	start = w
	
	while len(rest) > 0:
		
		if badseed:
			break
		
		if len(ordered) >= 3:
			neighS = routine(start,fix,vert,False)
			
			if neighS == True:
				#successfully terminated
				#ordered contains all vertices
				break
		
		#Find the next vertex
		for potv in rest:
			neigh = routine(potv,fix,vert)
			
			if neigh:
				fix = potv
				break
	
	return [ordered,badseed]


# [res,bads] = main(1,13)

# for v in res:
	# print v
	
# print '\nBad Seed: ' + str(bads)
# print '#Vertices: ' + str(len(res))

# #Plotting:
# xval = []
# yval = []

# for v in res:
	# xval += [v[0]]
	# yval += [v[1]]

# #Close the drawing:
# xval += [res[0][0]]
# yval += [res[0][1]]

# plt.plot(xval,yval)
# plt.axis([-4,4,-4,4])
# plt.show()




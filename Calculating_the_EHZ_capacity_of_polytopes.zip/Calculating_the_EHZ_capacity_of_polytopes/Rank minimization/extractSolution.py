import numpy as np
import pickle
import polarvert
import sys


inobj = open('polarvert.txt')
vert = pickle.load(inobj)
inobj.close()

k = len(vert)


def processline(line):
	global k
	
	copyline = line[3:]
	modline = []
	
	for i in range(k):
		numstr = copyline[i*20:i*20+19]
		modline += [float(numstr)]
	
	return modline
	

def run():
	
	sol = []
	
	inobj = open('problem2.out','r')
	
	
	passyMat = False
	passbrack = False
	success = False
		
	for line in inobj:
		if 'phase.value = pdOPT' in line:
			success = True
		
		elif 'yMat = ' in line:
			passyMat = True
			
		elif passyMat and (not passbrack) and ('}   }' in line):
			passbrack = True
		
		elif passyMat and passbrack:
			
			modline = processline(line)
			
			if '}   }' in line:
				passbrack = False
				passyMat = False
					
			sol += [modline]

	inobj.close()
	
	return [sol,success]


import pickle
import random_poly as rp
import random_poly_nDim as rpn
import polarvert
import sys
import random
import numpy as np


#######################################################################
############################# INPUT ###################################
#######################################################################

seed = random.random()
dim = 2
samplesize = 10
lenrange = [1,3]

C = rpn.main(seed, dim, samplesize, lenrange)

#######################################################################
#######################################################################

dim = C.shape[1]

if dim > 2:
	vertices = polarvert.getpolvert(vertices)

		
print "Confirmation. The vertices of C are:\n"
for v in C:
	print v
		
outobj=open("vert.txt","w")
pickle.dump(C,outobj)
outobj.close()

pvert = polarvert.getpolvert(C)

outobj2=open("polarvert.txt","w")
pickle.dump(pvert,outobj2)
outobj2.close()

print '\nThe polar polytope has ' + str(len(pvert)) + ' vertices.'

	
	

import numpy as np
import extractSolution as exsol
import Calc_rank as rk

[Xraw,success] = exsol.run()

if success:

	rk.run(Xraw)

else:
	print '\n Postoptimization with SDPA_GMP failed. No upper bound has been determined.'

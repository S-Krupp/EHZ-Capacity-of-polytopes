import numpy as np
import pickle
import polarvert
import ownSDP as sdp
import sys

#######################################################################
# Given a (presumably optimal) permutation this script generates an   #
# Inputfile for sdpa_gmp in order to solve the corresponding SDP      #
# again. This will result in a more accurate solution for c_EHZ.      #
#######################################################################

def run(alpha,perm):
	inobj = open('polarvert.txt')
	vert = pickle.load(inobj)
	inobj.close()
	
	k = len(vert)
	d = len(vert[0])
	
	J = np.zeros((d,d))
	J[0:d/2, d/2:d] = np.eye(d/2)
	J[d/2:d, 0:d/2] = -np.eye(d/2)
	
	#perm = [4, 3, 2, 0, 1, 5]
	#alpha = 1.8936602500369954e-02
	
	if len(perm) != k:
		print "The length of the permutation does not match the number of vertices!"
		sys.exit(0)
	
	consNum = 3 + k*(k-1)/2 + k**2
	blockNum = 2 + k*(k-1)/2
	
	fout = open("problem2.dat-s", "w")
	
	fout.write(str(consNum) + '\n')
	fout.write(str(blockNum) + '\n')
	
	#Block structure
	fout.write(str(2*k) + " " + str(k))
	for i in range(k*(k-1)/2):
		fout.write(', ' + str(1))
	fout.write('\n')
	
	#right hand side
	fout.write('0.0, 1.0')
	for i in range(k*(k-1)/2 + k**2):
		fout.write(', 0.0')
	fout.write(', ' + str(alpha) + '\n')
	
	
	#New objective function
	for j in range(2*k):
		fout.write('0 1 ' + str(j+1) + ' ' + str(j+1) + ' -0.5\n')
	
	
	#First constraint: <D,X> = 0
	for j in range(k):
		for i in range(j,k):
			
			val = np.dot(np.array(vert[perm[i]]), np.array(vert[perm[j]]))
			
			if abs(val) > 10**(-9):
				fout.write('1 2 ' + str(j+1) + ' ' + str(i+1) + ' ' + str(val) + '\n')
	
	
	#Second constraint: <1,X> = 1
	for j in range(k):
		for i in range(j,k):		
			fout.write('2 2 ' + str(j+1) + ' ' + str(i+1) + ' 1.0\n')
	
	
	#Nonnegativity constraints:
	count = 3
	
	for j in range(k):
		for i in range(j+1,k):
			fout.write(str(count) + ' 2 ' + str(j+1) + ' ' + str(i+1) + ' 1.0\n')
			fout.write(str(count) + ' ' + str(count) + ' 1 1 -1.0\n')
			
			count += 1
	
	
	#X is a block of Y:
	for j in range(k):
		for i in range(k):
			fout.write(str(count) + ' 1 ' + str(j+1) + ' ' + str(i+k+1) + ' 1.0\n')
			fout.write(str(count) + ' 2 ' +str(min(i,j)+1) + ' ' + str(max(i,j)+1) + ' -1.0\n')
			
			count += 1
	
	
	#Last constraint: <C,X> = alpha
	for j in range(k):
		for i in range(j+1,k):
			
			val = 0.25 * np.inner(np.array(vert[perm[i]]), np.dot(J, np.array(vert[perm[j]])))
			
			if abs(val) > 10**(-9):
				fout.write(str(count) + ' 2 ' + str(j+1) + ' ' + str(i+1) + ' ' + str(val) + '\n')
	
	fout.close()	
	
	print "File has been generated. Check problem2.dat-s"
	print '\n--------------------------------------------------------------------------------\n'
	

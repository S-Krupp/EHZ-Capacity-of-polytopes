import pickle
import main_nc_po_inputOpt as inopt
import setup_rankmin as rmin
import extractOpt as opt
import sys

[alpha,success] = opt.run()

if success:

	inobj = open('permutation.txt')
	perm = pickle.load(inobj)
	inobj.close()
	
	inopt.run(alpha,perm)
	
	rmin.run(alpha,perm)

	

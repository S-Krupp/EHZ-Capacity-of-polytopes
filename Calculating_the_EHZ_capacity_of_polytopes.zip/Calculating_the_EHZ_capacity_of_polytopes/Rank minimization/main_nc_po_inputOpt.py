import numpy as np
import multiprocessing as mp
import time
import pickle
import polarvert
import ownSDP as sdp
import ownSDP_post as sdppost
import scipy.misc
import sys

# tic = time.time()

inobj = open('polarvert.txt')
vert = pickle.load(inobj)
inobj.close()

k = len(vert)
d = len(vert[0])

# maxsolve = int(scipy.misc.factorial(k-1))

J = np.zeros((d,d))
J[0:d/2, d/2:d] = np.eye(d/2)
J[d/2:d, 0:d/2] = -np.eye(d/2)

# #Preparation for multiprocessing
# solvecount = mp.Value('i', 0)

# illposed = mp.Value('b',False)
# bestval = mp.Value('d', 0.0)
# bestperm = mp.Array('i', range(k-1))
# currpermid = mp.Array('i', [0] * (k-1)) #Identify permutations. If currpermid[r] = s then for the r-th entry the s-th possible entry should be chosen.
# l = mp.Lock()
# processes = []

# procnum = 4  #Amount of processes

# #get next permutation encoded by indexset permid
# def nextpermid(permid):
	
	# copy = permid[:] #Since permid is accessed by all processes be careful not to change it prematurely
	
	# j = -1

	# for i in range(k-1):
		
		# s = k-i-2
		
		# if copy[s] < i:
			# j = s		
			# break
	
	# if j == -1:
		# return [copy, False]
	
	# copy[j] += 1
	
	# for r in range(j+1,k-1):
		# copy[r] = 0
	
	# return [copy, True]

# #decode indexset and give corresponding permutation
# def decind(permid):
	
	# viable = range(k-1)
	
	# ind = []
	
	# for i in range(k-1):
		# ind += [viable.pop(permid[i])]
	
	# return ind

#Construct matrix C in the format needed for Mosek
def getC(perm, vert):
	
	ci = []
	cj = []
	cval = []
	
	for i in range(k):
		for j in range(i):
			
			val = 0.25 * np.inner(np.array(vert[perm[i]]), np.dot(J, np.array(vert[perm[j]])))
			
			if abs(val) > 10**(-9):
				ci += [i]
				cj += [j]
				cval += [val]
	
	return [ci,cj,cval]

#Return input that models the 2 constraints in format needed for Mosek.
def constraints(perm, vert):
	
	con1i = []
	con1j = []
	con1val = []
	con2i = []
	con2j = []
	con2val = []
	
	for i in range(k):
		for j in range(i+1):
			
			val = np.dot(np.array(vert[perm[i]]), np.array(vert[perm[j]]))
			
			if abs(val) > 10**(-9):
				con1i += [i]
				con1j += [j]
				con1val += [val]
			
			con2i += [i]
			con2j += [j]
			con2val += [1.0]
	
	ai = [con1i, con2i]
	aj = [con1j, con2j]
	aval = [con1val, con2val]

	return [ai,aj,aval]

#Similar to constraints(). Generates the missing constraints for
#post-optimization.
def postconst(perm, vert):
	Ak = []
	Al = []
	Av = []
	
	for i in range(k):
		for j in range(i+1):
			
			val = np.dot(np.array(vert[perm[i]]), np.array(vert[perm[j]]))
			
			if abs(val) > 10**(-9):
				Ak += [i]
				Al += [j]
				Av += [val]
	
	[Bk,Bl,Bv] = getC(perm,vert)
	
	return [Ak, Al, Av, Bk, Bl, Bv]


#Convert Matrix in upper triangular vector form in full form
def vectomat(xvec,dim):
	X = np.zeros((dim,dim))
	pointer = 0
	
	for i in range(dim):
		for j in range(i,dim):
			
			X[i,j] = xvec[pointer]
			if i != j:
				X[j,i] = xvec[pointer]
				
			pointer += 1
			
	return X

# #parallel procedure
# def doparallel(vert):
	
	# #Initialize: make sure first update is skipped (optval < 0).
	# optval = -1
	# perm = []
	# statcode = 0
	
	# while True:
			
		# #deliver last solution and get new permutation
		# l.acquire()
		# if statcode == 1 and optval > bestval.value + 10**(-9):
			# bestval.value = optval
			# bestperm[:] = perm
		
		# if statcode == 3 or statcode == 4:
			# #problem is ill-posed
			# illposed.value = True
		
		# [permid, succ] = nextpermid(currpermid[:])
		# currpermid[:] = permid
		# if succ:
			# solvecount.value += 1
			# print 'Progress: ' + str(solvecount.value) + ' / ' + str(maxsolve)
		# l.release()
		
		# #current permutation is last one? Quit process.
		# if not succ:
			# break
		
		# perm = decind(permid)
		# longperm = perm + [k-1]
	
		# [barci,barcj,barcval] = getC(longperm,vert)
		
		# [barai,baraj,baraval] = constraints(longperm, vert)
		
		# sdp.setup(0.0, 1.0, barai, baraj, baraval, barci, barcj, barcval, k)
		# [statcode, optval, optmat] = sdp.run()	
		# #barX may be too big to return. Rather memorize the permutation used
			

# #special case: first process
# def doparallelfirst(vert):
	# perm = decind([0] * (k-1))
	# longperm = perm + [k-1]
	
	# [barci,barcj,barcval] = getC(longperm,vert)
	# [barai,baraj,baraval] = constraints(longperm, vert)
	
	# sdp.setup(0.0, 1.0, barai, baraj, baraval, barci, barcj, barcval, k)
	# [statcode, optval, optmat] = sdp.run()
	
	# l.acquire()
	# if statcode == 1 and optval > bestval.value + 10**(-9):
		# bestval.value = optval
		# bestperm[:] = perm
	
	# if statcode == 3 or statcode == 4:
		# illposed.value = True
		
	# solvecount.value += 1
	# print 'Progress: ' + str(solvecount.value) + ' / ' + str(maxsolve)
	# l.release()
	
	# #After treating first Problem, become a normal process.
	# doparallel(vert)

# #Start processes:
# #First process is special. It has to solve the first problem (before getting new permutation)
# p=mp.Process(target=doparallelfirst,args=(vert,))
# processes.append(p)
# p.start()
	
# for i in range(1,procnum):	
	# p=mp.Process(target=doparallel,args=(vert,))
	# processes.append(p)
	# p.start()
		
# #Wait for all processes to finish
# for q in processes:
	# q.join()

# toc = time.time() - tic

# print 'Terminated after ' + str(round(toc,2)) + ' seconds.'
# print 'Best permutation: ' + str(bestperm[:] + [k-1])
# print 'Value: ' + str(bestval.value)

# if illposed.value:
	# print '\n\n ###############'
	# print ' #  ATTENTION  #'
	# print ' ###############'
	# print 'The problem is ill-posed. The determined value may not be an upper bound!\nConsider slight alteration of the vertices (reduce decimals). This may solve this issue.' 


#Postoptimization:

def run(alpha,bestperm):
	#alpha = 1.8936602500369954e-02
	
	[Ak, Al, Av, Bk, Bl, Bv] = postconst(bestperm, vert)
	sdppost.setup(Ak,Al,Av,Bk,Bl,Bv,alpha,k)
	
	[code,val,sol] = sdppost.run()
	
	if code != 1:
		print "\nPostoptimization failed. Statcode is " + str(code)
	
	else:
		xvec = sol[0]
		X = vectomat(xvec,k)
		print '\nHeuristic for minimal rank solution:\n'
		for line in X:
			print line
		rank = np.linalg.matrix_rank(X,tol=10**(-6))
		print '\nUpper bound for min{rank(X) : X is optimal} is ' + str(rank)
	
	print '\n--------------------------------------------------------------------------------'
	print 'Postoptimization with acurate optimal value has concluded.'
	print '--------------------------------------------------------------------------------\n'

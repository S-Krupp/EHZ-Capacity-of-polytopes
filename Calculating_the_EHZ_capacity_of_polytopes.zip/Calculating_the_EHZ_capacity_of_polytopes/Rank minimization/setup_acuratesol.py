import numpy as np
import pickle
import polarvert
import ownSDP as sdp
import sys

#######################################################################
# Given a (presumably optimal) permutation this script generates an   #
# Inputfile for sdpa_gmp in order to solve the corresponding SDP      #
# again. This will result in a more accurate solution for c_EHZ.      #
#######################################################################

def run():
	inobj = open('polarvert.txt')
	vert = pickle.load(inobj)
	inobj.close()
	
	k = len(vert)
	d = len(vert[0])
	
	J = np.zeros((d,d))
	J[0:d/2, d/2:d] = np.eye(d/2)
	J[d/2:d, 0:d/2] = -np.eye(d/2)
	
	
	inobj2 = open('permutation.txt')
	perm = pickle.load(inobj2)
	inobj2.close()
	#perm = [4, 3, 2, 0, 1, 5]
	
	if len(perm) != k:
		print "The length of the permutation does not match the number of vertices!"
		return
	
	consNum = 2 + k*(k-1)/2
	blockNum = 1 + k*(k-1)/2
	
	fout = open("problem1.dat-s", "w")
	
	fout.write(str(consNum) + '\n')
	fout.write(str(blockNum) + '\n')
	
	#Block structure
	fout.write(str(k))
	for i in range(k*(k-1)/2):
		fout.write(', ' + str(1))
	fout.write('\n')
	
	#right hand side
	fout.write('0.0, 1.0')
	for i in range(k*(k-1)/2):
		fout.write(', 0.0')
	fout.write('\n')
	
	#objective function
	for j in range(k):
		for i in range(j+1,k):
			
			val = 0.25 * np.inner(np.array(vert[perm[i]]), np.dot(J, np.array(vert[perm[j]])))
			
			if abs(val) > 10**(-9):
				fout.write('0 1 ' + str(j+1) + ' ' + str(i+1) + ' ' + str(val) + '\n')
	
	
	#First constraint: <D,X> = 0
	for j in range(k):
		for i in range(j,k):
			
			val = np.dot(np.array(vert[perm[i]]), np.array(vert[perm[j]]))
			
			if abs(val) > 10**(-9):
				fout.write('1 1 ' + str(j+1) + ' ' + str(i+1) + ' ' + str(val) + '\n')
	
	
	#Second constraint: <1,X> = 1
	for j in range(k):
		for i in range(j,k):		
			fout.write('2 1 ' + str(j+1) + ' ' + str(i+1) + ' 1.0\n')
	
	
	#Nonnegativity constraints:
	count = 3
	
	for j in range(k):
		for i in range(j+1,k):
			fout.write(str(count) + ' 1 ' + str(j+1) + ' ' + str(i+1) + ' 1.0\n')
			fout.write(str(count) + ' ' + str(count-1) + ' 1 1 -1.0\n')
			
			count += 1
	
	fout.close()		
	
	print "File for SDPA_GMP has been generated. Check problem1.dat-s"
	print '\n--------------------------------------------------------------------------------\n'


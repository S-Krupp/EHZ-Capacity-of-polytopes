import numpy as np
import pickle
import time
import random
from scipy import special

#Script meant to return a random n-dim. polytope.
#How the polytope is constructed: Start with a random point cloud (standard normal distribution).
#Assign each point to a random uniformly chosen length (so that point cloud isn't too round).
#Find all facets of the convex hull

#Output: - vertices (vertices of the convex hull)

#Given an index set (i.e. a set consisting of n distinct numbers from range(n))
#find its successor. These sets are ordered as follows:
#(0,1,...,k-2,k-1), (0,1,...,k-2,k), ..., (0,1,...,k-2,n-1), (0,1,...,k-3,k-1,k), ..., (n-k,...,n-1)
#Return value is True iff there is a successor. The predecessor is overwritten
def nextkSubset(subset, k, n):
	copy = subset[:]
	i = k-1
	while True:
		if i == k-1 and subset[i] == n-1:
			i -= 1
		elif i < k-1 and subset[i] == subset[i+1]-1:
			i -= 1
		else:
			j = i
			break
	if i < 0:
		return [copy,False]
		
	copy[j] += 1
	for r in range(j+1,k):
		copy[r] = copy[r-1] + 1
		
	return [copy,True]

# HOW TO USE nextkSubset:
#
# x = [range(3),True]
# while x[1]:
#	print x[0]
#	x = nextkSubset(x[0],3,5)


#Given a list of lists (collection) a list of numbers (subset), check
#whether subset is contained in any list in collection
def subsetIn(collection,subset):
	for l in collection:
		if set(subset).issubset(set(l)):
			return True
	return False
	

#Returns the k-th canonic unit vector in R^n.
def dirac(n, k):
	e = np.zeros(n)
	e[k] = 1
	return e


#Get all facets of a polytope T.
def getvertices(points):
	[vnum,d] = np.shape(points)
	setdata = [[x for x in range(d)],True]
	facetData = [] #collection of indices of points which form a facet
	pointData = [0] * vnum #Counts how often each point appears in facets.
	
	while setdata[1]:
		subset = setdata[0]
		#Skip an iteration if subset leads to a facet which has already been found
		if subsetIn(facetData,subset):
			setdata = nextkSubset(subset,d,vnum)
			continue
		
		#Choose reference point.
		w = points[subset[0]]
		
		#Define system of equations such that the solution is a normal vector of the facet
		V = np.zeros((d,d))
		b = np.zeros(d)
		
		count = 0
		for j in range(1,d):
			V[count] = points[subset[j]] - points[subset[0]]
			count += 1
		
		#The last row ensures that the solution is nonzero
		V[d-1] = dirac(d,0)
		r = 0
		
		stop = False
		while np.linalg.matrix_rank(V,10**(-9)) < d:
			
			if r == d-1:
				#The indicated points are not affinely independent.
				stop = True
				break
				
			r += 1
			V[d-1] = dirac(d,r)
		
		if stop:
			setdata = nextkSubset(subset,d,vnum)
			continue
		
		b[d-1] = 1
		
		#Solve system
		n = np.linalg.solve(V,b)
		
		#Check whether we found a facet. We don't need to check the indices in subset.
		h = n.dot(points[subset[0]])
		checkNum = 0
		failed = False
		newfacet = subset[:]
		
		for l in [index for index in range(vnum) if index not in subset]:
			temp = n.dot(points[l])
			if temp < h - 10**(-9):
				if checkNum == 0:
					checkNum = 1
				elif checkNum == -1:
					#No facet
					failed = True
					setdata = nextkSubset(subset,d,vnum)
					break
			
			elif temp > h + 10**(-9):
				if checkNum == 0:
					checkNum = -1
				elif checkNum == 1:
					#No facet
					failed = True
					setdata = nextkSubset(subset,d,vnum)
					break
			
			else:
				newfacet += [l]
		
		if not failed:
			#Facet found.
			facetData += [newfacet]
			for i in newfacet:
				pointData[i] += 1
						
		setdata = nextkSubset(subset,d,vnum)
	
	vertices = []
	for h in range(vnum):
		if pointData[h] >= 2:
			vertices += [points[h]]
			
	return np.array(vertices)
	

#Main function. Call this to run the script.
def main(seed, dim, samplesize = 10, lenrange = [1,3]):
	
	if samplesize <= dim:
		print('Either samplesize too small or dim too large. Please adjust input.')
		return []
	random.seed(seed)
	#Construct random point cloud.
	points = []
	for i in range(samplesize):
		v = []
		
		for j in range(dim):
			v += [random.gauss(0,1)]
		
		v = np.array(v)
		
		#adjust norm
		r = random.uniform(lenrange[0],lenrange[1])
		v = v * (r/np.linalg.norm(v))
		
		points += [v]
	
	#Get the vertices of the convex hull
	vertices = getvertices(np.array(points))
	
	#Check that the convex hull has full dimension:
	(m, n) = vertices.shape
	V = np.ones((n+1,m))
	V[:n,:] = np.transpose(vertices)
	if np.linalg.matrix_rank(V,10**(-9)) <= n:
		print('Convex hull is not full-dimensional. Pleasy try again with a different seed.')
		return[]
	
	#Move convex hull such that it contains the origin in its interior
	mid = np.zeros((n,))
	for u in vertices:
		mid += u
	
	mid *= 1./m
	
	for u in vertices:
		u -= mid
		
	return vertices

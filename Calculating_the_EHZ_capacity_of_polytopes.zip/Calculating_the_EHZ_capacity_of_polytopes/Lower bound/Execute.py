import random_poly_nDim as rp
import lowerBound as lb
import random
import sys
import polarvert as pv

#######################################################################
############################# INPUT ###################################
#######################################################################

seed = 107
samplesize = 6
dim = 2
lenrange = [1,3]
C = rp.main(seed, dim, samplesize, lenrange)

permutation = [3, 2, 0, 1, 4]

randomStart = False

#######################################################################
#######################################################################

dim = C.shape[1]

if dim % 2 == 1:
	print('The dimension of the polytope has to be even!')
	sys.exit(0)

if dim > 2:
	C = pv.getpolvert(C)

lb.main(C,permutation,True,randomStart)

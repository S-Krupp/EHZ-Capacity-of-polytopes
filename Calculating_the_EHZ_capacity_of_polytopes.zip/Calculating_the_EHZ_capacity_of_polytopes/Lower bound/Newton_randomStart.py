import numpy as np
from scipy.optimize import Bounds
from scipy.optimize import LinearConstraint
from scipy.optimize import minimize
from scipy.optimize import linprog
import sys



def isnonneg(arr):
	for x in arr:
		if x < -10**(-9):
			return False
	return True


#Check whether Ax = b holds.
def issolution(A,b,x):
	if np.linalg.norm(A.dot(x) - b) < 10**(-9):
		return True
	else:
		return False


#This script applies the "Trust-Region Constrained Algorithm" to
#find a lower bound of
#
#             max  f(x)
#             s.t. Ax =  b
#                   x >= 0
#
#der_f is the gradient of f and hess_f is the Hessian matrix of f.

def main(f, der_f, hess_f, A, b):
	
	#convert maximization to minimization
	def maxf(x):
		return -f(x)
	
	def der_maxf(x):
		der = der_f(x)
		return [-ele for ele in der]
	
	def hess_maxf(x):
		hess = hess_f(x)
		return [[-ele for ele in hess[j]] for j in range(len(hess))]
	
	
	k = len(A[0])
	dplus = len(A)
	bounds = Bounds([0.0] * k, [np.inf] * k)
	linear_constraint = LinearConstraint(A, b, b)
	
	#Find a starting point. Start with a random point (uniformly distributed)
	for counter in range(100000):
		x0 = np.random.uniform(size = k)
		
		#Project the random point onto the linear space {x:Ax=b}
		#First step:
		a0 = np.array(A[0])
		b0 = np.array(b[0])
		fac = (b0 - a0.dot(x0))/a0.dot(a0)
		x0 += fac * a0
		
		#Remaining steps:
		for j in range(1,dplus):
			Ared = np.array(A[:j])
			rightSide = np.zeros(j)
			rightSide[j-1] = 1.0
			u = np.linalg.lstsq(Ared,rightSide,rcond=None)[0]
			if not issolution(Ared,rightSide,u):
				#Nothing to do in this iteration.
				continue
			else:
				bj = np.array(b[j])
				aj = np.array(A[j])
				x0 += (bj - aj.dot(x0)) * u
		
		if isnonneg(x0):
			#print(counter)
			break
	
	if not isnonneg(x0):
		print("Error! Couldn't find feasible start for optimization. Please try again or try other algorithm.")
		return [0.0,0.0]
	
	res = minimize(maxf, x0, method='trust-constr', jac=der_maxf, hess=hess_maxf, constraints=[linear_constraint], bounds=bounds)
	
	return [res.x, -res.fun]


#Testing:
#def f(x):
	#summe = 0
	#for i in range(6):
		#summe += x[i]**2.0
	#return summe

#def der_f(x):
	#return [2.0*x[i] for i in range(6)]

#def hess_f(x):
	#H = [[0.0]*6]*6
	#for i in range(6):
		#H[i][i] = 2.0
	#return H

#A = [[1.,0.,0.,-1.,0.,0.],[0.,1.,0.,0.,-1.,0.],[0.,0.,1.,0.,0.,-1.],[1.,1.,1.,1.,1.,1.]]
#b=[0.,0.,0.,1.]


#print(main(f, der_f, hess_f, A, b))
	

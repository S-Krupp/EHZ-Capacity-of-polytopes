import numpy as np
from scipy.optimize import Bounds
from scipy.optimize import LinearConstraint
from scipy.optimize import minimize
from scipy.optimize import linprog



#get next subset of {0,...,m-1} = range(m) of size n
def nextset(arr,n,m):
	copy = arr[:]
	j = -1
	for i in range(n):
		if arr[n-i-1] < m-i-1:
			j = n-i-1
			break
	if j < 0:
		return [False,copy]
	else:
		copy[j] += 1
		for l in range(j+1,n):
			copy[l] = copy[l-1] + 1
		return [True,copy]

def isnonneg(arr):
	for x in arr:
		if x < -10**(-9):
			return False
	return True

#How to use:
#a = [True,[z for z in range(3)]]
#while a[0]:
#	print(a[1])
#	a = nextset(a[1],3,5)


#This script applies the "Trust-Region Constrained Algorithm" to
#find a lower bound of
#
#             max  f(x)
#             s.t. Ax =  b
#                   x >= 0
#
#der_f is the gradient of f and hess_f is the Hessian matrix of f.

def main(f, der_f, hess_f, A, b):
	
	#convert maximization to minimization
	def maxf(x):
		return -f(x)
	
	def der_maxf(x):
		der = der_f(x)
		return [-ele for ele in der]
	
	def hess_maxf(x):
		hess = hess_f(x)
		return [[-ele for ele in hess[j]] for j in range(len(hess))]
	
	
	k = len(A[0])
	dplus = len(A)
	bounds = Bounds([0.0] * k, [np.inf] * k)
	linear_constraint = LinearConstraint(A, b, b)
	
	#Find a starting point by solving the LP
	#
	#            max c^T x
	#                Ax = b
	#                x >= 0
	#
	#for a random vector c.
	
	#subData = [True, [y for y in range(dplus)]]
	#B = np.zeros((dplus,dplus + 1))
	#C = np.zeros((dplus,dplus + 1))
	#for i in range(dplus):
		#C[i,i] = -1
		#C[i,dplus] = 1
	#c = np.zeros(dplus + 1)
	#c[dplus] = -1
	
	#while subData[0]:
		#for i in range(dplus):
			#B[:,i] = [A[j][subData[1][i]] for j in range(dplus)]
		
		#res = linprog(c,C,np.zeros(dplus),B,np.array(b))
		
		#if isnonneg(res.x):
			#x0 = [0.0] * k
			#for ind in range(dplus):
				#x0[subData[1][ind]] = res.x[ind]
			#break
		
		#subData = nextset(subData[1],dplus,k)
	
	c = np.random.normal(size = k)
	
	initres = linprog(c, A_eq = np.array(A), b_eq = np.array(b), bounds = (0,None))
	
	x0 = initres.x
	
	res = minimize(maxf, x0, method='trust-constr', jac=der_maxf, hess=hess_maxf, constraints=[linear_constraint], bounds=bounds)
	
	return [res.x, -res.fun]

#Testing:
#def f(x):
	#summe = 0
	#for i in range(6):
		#summe += x[i]**2.0
	#return summe

#def der_f(x):
	#return [2.0*x[i] for i in range(6)]

#def hess_f(x):
	#H = [[0.0]*6]*6
	#for i in range(6):
		#H[i][i] = 2.0
	#return H

#A = [[1.,0.,0.,-1.,0.,0.],[0.,1.,0.,0.,-1.,0.],[0.,0.,1.,0.,0.,-1.],[1.,1.,1.,1.,1.,1.]]
#b=[0.,0.,0.,1.]


#print(main(f, der_f, hess_f, A, b))
	

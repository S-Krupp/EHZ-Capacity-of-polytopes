import numpy as np
import Newton_randomStart as nm1
import NewtonMethod as nm2
import polarvert as pv
import sys
import pickle
import time


def permute(indices,V,k,d):
	copy = np.copy(V)
	new = np.zeros((k,d))
	for i in range(k):
		new[i] = copy[indices[i]]
	return new


def main(vert,myperm,verbose = True, randomStart = True):
	
	#Find vertices of the polar set
	V = np.array(pv.getpolvert(vert))
	
	tic = time.time()
	
	(k, d) = V.shape
	
	if not k == len(myperm):
		sys.exit('The permutation has wrong length.')
	
	V = permute(myperm,V,k,d)
	
	val = -1 #default value
	
	if d % 2 == 1:
		print('Input has odd dimension. Even dimension is required!')
	
	else:
		d2 = int(d/2)
		#Define symplectic matrix J
		J = np.zeros((d,d))
		J[d2:,:d2] = -np.eye(d2)
		J[:d2,d2:] = np.eye(d2)
		
		#Define (half of) standard symplectic form (omega_0 = u^T*J*w)
		def simpform(u,w):
			return 0.5 * u.dot(J.dot(w))
		
		#Define objective function, its gradient and its Hessian.
		def f(y):
			summ = 0.
			for j in range(k):
				for h in range(j):
					summ += y[h] * y[j] * simpform(V[j],V[h])
			return summ
	
		def der_f(y):
			der = [0.]*k
			for i in range(k):
				summ = 0.
				for j in range(k):
					if j == i:
						continue
					M = max(i,j)
					m = min(i,j)
					summ += y[j] * simpform(V[M],V[m])
				der[i] = summ
			return der
		
		def hess_f(y):
			hes = [[0.]*k]*k
			for i in range(k):
				for j in range(k):
					if i==j:
						continue
					M = max(i,j)
					m = min(i,j)
					hes[i][j] = simpform(V[M],V[m])
			return hes
		
		
		#Linear constraint:
		A = (np.transpose(V)).tolist() + ([[1.] * k])
		b = [0.] * d + [1.]
		
		
		#apply Newton method.
		if randomStart:
			[sol, val] = nm1.main(f, der_f, hess_f, A, b)
		else:
			[sol, val] = nm2.main(f, der_f, hess_f, A, b)
		
		toc = time.time() - tic
		
		if verbose:
			print('The algorithm found the following optimal solution for the given permutation:\n')
			print(sol)
			print('\nThe corresponding objective value yields the following lower bound:')
			print('\n1/4c(C) >= ' + str(val))
			print('\n\nThe running time is ' + str(toc) + ' seconds')
		
	return val
	

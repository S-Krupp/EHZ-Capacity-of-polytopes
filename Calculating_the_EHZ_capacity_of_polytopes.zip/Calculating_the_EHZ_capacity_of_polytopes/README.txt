
This folder contains the implementations of the algorithms that are
investigated in the thesis "Calculating the EHZ capacity of polytopes".


You can find the following subfolders:


Euclidean billiards:  Contains the implementation of Algorithm 1 (see Chapter 4.3.1).
                      Please read the file Manual.txt in this subfolder for further
                      instructions.


Minkowski billiards 4 dim:  Contains the implementation of Algorithm 2 and 3 (see Chapter 4.3.3).
                            Please read the file Manual.txt in this subfolder for further
                            instructions.


Minkowski billiards 2n dim:  Contains the implementation of the Algorithm that is outlined in
                             Chapter 4.3.4. Please read the file Manual.txt in this subfolder
                             for further instructions.


QAP bound:  Contains the implementation of the upper bound via QAP techniques from
            Chapter 5.2. Please read the file Manual.txt in this subfolder
            for further instructions.
                             

Sulti SDP bound:  Contains the implementation of the upper bound that we get from CP techniques
                  and by solving an SDP (see Chapter 5.3.1). Please read the file Manual.txt in
                  this subfolder for further instructions.


Multi SDP bound:  Contains the implementation of the upper bound that we get by solving (k-1)! SDPs
                  (see Chapter 5.3.2). Please read the file Manual.txt in this subfolder for further
                  instructions.


Lower bound:  Contains the implementation of the lower bound from Chapter 5.4. Please read the file
              Manual.txt in this subfolder for further instructions.


Rank minimization:  Contains the same algorithm as the subfolder "Multi SDP bound" but additionally
                    contains the algorithm that uses rank minimization techniques to possibly yield
                    a proof that the corresponding upper bound is equal to the exact value (see
                    Chapter 5.3.3).

                    This algorithm requires SDPA-GMP which you can download from the following website:
                                
                             http://sdpa.sourceforge.net/

                    There you can download the folder sdpa-gmp-x.y.z.src.<date>.tar.gz, where x.y.z. is
                    the recent version of SDPA-GMP and <date> is the release date. We use the version
                    that comes in the folder

                             sdpa-gmp-7.1.3.src.20150320.tar.gz

                    After downloading this folder, decompress it and add the contents of the folder 
                    "Rank minimization". Note that both folders contain the file "param.sdpa". Make sure
                    that you overwrite this file while adding the contents of the folder 
                    "Rank minimization".

                    To run this algorithm for a random example, open a terminal, navigate to the
                    folder sdpa-gmp-7.1.3 (depending on the SDPA-GMP version you downloaded) and type:
                              ./autorun
                     
                    This algorithm requires a polytope C as input. To make an input, open vertices.py.
                    You can insert C by replacing the following five lines:


                    seed = random.random()
                    samplesize = 10
                    dim = 2
                    lenrange = [1,3]
                    C = rpn.main(seed, dim, samplesize, lenrange)


                    A viable input is a Numpy array that contains the vertices of your polytope.
                    For instance, if you would like to run the algorithm for the unit cube in
                    dimension 2, replace the above five lines with:


                    C = numpy.array([[ 1.0, 1.0],
                                     [ 1.0,-1.0],
                                     [-1.0, 1.0],
                                     [-1.0,-1.0]])


                    If the input polytope has dimension > 2, then the algorithm assumes that the
                    input is the polar polytope C^0 instead.

                    Then execute the file vertices.py to confirm your input. Afterwards, you can run
                    the algorithm with the command:   ./autorun


                    To reproduce the examples in the thesis please insert the desired values for the
                    variables seed, samplesize, lenrange and dim from the following table into vertices.py.




                           No. |   seed  |  samplesize  |    lenrange    |   dim
                         -----------------------------------------------------------
                            1  |   101   |       3      |      [1, 3]    |    2
                            2  |   102   |       3      |      [1, 3]    |    2
                            3  |   103   |       5      |      [1, 3]    |    2
                            4  |   104   |       4      |      [1, 3]    |    2
                            5  |   106   |       5      |      [1, 3]    |    2
                            6  |   107   |       6      |      [1, 3]    |    2
                            7  |   112   |       9      |      [1, 3]    |    2
                            8  |   113   |       9      |      [1, 3]    |    2
                            9  |   115   |       9      |      [1, 3]    |    2
                           10  |   117   |      15      |      [1, 3]    |    2
                           11  |   118   |      45      |      [1, 3]    |    2
                           12  |   119   |      18      |      [1, 3]    |    2
                           13  |   131   |      32      |      [1, 3]    |    2
                           14  |   132   |      24      |      [1, 3]    |    2
                           15  |   134   |      25      |      [1, 3]    |    2
                           16  |   135   |      35      |      [1, 3]    |    2
                           17  |   136   |      35      |      [1, 3]    |    2
                           18  |   137   |      67      |      [1, 3]    |    2
                           19  |   200   |       5      |      [1, 3]    |    4
                           20  |   201   |       5      |      [1, 3]    |    4
                           21  |   201   |       6      |      [1, 3]    |    4
                           22  |   203   |       6      |      [1, 3]    |    4
                           23  |   204   |       7      |      [1, 3]    |    4
                           24  |   205   |       7      |      [1, 3]    |    4
                           25  |   206   |       8      |      [1, 3]    |    4
                           26  |   207   |       8      |      [1, 3]    |    4
                           27  |   208   |       9      |      [1, 3]    |    4
                           28  |   209   |      10      |      [1, 3]    |    4
                           29  |   210   |      10      |      [1, 3]    |    4
                           30  |   211   |      11      |      [1, 3]    |    4
                           31  |   212   |      13      |      [1, 3]    |    4
                           32  |   213   |      12      |      [1, 3]    |    4
                           33  |   300   |       7      |      [1, 3]    |    6
                           34  |   301   |       7      |      [1, 3]    |    6
                           35  |   302   |       8      |      [1, 3]    |    6
                           36  |   303   |       8      |      [1, 3]    |    6
                           37  |   304   |       9      |      [1, 3]    |    6
                           38  |   305   |       9      |      [1, 3]    |    6
                           39  |   306   |      10      |      [1, 3]    |    6
                           40  |   307   |      10      |      [1, 3]    |    6


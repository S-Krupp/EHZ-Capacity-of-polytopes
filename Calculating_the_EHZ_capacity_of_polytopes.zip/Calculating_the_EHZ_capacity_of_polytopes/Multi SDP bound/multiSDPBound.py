import numpy as np
import multiprocessing as mp
import time
import pickle
import polarvert
import ownSDP as sdp
import scipy.misc


def getJ(d):
	J = np.zeros((d,d))
	J[0:d/2, d/2:d] = np.eye(d/2)
	J[d/2:d, 0:d/2] = -np.eye(d/2)
	return J

#get next permutation encoded by indexset permid
def nextpermid(permid,k):
	
	copy = permid[:] #Since permid is accessed by all processes be careful not to change it prematurely
	
	j = -1

	for i in range(k-1):
		
		s = k-i-2
		
		if copy[s] < i:
			j = s		
			break
	
	if j == -1:
		return [copy, False]
	
	copy[j] += 1
	
	for r in range(j+1,k-1):
		copy[r] = 0
	
	return [copy, True]

#decode indexset and give corresponding permutation
def decind(permid,k):
	
	viable = range(k-1)
	
	ind = []
	
	for i in range(k-1):
		ind += [viable.pop(permid[i])]
	
	return ind

#Construct matrix C in the format needed for Mosek
def getC(perm, vert):
	
	k = len(vert)
	d = len(vert[0])
	J = getJ(d)
	
	ci = []
	cj = []
	cval = []
	
	for i in range(k):
		for j in range(i):
			
			val = 0.25 * np.inner(np.array(vert[perm[i]]), np.dot(J, np.array(vert[perm[j]])))
			
			if abs(val) > 10**(-9):
				ci += [i]
				cj += [j]
				cval += [val]
	
	return [ci,cj,cval]

#Return input that models the 2 constraints in format needed for Mosek.
def constraints(perm, vert):
	
	k = len(vert)
	
	con1i = []
	con1j = []
	con1val = []
	con2i = []
	con2j = []
	con2val = []
	
	for i in range(k):
		for j in range(i+1):
			
			val = np.dot(np.array(vert[perm[i]]), np.array(vert[perm[j]]))
			
			if abs(val) > 10**(-9):
				con1i += [i]
				con1j += [j]
				con1val += [val]
			
			con2i += [i]
			con2j += [j]
			con2val += [1.0]
	
	ai = [con1i, con2i]
	aj = [con1j, con2j]
	aval = [con1val, con2val]

	return [ai,aj,aval]

#parallel procedure
def doparallel(vert,verbose,k,d,maxsolve,solvecount,illposed,bestval,bestperm,currpermid,l):
	
	#Initialize: make sure first update is skipped (optval < 0).
	optval = -1
	perm = []
	statcode = 0
	
	while True:
			
		#deliver last solution and get new permutation
		l.acquire()
		if statcode == 1 and optval > bestval.value + 10**(-9):
			bestval.value = optval
			bestperm[:] = perm
		
		if statcode == 3 or statcode == 4:
			#problem is ill-posed
			illposed.value = True
		
		[permid, succ] = nextpermid(currpermid[:],k)
		currpermid[:] = permid
		if succ:
			solvecount.value += 1
			if verbose:
				print 'Progress: ' + str(solvecount.value) + ' / ' + str(maxsolve)
		l.release()
		
		#current permutation is last one? Quit process.
		if not succ:
			break
		
		perm = decind(permid,k)
		longperm = perm + [k-1]
	
		[barci,barcj,barcval] = getC(longperm,vert)
		
		[barai,baraj,baraval] = constraints(longperm, vert)
		
		sdp.setup(0.0, 1.0, barai, baraj, baraval, barci, barcj, barcval, k)
		[statcode, optval, optmat] = sdp.run()	
		#barX may be too big to return. Rather memorize the permutation used
			

#special case: first process
def doparallelfirst(vert,verbose,k,d,maxsolve,solvecount,illposed,bestval,bestperm,currpermid,l):
	perm = decind([0] * (k-1),k)
	longperm = perm + [k-1]
	
	[barci,barcj,barcval] = getC(longperm,vert)
	[barai,baraj,baraval] = constraints(longperm, vert)
	
	sdp.setup(0.0, 1.0, barai, baraj, baraval, barci, barcj, barcval, k)
	[statcode, optval, optmat] = sdp.run()
	
	l.acquire()
	if statcode == 1 and optval > bestval.value + 10**(-9):
		bestval.value = optval
		bestperm[:] = perm
	
	if statcode == 3 or statcode == 4:
		illposed.value = True
		
	solvecount.value += 1
	if verbose:
		print 'Progress: ' + str(solvecount.value) + ' / ' + str(maxsolve)
	l.release()
	
	#After treating first Problem, become a normal process.
	doparallel(vert,verbose,k,d,maxsolve,solvecount,illposed,bestval,bestperm,currpermid,l)


def main(vert,verbose = True):
	
	tic = time.time()
	vert=polarvert.getpolvert(vert)
	
	k = len(vert)
	d = len(vert[0])
	
	maxsolve = int(scipy.misc.factorial(k-1))
	
	#Preparation for multiprocessing
	solvecount = mp.Value('i', 0)
	
	illposed = mp.Value('b',False)
	bestval = mp.Value('d', 0.0)
	bestperm = mp.Array('i', range(k-1))
	currpermid = mp.Array('i', [0] * (k-1)) #Identify permutations. If currpermid[r] = s then for the r-th entry the s-th possible entry should be chosen.
	l = mp.Lock()
	processes = []
	
	procnum = 4  #Amount of processes
	#Start processes:
	#First process is special. It has to solve the first problem (before getting new permutation)
	p=mp.Process(target=doparallelfirst,args=(vert,verbose,k,d,maxsolve,solvecount,illposed,bestval,bestperm,currpermid,l))
	processes.append(p)
	p.start()
		
	for i in range(1,procnum):	
		p=mp.Process(target=doparallel,args=(vert,verbose,k,d,maxsolve,solvecount,illposed,bestval,bestperm,currpermid,l))
		processes.append(p)
		p.start()
			
	#Wait for all processes to finish
	for q in processes:
		q.join()
	
	toc = time.time() - tic
	
	if verbose:
		print 'Terminated after ' + str(round(toc,2)) + ' seconds.\n'
		print 'Upper bound:'
		print '1/4c(C) <= ' + str(bestval.value)
		print '\nThis value is achieved for the permutation ' + str(bestperm[:] + [k-1])
	
	if illposed.value:
		print '\n\n ###############'
		print ' #  ATTENTION  #'
		print ' ###############'
		print 'The problem is ill-posed. The determined value may not be an upper bound!\nConsider slight alteration of the vertices (reduce decimals). This may solve this issue.' 
	
	return [bestval.value,bestperm[:] + [k-1]]

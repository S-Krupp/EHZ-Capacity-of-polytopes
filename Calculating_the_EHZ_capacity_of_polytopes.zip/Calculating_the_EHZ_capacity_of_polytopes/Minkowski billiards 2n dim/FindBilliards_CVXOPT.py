import numpy as np
import scipy.special
import scipy.optimize
import multiprocessing as mp
import time
import cvxpy as cp

#-----------------------------------------------------------------------
#-----------------------  Vorbereitung  --------------------------------
#-----------------------------------------------------------------------

#Sortiere n-elementige Indexmenge wie folgt:
#[0,..,n-2,n-1],[0,..,n-2,n],..,[0,..,n-2,m],[0,..,n-1,n],...,[m-n+1,..,m]
#Update indices zur naechsten Indexmenge
def nextIndices(indices,n,m):
	i=n-1
	while True:
		if i==n-1 and indices[i]==m:
			i-=1
		elif i<n-1 and indices[i]==indices[i+1]-1:
			i-=1
		else:
			j=i
			break
	if i<0:
		return False
	indices[j]+=1
	for k in range(j+1,n):
		indices[k]=indices[k-1]+1
	return True

#Berechne Hyperebene H={x:a*x=c} zu Ecken, gegeben durch ein Array von Indizes
def calcHyperplane(vert,indices):
	dim=vert.shape[1]
	x1=vert[indices[0]]
	A=np.array(vert[indices[1]]-x1)
	for i in range(2,dim):
		A=np.vstack([A,vert[indices[i]]-x1])
	if np.linalg.matrix_rank(A,tol=10**(-9))<dim-1:
		#Die gegebenen Ecken definieren keine Hyperebene
		return [False,np.zeros([dim]),0]
	for j in range(dim):
		ej=np.zeros([dim])
		ej[j]=1
		B=np.vstack([A,ej])
		if np.linalg.matrix_rank(B,tol=10**(-9))==dim:
			break
	b=np.zeros([dim])
	b[dim-1]=1
	a=np.linalg.solve(B,b)
	c=x1.dot(a)
	return [True,a,c]

#Given a list of arrays decide whether arr belongs to the list
def isInList(lis,arr):
	for listEle in lis:
		if np.linalg.norm(listEle-arr)<10**(-9):
			return True
	return False
		
#Gegeben Ecken, finde alle Facetten
def getFacets(vert):
	dim=vert.shape[1]
	vertN=vert.shape[0]
	indices=range(dim)
	facetsVer=[]
	facetsNor=[]
	#facetsHig=[]
	goOn=True
	while goOn:
		#Teste, ob indizierte Ecken schon in einer Facette gefunden wurden
		#Diese Zeile ist nur solange relevant, bis eine erste Facette gefunden wurde
		allInF=False
		#Betrachte jede bereits gefundene Facette f.
		for f in facetsVer:
			allInF=True
			#Sind alle betrachteten Ecken in f?
			for j in indices:
				if not j in f:
					allInF=False
					break
			#Falls ja: Betrachte keine weiteren Facetten f. AllInF=True
			if allInF:
				break
		#Falls ein f gefunden wurde mit allInF=True: NaechsteIndexmenge und weiter. Sonst: Schleifendurchgang ausfuehren.
		if allInF:
			goOn=nextIndices(indices,dim,vertN-1)
			continue
		[succ,a,c]=calcHyperplane(vert,indices)
		if not succ:
			continue
		#potenzielle Facette gefunden. Teste, ob alle Ecken auf einer Seite sind und speichere alle Ecken mit Gleichheit
		faceverts=[]
		sign=0
		stopped=False
		for k in range(vertN):
			v=vert[k]
			if abs(a.dot(v)-c)<10**(-9):
				faceverts+=[k]
			else:
				if a.dot(v)<=c-10**(-9):
					if sign==1:
						#Keine Facette!
						stopped=True
						break
					else:
						sign=-1
				else:
					if sign==-1:
						#Keine Facette!
						stopped=True
						break
					else:
						sign=1
		if not stopped:
			faceverts=tuple(faceverts)
			facetsVer+=[faceverts]
			facetsNor+=[-sign*a]
			#facetsHig+=[-sign*c]
		goOn=nextIndices(indices,dim,vertN-1)
	return [facetsVer,facetsNor]

#Gibt eine Liste mit allen Elemente zurueck, die in beiden Eingabelisten enthalten sind.
def inters(list1,list2):
	outList=[]
	for ele in list1:
		if ele in list2:
			outList+=[ele]
	outList=tuple(outList)
	return outList

#Gibt eine Liste mit allen Elemente zurueck, die in allen Eingabelisten enthalten sind. superlist ist die Liste, die alle Eingabelisten enthaelt.
def intersMulti(superlist):
	outList=[]
	listNum=len(superlist)
	ref=superlist[0]
	for ele in ref:
		inInters=True
		for sublist in superlist:
			if not ele in sublist:
				inInters=False
		if inInters:
			outList+=[ele]
	outList=tuple(outList)
	return outList

#Checkt ob list1 eine Teilliste von list2 ist. Funktioniert auch mit Tuples
def isSublist(list1,list2):
	for ele in list1:
		if ele not in list2:
			return False
	return True
	
#Erstellt ein Dictionary. Schluessel: Seiten (als Tupel von Eckenindizes). Werte: Normalenkegel (als Liste von aufspannenden Vektoren/Arrays).
def getFaceDic(vert):
	dic={}
	keyList=[]
	dim=vert.shape[1]
	vertN=vert.shape[0]
	[facets,normals]=getFacets(vert)
	facetsN=len(facets)
	#Jede Facette ist eine Seite
	for i in range(facetsN):
		key=facets[i]
		val=[np.array(normals[i])]
		dic[key]=val
		keyList+=[key]
	for j in range(2,dim+1):
		indices=range(j)
		goOn=True
		while goOn:
			#Berechne jede Seite als Schnitt von Facetten
			superlist=[]
			nCone=[]
			for k in indices:
				superlist+=[facets[k]]
				nCone+=[normals[k]]
			intersection=intersMulti(superlist)
			#Testen, ob Seite schon gefunden wurde.
			if not intersection in dic:
				dic[intersection]=nCone
				keyList+=[intersection]
			goOn=nextIndices(indices,j,facetsN-1)
	#wenn leerer Schnitt gefunden wurde: entfernen
	if () in dic:
		del dic[()]
		keyList.remove(())
	return [dic,keyList,facetsN,facets]


#Given the facets (as indices) of a polytope P determine the representation P={Ax <= b}
#The jth line of Ax<=b belongs to the jth index set in facets
def getFacetIneqs(vert,facets):
	[vertnum,dim] = vert.shape
	facetnum = len(facets)
	A = np.zeros((facetnum,dim))
	b = np.zeros(facetnum)
	counter = 0
	for f in facets:
		#Find index not in f:
		u=np.zeros(dim)
		for i in range(vertnum):
			if i not in f:
				u = vert[i]
		#get supporting hyperplane:
		[succ,a,c] = calcHyperplane(vert,f)
		if np.inner(u,a) > c + 10**(-9):
			a *= (-1)
			c *= (-1)
		A[counter,:] = a[:]
		b[counter] = c
		counter += 1
	return [A,b]


#Given a face F (as vertex indices) determine all facets (as vertex indices)
#that contain F. Also return a list of the remaining facets
def homeFacets(facetsInd,myFaceInd):
	homefacets = []
	homeInd = []
	nonhomefacets = []
	nonhomeInd = []
	for i in range(len(facetsInd)):
		f = facetsInd[i]
		if isSublist(myFaceInd,f):
			homefacets += [f]
			homeInd += [i]
		else:
			nonhomefacets += [f]
			nonhomeInd += [i]
	return[homefacets,nonhomefacets,homeInd,nonhomeInd]
	

#Model the inequalities that define p_j in G_j. The facets G_1,...,G_m
#are given by myFaceList. The polytope T has the form {x: Ax<=b}.
#lmbdaNum gives the neccessary zero columns.
#The same routine works for q_j as well.
def ineqForp(A,b,myFaceList,allFaceInd,allFacetInd,lambdaNum):
	m = len(myFaceList)
	[fnum,dim] = A.shape
	nHomeFacets = []
	total = 0
	#For each chosen face determine their non-home facets (i.e. facets the face is not contained in)
	for i in range(m):
		myFace = allFaceInd[myFaceList[i]]
		newNonHomeInd = homeFacets(allFacetInd,myFace)[3]
		total += len(newNonHomeInd)
		nHomeFacets += [newNonHomeInd]
	
	Mat = np.zeros((total+lambdaNum,m*dim+lambdaNum))
	Vec = np.zeros(total+lambdaNum)
	count = 0
	for i in range(m):
		nonHomes = nHomeFacets[i]
		for j in nonHomes:
			Mat[count,i*dim:(i+1)*dim] = np.transpose(A[j,:])
			Vec[count] = b[j]
			count += 1
	
	#Nonnegativity for the lambdas		
	for j in range(lambdaNum):
		Mat[count,m*dim+j] = -1.0
		count += 1
	return [Mat,Vec]



#Same as ineqForq but with additional constraints to make sure that q_j =/= q_{j+1}
def ineqForq(A,b,myFaceList,allFaceInd,allFacetInd,lambdaNum):
	m = len(myFaceList)
	[fnum,dim] = A.shape
	nHomeFacets = []
	total = 0
	#For each chosen face determine their non-home facets (i.e. facets the face is not contained in)
	for i in range(m):
		myFace = allFaceInd[myFaceList[i]]
		newNonHomeInd = homeFacets(allFacetInd,myFace)[3]
		total += len(newNonHomeInd)
		nHomeFacets += [newNonHomeInd]
	
	Mat = np.zeros((total + lambdaNum + 1,m*dim+lambdaNum+1))
	Vec = np.zeros(total + lambdaNum + 1)
	count = 0
	for i in range(m):
		nonHomes = nHomeFacets[i]
		for j in nonHomes:
			Mat[count,i*dim:(i+1)*dim] = np.transpose(A[j,:])
			Vec[count] = b[j]
			count += 1
	for j in range(lambdaNum):
		Mat[count,m*dim + j] = -1.0
		Mat[count,m*dim + lambdaNum] = 1.0
		count += 1
	
	#Nonnegativity of the lambdas
	Mat[count,m*dim + lambdaNum] = -1.0
		
	return [Mat,Vec]


#Model the equality constraints. Input is T = {x:Ax <= b},
#the normal vectors Unormal = [[u_1^1,...,u_{k_1}^1],...,[u_1^m,...,u_{k_m}^m]],
#a list of the facets and faces of T (by vertex indices) and a list of indices
#that determine G_1,...,G_m.
def eqForp(A,b,myFaceList,allFaceInd,allFacetInd,Unormal):
	#Model that p lies in the correct facets
	m = len(myFaceList)
	[fnum,dim] = A.shape
	hFacets = []
	
	#Determine number nonnegative variables lambda_j
	lambdaNum = 0
	for Umat in Unormal:
		lambdaNum += len(Umat)

	total = 0
	#For each chosen face determine their home facets (i.e. facets the face is contained in)
	for i in range(m):
		myFace = allFaceInd[myFaceList[i]]
		newHomeInd = homeFacets(allFacetInd,myFace)[2]
		total += len(newHomeInd)
		hFacets += [newHomeInd]
	
	UpperMat = np.zeros((total,m*dim+lambdaNum))
	UpperVec = np.zeros(total)
	count = 0
	for i in range(m):
		homes = hFacets[i]
		for j in homes:
			UpperMat[count,i*dim:(i+1)*dim] = np.transpose(A[j,:])
			UpperVec[count] = b[j]
			count += 1
	
	#Model that p_{j+1}-p_j lies in -N_K(q_{j+1})
	LowerMat = np.zeros((m*dim,m*dim+lambdaNum))
	count = m*dim
	#i=0 is special case:
	LowerMat[0:dim,0:dim] = np.eye(dim)
	LowerMat[0:dim,(m-1)*dim:m*dim] = -np.eye(dim)
	
	Umat = Unormal[0]
	for j in range(len(Umat)):
		LowerMat[0:dim,count] = np.transpose(Umat[j])
		count += 1
	
	#Now for i >= 1
	for i in range(1,m):
		LowerMat[i*dim:(i+1)*dim,i*dim:(i+1)*dim] = np.eye(dim)
		LowerMat[i*dim:(i+1)*dim,(i-1)*dim:i*dim] = -np.eye(dim)
		
		Umat = Unormal[i]
		for j in range(len(Umat)):
			LowerMat[i*dim:(i+1)*dim,count] = np.transpose(Umat[j])
			count += 1
	
	#Stack upper and lower halfes:
	Mat = np.zeros((total + m*dim, m*dim+lambdaNum))
	Mat[:total,:] = UpperMat[:]
	Mat[total:,:] = LowerMat[:]
	
	Vec = np.zeros(total + m*dim)
	
	Vec[:total] = UpperVec[:]
	
	return[Mat,Vec]


#Model the equality constraints. Input is K = {x:Ax <= b},
#the normal vectors Wnormal = [[w_1^1,...,w_{k_1}^1],...,[w_1^m,...,w_{k_m}^m]],
#a list of the facets and faces of K (by vertex indices) and a list of indices
#that determine F_1,...,F_m.
def eqForq(A,b,myFaceList,allFaceInd,allFacetInd,Wnormal):
	#Model that q lies in the correct facets
	m = len(myFaceList)
	[fnum,dim] = A.shape
	hFacets = []
	
	#Determine number nonnegative variables mu_j
	muNum = 0
	for Wmat in Wnormal:
		muNum += len(Wmat)

	total = 0
	#For each chosen face determine their home facets (i.e. facets the face is contained in)
	for i in range(m):
		myFace = allFaceInd[myFaceList[i]]
		newHomeInd = homeFacets(allFacetInd,myFace)[2]
		total += len(newHomeInd)
		hFacets += [newHomeInd]
	
	UpperMat = np.zeros((total,m*dim+muNum+1))
	UpperVec = np.zeros(total)
	count = 0
	for i in range(m):
		homes = hFacets[i]
		for j in homes:
			UpperMat[count,i*dim:(i+1)*dim] = np.transpose(A[j,:])
			UpperVec[count] = b[j]
			count += 1
	
	#Model that q_{j+1}-q_j lies in N_T(p_j)
	LowerMat = np.zeros((m*dim,m*dim+muNum+1))
	count = m*dim
	
	#Now for i<=m-2
	for i in range(m-1):
		LowerMat[i*dim:(i+1)*dim,(i+1)*dim:(i+2)*dim] = np.eye(dim)
		LowerMat[i*dim:(i+1)*dim,i*dim:(i+1)*dim] = -np.eye(dim)
		
		Wmat = Wnormal[i]
		for j in range(len(Wmat)):
			LowerMat[i*dim:(i+1)*dim,count] = -np.transpose(Wmat[j])
			count += 1
	
	#i=m-1 is special case:
	LowerMat[(m-1)*dim:m*dim,0:dim] = np.eye(dim)
	LowerMat[(m-1)*dim:m*dim,(m-1)*dim:m*dim] = -np.eye(dim)
	
	Wmat = Wnormal[m-1]
	for j in range(len(Wmat)):
		LowerMat[(m-1)*dim:m*dim,count] = -np.transpose(Wmat[j])
	
	#Stack upper and lower halfes:
	Mat = np.zeros((total + m*dim, m*dim+muNum+1))
	Mat[:total,:] = UpperMat[:]
	Mat[total:,:] = LowerMat[:]
	
	Vec = np.zeros(total + m*dim)
	
	Vec[:total] = UpperVec[:]
	
	return[Mat,Vec]


#Sortiere n-elementige Indexmenge wie folgt:
#[0,..,0,0],[0,..,0,1],..,[0,..,0,m],[0,..,1,0],...,[m,..,m]
#Update indices zur naechsten Indexmenge
def nextIndicesAll(indices,n,m):
	i=n-1
	while True:
		if i<0:
			return False
		if indices[i]==m:
			i-=1
		else:
			j=i
			break
	indices[j]+=1
	for k in range(j+1,n):
		indices[k]=0
	return True

#Ueberprueft zu einem Integer-Array, ob es zwei aufeinander folgende, identische Eintraege gibt.
def hasDouble(arr):
	if arr[0]==arr[-1]:
		return True
	for j in range(1,len(arr)):
		if arr[j]==arr[j-1]:
			return True
	return False

#berechnet die Wirkung einer Billiardbahn
def action(orbitK,orbitT):
	summ=0
	k=len(orbitK)
	for i in range(k-1):
		summ+=orbitT[i].dot(orbitK[i+1]-orbitK[i])
	summ+=orbitT[k-1].dot(orbitK[0]-orbitK[k-1])
	return summ
	

def doParallel(ind1,relevFacesK,keyListK,keyListT,n,k,dicK,facetsNK,dicT,facetsNT,vertK,vertT,facetsK,facetsT,minVal,orbStore,bouncePointsN,l,AK,bK,AT,bT):
	
	otherInd=(k-1)*[0]
	goOnK=True
	while goOnK:
		indicesK=[ind1]+otherInd
		if hasDouble(indicesK):
			goOnK=nextIndicesAll(otherInd,k-1,len(relevFacesK)-1)
			continue
		fChoiceK=[]
		for indexK in indicesK:
			fChoiceK+=[relevFacesK[indexK]]
		indicesT=k*[0]
		goOnT=True
		while goOnT:
				
			fChoiceT=[]
			for indexT in indicesT:
				fChoiceT+=[keyListT[indexT]]
			#Zu den gegebenen Seiten das LP aufstellen um p zu finden:
			Unormal = []
			lambdaNum = 0
			for fK in fChoiceK:
				nCone = []
				for nvec in dicK[fK]:
					nCone += [nvec]
					lambdaNum += 1
				Unormal += [nCone]
			
			[eqMat,eqVec] = eqForp(AT,bT,indicesT,keyListT,facetsT,Unormal)
			colCount=eqMat.shape[1]
			[ineqMat,ineqVec] = ineqForp(AT,bT,indicesT,keyListT,facetsT,lambdaNum)
			#Das LP loesen:
			x=cp.Variable(colCount)
			c=np.zeros(colCount)
			#c[colCount-1]=1	
			constraints = [ineqMat*x<=ineqVec, eqMat*x==eqVec]
			obj = cp.Maximize(c*x)
			prob = cp.Problem(obj, constraints)
			lamb=prob.solve(solver=cp.CVXOPT)
			#Falls LP unloesbar: naechste Wahl von Seiten
			if prob.status!='optimal':
				goOnT=nextIndicesAll(indicesT,k,len(keyListT)-1)					
				continue
			
			#We found p_1,...,p_m. Next we search for q_1,...,q_m.
			Wnormal = []
			muNum = 0
			for fT in fChoiceT:
				nCone = []
				for nvec in dicT[fT]:
					nCone += [nvec]
					muNum += 1
				Wnormal += [nCone]
			
			[eqMat2,eqVec2] = eqForq(AK,bK,indicesK,keyListK,facetsK,Wnormal)
			colCount2=eqMat2.shape[1]
			[ineqMat2,ineqVec2] = ineqForq(AK,bK,indicesK,keyListK,facetsK,muNum)
			#Das LP loesen:
			x2=cp.Variable(colCount2)
			#Objective tries to find pairwise distinct bouncing points
			c2=np.zeros(colCount2)
			c2[colCount2-1]=1	
			constraints2 = [ineqMat2*x2<=ineqVec2, eqMat2*x2==eqVec2]
			obj2 = cp.Maximize(c2*x2)
			prob2 = cp.Problem(obj2, constraints2)
			mu=prob2.solve(solver=cp.CVXOPT)
			#Falls LP unloesbar: naechste Wahl von Seiten
			if prob2.status!='optimal':
				goOnT=nextIndicesAll(indicesT,k,len(keyListT)-1)					
				continue
				
			#Falls Optimalwert=0 ist eine Loesung nur moeglich, wenn ein Normalenvektor = 0 gewaehlt wird. Dies ist keine gueltige Wahl.
			if abs(mu)<10**(-6):
				goOnT=nextIndicesAll(indicesT,k,len(keyListT)-1)					
				continue

			orbitK=np.zeros([k,n])
			orbitT=np.zeros([k,n])
			#Bahn aus der Loesung extrahieren und Wirkung berechnen.
			for i in range(k):
				orbitK[i]=np.array(x2.value[i*n:(i+1)*n])
				orbitT[i]=np.array(x.value[i*n:(i+1)*n])
			act=action(orbitK,orbitT)
			#Wenn Wirkung ein neues Minimum ist: Update
			l.acquire()
			if act<minVal.value-10**(-9):
				minVal.value=act
				orbStore[k-2][0][:]=orbitK.flatten()
				orbStore[k-2][1][:]=orbitT.flatten()
				bouncePointsN.value=k
			l.release()
			goOnT=nextIndicesAll(indicesT,k,len(keyListT)-1)
		goOnK=nextIndicesAll(otherInd,k-1,len(relevFacesK)-1)

#gegeben K und T finde minimalen Orbit/Kapazitaet
def findMinOrbit(vertK,vertT):
	n=vertK.shape[1]
	minVal=mp.Value('d',np.Inf)
	#Arrays fuer multiprocessing brauchen vordefinierte, feste Laenge. Erstelle solche Arrays fuer jede notwendige Groesse. 
	orbStore=[]
	for i in range(2,n+2):
		iBounceOrbK=mp.Array('d',np.zeros(n*i))
		iBounceOrbT=mp.Array('d',np.zeros(n*i))
		orbStore+=[[iBounceOrbK,iBounceOrbT]]
	bouncePointsN=mp.Value('i',0)
	l=mp.Lock()
	processes=[]
	[dicK,keyListK,facetsNK,facetsK]=getFaceDic(vertK)
	[dicT,keyListT,facetsNT,facetsT]=getFaceDic(vertT)
	[AK,bK] = getFacetIneqs(vertK,facetsK)
	[AT,bT] = getFacetIneqs(vertT,facetsT)
	for k in range(2,n+2):
		#Waehle k Seiten aus K (Facetten genuegen, wenn k=n+1) und waehle k Seiten aus T.
		#Aufeinander folgende Facetten sind in K nicht gestattet.
		if k < n+1:
			relevFacesK=keyListK
		else:
			relevFacesK=facetsK
		for ind1 in range(len(relevFacesK)):
			#Parallelisierung
			p=mp.Process(target=doParallel,args=(ind1,relevFacesK,keyListK,keyListT,n,k,dicK,facetsNK,dicT,facetsNT,vertK,vertT,facetsK,facetsT,minVal,orbStore,bouncePointsN,l,AK,bK,AT,bT))
			processes.append(p)
			p.start()
		#Warte bis alle Prozesse beendet sind:
		for q in processes:
			q.join()
	#Aufbereitung der Bahnen:
	minOrbitK=orbStore[bouncePointsN.value-2][0]
	minOrbitT=orbStore[bouncePointsN.value-2][1]
	outOrbK=np.zeros((bouncePointsN.value,n))
	outOrbT=np.zeros((bouncePointsN.value,n))
	for j in range(bouncePointsN.value):
		outOrbK[j,:]=minOrbitK[j*n:(j+1)*n]
		outOrbT[j,:]=minOrbitT[j*n:(j+1)*n]
	minOrb=[outOrbK,outOrbT]
	return [minVal.value,minOrb,bouncePointsN.value]



def main(vertK,vertT,verbose = True):
	s=time.time()
	[minVal,minOrb,bouncePointsN]=findMinOrbit(vertK,vertT)
	t=time.time()
	
	if verbose:
		print 'Time spent: ' + str(t-s)
		
		print 'Minimal orbit has '+str(bouncePointsN)+' bouncing points.'
		print '-------------------------------------------------'
		print 'Orbit in K:'
		print minOrb[0]
		print '---'
		print 'Orbit in T:'
		print minOrb[1]
		print '-------------------------------------------------'
		print 'Minimal action: '+str(minVal)
	
	return minVal
	

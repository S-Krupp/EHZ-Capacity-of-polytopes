import random_poly_nDim as rp
import FindBilliards_CVXOPT as billiard
import random

#######################################################################
############################# INPUT ###################################
#######################################################################

seedK = random.random()
seedT = random.random()

samplesizeK = 3
samplesizeT = 3

lenrangeK = [1,3]
lenrangeT = [1,3]

dim = 2

K = rp.main(seedK, dim, samplesizeK, lenrangeK)
T = rp.main(seedT, dim, samplesizeT, lenrangeT)

#######################################################################
#######################################################################

billiard.main(K,T)

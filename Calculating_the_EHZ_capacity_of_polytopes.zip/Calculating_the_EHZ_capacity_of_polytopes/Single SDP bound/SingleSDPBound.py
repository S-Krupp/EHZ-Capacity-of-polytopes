import pickle
import numpy as np
import scipy.special
import scipy.optimize
import cvxpy as cvx
import time
import facet
import sparseform as sf
import solveSDP as sdp

#Generates the SDP and solves it via Mosek
#Input is done via vert.py.

#--------------------------------------------------------------------
#-------------------- Constructing matrices -------------------------
#--------------------------------------------------------------------

#Defined for j=0,...,col-1. (row x col)-Matrix whose j-th column consists of ones and all other entries are zero.
def Ej(j,row,col):
	ej=np.zeros(col)
	ej[j]=1
	return np.vstack([ej]*row)


def main(vert, verbose = True):
	
	tic = time.time()
	
	#Calculation of d,k,m goes here!
	d=len(vert[0]) #Dimension
	m=len(vert) #Nr. of vertices
	k=facet.getFacetNum(vert) #Nr. of facets
	
	#Important Blocks:
	#Symplectic J
	J=np.zeros([d,d])
	I=np.eye(d/2)
	J[:d/2,d/2:]=I
	J[d/2:,:d/2]=-I
	scaledJ=0.25*J
	
	#Matrix whose rows are the vertices of P.
	W=np.vstack(vert)
	
	#Sizes of the matrices. Size of Q: colCount x colCOunt. Size of A: rowsA x colCount. 
	colCount=k*(1+2*d+m)
	rowsA=d+k*m
	
	#Construct c:
	c=np.hstack([np.ones([k]),np.zeros([colCount-k])])
	#Construct the coefficient matrix for <cc^T,X> = 1
	coeffC=np.outer(c,c)
	
	#Construct A 'columnwise' (not really columnwise since A is handled like a blockmatrix):
	A=np.zeros([rowsA,colCount])
	#1st 'column'
	for i in range(k):
		A[d+i*m:d+(i+1)*m,:k]=-Ej(i,m,k)
	#2nd to 2k-th 'column'
	for j in range(k):
		A[:d,k+2*j*d:k+(2*j+1)*d]=np.eye(d)
		A[:d,k+(2*j+1)*d:k+(2*j+2)*d]=-np.eye(d)
		A[d+j*m:d+(j+1)*m,k+2*j*d:k+(2*j+1)*d]=W
		A[d+j*m:d+(j+1)*m,k+(2*j+1)*d:k+(2*j+2)*d]=-W
	#last k 'columns':
	for j in range(k):
		A[d+j*m:d+(j+1)*m,k*(1+2*d)+j*m:k*(1+2*d)+(j+1)*m]=np.eye(m)
	#Construct the coefficient matrix for <A^T*A,X> = 0
	coeffA=np.matmul(np.transpose(A),A)
	
	#Construct Q (similar to A):
	Q=np.zeros([colCount,colCount])
	for i in range(k):
		for j in range(i+1,k):
			Q[k+d*2*i:k+d*(2*i+1),k+d*2*j:k+d*(2*j+1)]=-scaledJ
			Q[k+d*(2*i+1):k+d*(2*i+2),k+d*2*j:k+d*(2*j+1)]=scaledJ
			Q[k+d*2*i:k+d*(2*i+1),k+d*(2*j+1):k+d*(2*j+2)]=scaledJ
			Q[k+d*(2*i+1):k+d*(2*i+2),k+d*(2*j+1):k+d*(2*j+2)]=-scaledJ
			
			Q[k+d*2*j:k+d*(2*j+1),k+d*2*i:k+d*(2*i+1)]=scaledJ
			Q[k+d*(2*j+1):k+d*(2*j+2),k+d*2*i:k+d*(2*i+1)]=-scaledJ
			Q[k+d*2*j:k+d*(2*j+1),k+d*(2*i+1):k+d*(2*i+2)]=-scaledJ
			Q[k+d*(2*j+1):k+d*(2*j+2),k+d*(2*i+1):k+d*(2*i+2)]=scaledJ
	
	
	#--------------------------------------------------------------------
	#------------------------- Sparse format ----------------------------
	#--------------------------------------------------------------------
	
	Qdata = sf.runComplete(Q)
	
	Adata = sf.runComplete(coeffA)
	
	Cdata = sf.runComplete(coeffC)
	
	#all matrices same size?
	if (Qdata[3] != Adata[3]) or (Qdata[3] != Cdata[3]) or (Cdata[3] != Adata[3]):
		print "Error in getSDPmat.py ; Q, coeffA, coeffC don't have the same dimension!"
	
	else:
		#Input as needed for Mosek. barc is the objective, bara are the constraints
		matdim = Qdata[3]
	
		barai   = [Adata[0], Cdata[0]]
		baraj   = [Adata[1], Cdata[1]]
		baraval = [Adata[2], Cdata[2]]
	
		barci   = Qdata[0]
		barcj   = Qdata[1]
		barcval = Qdata[2]
	
	
	b0 = 0.0
	b1 = 1.0
	
	#--------------------------------------------------------------------
	#-------------------------- call solver -----------------------------
	#--------------------------------------------------------------------
	
	sdp.setup(b0,b1,barai,baraj,baraval,barci,barcj,barcval,matdim)
	
	[statcode,optval,solution] = sdp.run()
	
	toc = time.time() - tic
	
	print 'Calculation terminated. Required time: ' + str(toc) + ' seconds.'
	
	if statcode != 1:
		print 'Solver failed. Error code: ' + str(statcode)
		return []
	else:
		if verbose:
			print 'Calculation terminated successfully. Upper bound:'
			print '1/4c(C) <= ' + str(optval)
		return optval
			


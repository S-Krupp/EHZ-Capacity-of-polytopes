import numpy as np

#Given vertices of polytope P, find vertices of P^0
def getpolvert(vert):
	tol=10**(-9) #Tolerance
	m=len(vert) #m = Nr. of vertices
	d=len(vert[0]) #d = Dimension
	indices=range(d)
	goOn=True
	polvert=[] #store found vertices
	while goOn:
		#Take a regular, quadratic subsystem and solve it.
		sub=np.array([vert[i] for i in indices])
		if np.linalg.matrix_rank(sub,tol)==d: #Check for regularity
			potVert=np.linalg.solve(sub,np.ones(d))
			left=np.array(vert).dot(potVert)
			if leqOne(left,tol): #Check wether the solution lies in P^0						
				if not elementOf(polvert,potVert,tol): #Check wether solution already has been found				
					polvert+=[potVert]
		goOn=nextIndices(indices,d,m)	
	return polvert

#Given an index set (i.e. a set consisting of n distinct numbers from range(m))
#find its successor. These sets are ordered as follows:
#(0,1,..,n-1,n), (0,1,..,n-1,n+1), ..., (0,1,..,n-1,m), (0,1,..,n,n+1), ...,(m-n,..,m-1)
#Return value is True iff there is a successor. The predecessor is overwritten
def nextIndices(indices,n,m):
	i=n-1
	while True:
		if i==n-1 and indices[i]==m-1:
			i-=1
		elif i<n-1 and indices[i]==indices[i+1]-1:
			i-=1
		else:
			j=i
			break
	if i<0:
		return False
	indices[j]+=1
	for k in range(j+1,n):
		indices[k]=indices[k-1]+1
	return True

#Checks wether a given array equals an array from a given List; up to tolerance tol.
def elementOf(arrList,arr,tol):	
	for temp in arrList:
		if np.linalg.norm(temp-arr)<tol:
			return True
	return False

#Checks wether a given array is (element wise) <=1; up to tolerance tol. 
def leqOne(arr,tol):
	for ele in arr:
		if ele>1+tol:
			return False
	return True


##########################################################################################
###################################  manual use  #########################################
##########################################################################################


# vert = [[   0.5,    1.5,  -1.25,  1.75],
        # [   0.5,    1.5,    1.5,  -1.0],
        # [-5./3., -2./3.,    2.0, 2./3.],
        # [   0.0,    1.0,    2.0,  -1.0],
        # [ 8./3., -2./3., -7./3., 2./3.],
        # [   1.0,    1.0,    1.0,  -1.0],
        # [-4./3., -1./3., -1./3.,  -1.0],
        # [  -2.5,   -1.5,    2.0,  -1.0],
        # [   1.0,   -1.5,   -1.5,  -1.0]]

# pv = getpolvert(vert)
# for v in pv:
	# print v

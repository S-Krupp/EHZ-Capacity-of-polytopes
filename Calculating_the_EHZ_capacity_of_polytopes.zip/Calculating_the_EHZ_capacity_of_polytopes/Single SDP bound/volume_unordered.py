import numpy as np
import pickle
import polarvert as pv
import random_poly_nDim as rp


#Calculates the volume of a polytope.
#Input via vert.txt file
#MAKE SURE VERTICES ARE ORDERED ( I.E. v[i] AND v[i+1] ARE NEIGHBORS ) !!!!!!!
def main_autoread(filename = 'vert.txt'):
	pfile = open(filename)
	unordvert = pickle.load(pfile)
	pfile.close()
	
	vert=order(unordvert)

	vnum=len(vert)

	fix=vert[0]

	#Calculate volume
	totalarea=0

	for i in range(1,vnum-1):
	
		a = np.array(fix)
		b = np.array(vert[i])
		c = np.array(vert[i+1])
	
		base = b-a
		baselen = np.linalg.norm(base)
		proj = a + (np.inner(c-a,base) / np.inner(base,base)) * base
		height=np.linalg.norm(c-proj)
		area=baselen*height/2
		totalarea+=area

	print "The area of the polytope is: " + str(totalarea) + "\n"

	optval=round(1./(4. * totalarea),9)

	print "The quantity 1/4c(P) equals: " + str(optval)


def order(vert):
	vnum = len(vert)
	d = len(vert[0])
	newvert = [vert[0]]
	v = np.array(vert[0])
	
	for i in range(1,vnum):
		for u in vert:
			w = np.array(u)
			waschecked = False
			for oldv in newvert:
				if np.linalg.norm(w-np.array(oldv)) < 10**(-6):
					waschecked = True
			if waschecked:
				continue
			dif = v-w
			n=np.array([dif[1],-dif[0]])
			height = np.inner(n,w)
			
			sign = 0
			failed = False
			
			for z in vert:		
				x=np.array(z)
				if np.inner(x,n) > height + 10**(-6):
					#sign = 1
					if sign == -1:
						failed = True
						break
					else:
						sign = 1
						
				if np.inner(x,n) < height - 10**(-6):
					#sign = -1
					if sign == 1:
						failed = True
						break
					else:
						sign = -1
			
			if not failed:
				newvert += [u]
				v = np.array(u)
				break
	return newvert
						


#Calculates the volume of a polytope.
#Input done directly.
#MAKE SURE VERTICES ARE ORDERED ( I.E. v[i] AND v[i+1] ARE NEIGHBORS ) !!!!!!!
def main(unordvert):
	vert = order(unordvert)
	vnum=len(vert)

	fix=vert[0]

	#Calculate volume
	totalarea=0

	for i in range(1,vnum-1):
	
		a = np.array(fix)
		b = np.array(vert[i])
		c = np.array(vert[i+1])
	
		base = b-a
		baselen = np.linalg.norm(base)
		proj = a + (np.inner(c-a,base) / np.inner(base,base)) * base
		height=np.linalg.norm(c-proj)
		area=baselen*height/2
		totalarea+=area
	
	#print "The area of the polytope is: " + str(totalarea) + "\n"

	optval=round(1./(4. * totalarea),9)

	#print "The quantity 1/4c(P) equals: " + str(optval)
	
	return optval

#main_autoread()

seed = 137
samp = 67
lenr = [1,3]

vert = rp.main(seed,2,samp,lenr)
print main(vert)

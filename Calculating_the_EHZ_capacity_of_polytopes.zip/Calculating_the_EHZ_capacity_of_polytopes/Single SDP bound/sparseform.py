#For a matrix M return the sparse notation for Mosek

import numpy as np

M=np.array([[0]])

Mi=[]
Mj=[]
Mval=[]
dim=1

#input M
def setmat(Mnew):
	global M, dim
	
	#Square Check
	form = Mnew.shape
	if form[0] != form[1]:
		print 'Error in sparseform.py ; M is not square!'
		return
		
	M = Mnew
	dim = form[0]
	

#run calculation of Mi, Mj, Mval
def calculate(tol=10**(-9)):
	global Mi, Mj, Mval
	
	#first reset:
	Mi = []
	Mj = []
	Mval = []
	
	#go through lower left triangle
	for i in range(dim):
		for j in range(i+1):
			
			#consider any entry with sufficiently large absolute value.
			if abs(M[i,j]) >= tol:
				Mi+=[i]
				Mj+=[j]
				Mval+=[M[i,j]]


#call output
def get():
	return [Mi, Mj, Mval, dim]


#run whole script
def runComplete(Mnew):
	
	setmat(Mnew)
	calculate()
	
	return get()

import random_poly_nDim as rp
import SingleSDPBound as ub
import polarvert
import random
import sys

#######################################################################
############################# INPUT ###################################
#######################################################################

seed = random.random()
dim = 2
samplesize = 10
lenrange = [1,3]

C = rp.main(seed, dim, samplesize, lenrange)

#######################################################################
#######################################################################

dim = C.shape[1]

if dim % 2 == 1:
	print 'The dimension of the polytope has to be even!'
	sys.exit(0)


if dim > 2:
	C = polarvert.getpolvert(C)

ub.main(C)

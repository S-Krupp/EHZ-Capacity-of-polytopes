import sys
import mosek

# Since the value of infinity is ignored, we define it solely
# for symbolic purposes
inf = 0.0

############################################################
######################### Input ############################
############################################################

# Input SDP should have the following Form:

# max <C,X>
# s.t. <A_0,X> = b_0
#      <A_1,X> = b_1
#      X >= 0
#      X psd

# Bound keys for constraints
bkc = [mosek.boundkey.fx,
       mosek.boundkey.fx]

b0 = 3.0
b1 = 12.0

# Bound values for constraints
blc = [b0, b1]
buc = [b0, b1]

# Below is the sparse representation of the A
# matrix stored by row.
matrixdim = 2

# Number of elements in the upper right triangle (diagonal excluded)
uptri = matrixdim*(matrixdim-1)/2

bkc += [mosek.boundkey.lo]*uptri
blc += [0.0] * uptri
buc += [+inf] * uptri

barci = [1]
barcj = [0]
barcval = [1.0]

barai = [[0],
         [1]]
baraj = [[0],
         [1]]
baraval = [[1.0],
           [1.0]]

for j in range(matrixdim-1):
	for i in range(j+1,matrixdim):
		barai += [[i]]
		baraj += [[j]]
		baraval += [[1.0]]

def setup(b_0, b_1, bara_i, bara_j, bara_val, barc_i, barc_j, barc_val, matdim):
	global bkc, blc, buc, b0, b1, barai, baraj, baraval, barci, barcj, barcval, matrixdim, uptri
	b0, b1 = b_0, b_1
	barai, baraj, baraval = bara_i, bara_j, bara_val
	barci, barcj, barcval = barc_i, barc_j, barc_val
	matrixdim = matdim
	
	uptri = matrixdim*(matrixdim-1)/2
	
	bkc = [mosek.boundkey.fx,
		   mosek.boundkey.fx]
	blc = [b0, b1]
	buc = [b0, b1]
	bkc += [mosek.boundkey.lo]*uptri
	blc += [0.0] * uptri
	buc += [+inf] * uptri
	
	for j in range(matrixdim-1):
		for i in range(j+1,matrixdim):
			barai += [[i]]
			baraj += [[j]]
			baraval += [[1.0]]

#############################################################
######################### Mosek #############################
#############################################################

# Define a stream printer to grab output from MOSEK
def streamprinter(text):
    sys.stdout.write(text)
    sys.stdout.flush()


def main():
    # Make mosek environment
    with mosek.Env() as env:

        # Create a task object and attach log stream printer
        with env.Task(0, 0) as task:
			
            #task.set_Stream(mosek.streamtype.log, streamprinter)
            
            BARVARDIM = [matrixdim]
            
            numcon = len(bkc)

            # Append 'numcon' empty constraints.
            # The constraints will initially have no bounds.
            task.appendcons(numcon)

            # Append matrix variables of sizes in 'BARVARDIM'.
            # The variables will initially be fixed at zero.
            task.appendbarvars(BARVARDIM)

            for i in range(numcon):
                # Set the bounds on constraints.
                # blc[i] <= constraint_i <= buc[i]
                task.putconbound(i, bkc[i], blc[i], buc[i])


            symc = task.appendsparsesymmat(BARVARDIM[0],
                                           barci,
                                           barcj,
                                           barcval)

            syma0 = task.appendsparsesymmat(BARVARDIM[0],
                                            barai[0],
                                            baraj[0],
                                            baraval[0])

            syma1 = task.appendsparsesymmat(BARVARDIM[0],
                                            barai[1],
                                            baraj[1],
                                            baraval[1])

            task.putbarcj(0, [symc], [1.0])

            task.putbaraij(0, 0, [syma0], [1.0])
            task.putbaraij(1, 0, [syma1], [1.0])

            for j in range(uptri):
                symaj = task.appendsparsesymmat(BARVARDIM[0],
                                                barai[2+j],
                                                baraj[2+j],
                                                baraval[2+j])

                task.putbaraij(2+j, 0, [symaj], [1.0])

            # Input the objective sense (minimize/maximize)
            task.putobjsense(mosek.objsense.maximize)

            # Solve the problem and print summary
            task.optimize()
            # task.solutionsummary(mosek.streamtype.msg)

            # Get status information about the solution
            prosta = task.getprosta(mosek.soltype.itr)
            solsta = task.getsolsta(mosek.soltype.itr)

            if (solsta == mosek.solsta.optimal or
                    solsta == mosek.solsta.near_optimal):
                #xx = [0.] * numvar
                #task.getxx(mosek.soltype.itr, xx)

                lenbarvar = BARVARDIM[0] * (BARVARDIM[0] + 1) / 2
                barx = [0.] * int(lenbarvar)
                task.getbarxj(mosek.soltype.itr, 0, barx)
                primalobj = task.getprimalobj(mosek.soltype.itr)

                #print("Optimal solution:\nx=%s\nbarx=%s" % (xx, barx))
                #print("Optimal solution:\nbarx=%s" % (barx))

                return [1,primalobj,barx]

            elif (solsta == mosek.solsta.dual_infeas_cer or
                  solsta == mosek.solsta.prim_infeas_cer or
                  solsta == mosek.solsta.near_dual_infeas_cer or
                  solsta == mosek.solsta.near_prim_infeas_cer):
                #print("Primal or dual infeasibility certificate found.\n")
                return [2,0,[]]
            elif solsta == mosek.solsta.unknown:
                #print("Unknown solution status")
                return [3,0,[]]
            else:
                #print("Other solution status")
                return [4,0,[]]

# call the main function
def run():
	try:
			return main()
	except mosek.MosekException as e:
    		print("ERROR: %s" % str(e.errno))
    		if e.msg is not None:
        		print("\t%s" % e.msg)
        		sys.exit(1)
	except:
    		import traceback
    		traceback.print_exc()
    		sys.exit(1)

#Example for use of setup:

#tb0=1
#tb1=1.5
#tbarai=[[0,1,2],[0,1,2,1,2,2]]
#tbaraj=[[0,1,2],[0,0,0,1,1,2]]
#tbaraval=[[1.0,1.0,1.0],[1.0,1.0,1.0,1.0,1.0,1.0]]
#tbarci=[0,1,1,2,2]
#tbarcj=[0,0,1,1,2]
#tbarcval=[2.0,1.0,2.0,1.0,2.0]
#tmatrixdim=3
#print("Test Setup started")
#setup(tb0,tb1,tbarai,tbaraj,tbaraval,tbarci,tbarcj,tbarcval,tmatrixdim)
#print("Test Setup done!")
#run()

import random_poly_nDim as rp
import QAP_upper_bound_LP as ub
import random
import sys
import volume_unordered as vol
import polarvert as pv

#######################################################################
############################# INPUT ###################################
#######################################################################

seed = random.random()
samplesize = 10
dim = 2
lenrange = [1,3]
isBig = False

C = rp.main(seed, dim, samplesize, lenrange)

#######################################################################
#######################################################################

isBig = False

dim = C.shape[1]

if dim % 2 == 1:
	print 'The dimension of the polytope has to be even!'
	sys.exit(0)


if dim > 2 and not isBig:
	C = pv.getpolvert(C)


if dim > 2 and isBig:
	ub.main(C,input_polar = True)
else:
	ub.main(C)

if dim == 2:
	exact = vol.main(C)
	print '\n\nThe exact value is 1/4c(C) = ' + str(exact) 

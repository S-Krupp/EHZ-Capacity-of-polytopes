import numpy as np
import time
import pickle
import polarvert
import ownLP as lp


#Setters for the matrices.
def setJ(d):
	J = np.zeros((d,d))
	J[0:d/2, d/2:d] = np.eye(d/2)
	J[d/2:d, 0:d/2] = -np.eye(d/2)
	return J

def setF(k):
	F = np.zeros((k,k))
	for i in range(k):
		for j in range(i+1,k):
			F[i,j] = 0.5
			F[j,i] = -0.5
	return F

def setC(vert,k,J):
	C = np.zeros((k,k))
	for i in range(k):
		for j in range(i+1,k):
			temp = vert[j].dot(J.dot(vert[i]))
			C[i,j] = temp
			C[j,i] = -temp
	return C

#Alternative method for input: Load from txt-file.
def loadvert():
	inobj = open('vert.txt')
	data = pickle.load(inobj)
	inobj.close()
	setvert(data)
	
#Calculate biggest imaginary part of eigenvalues of C.
def evC(C):
	vals = np.linalg.eigvals(C).imag
	return np.amax(vals)

#Calculate sum of nonnegative imaginary parts of eigenvalues of F.
def sumEvF(F):
	vals = np.linalg.eigvals(F).imag
	temp = 0
	for num in vals:
		if num >= 0:
			temp += num
	return temp

 
#Return input that models the 2 constraints in format needed for Mosek.
def constraints(vert,k,d):
	
	asub = []
	aval = []
	
	#Constraint matrix
	for i in range(k):
		colsub = []
		colval = []
		
		for j in range(d):		
			val = vert[i][j]
			if abs(val) > 10**(-9):
				colsub += [j]
				colval += [val]
		
		#last entry in each column
		colsub += [d]
		colval += [1.]
		
		#Add column
		asub += [colsub]
		aval += [colval]

	return [asub, aval]

#Main function. Solve k SDPs and determine upper bound for EHZ-capacity.
def main(v_in, verbose = True, input_polar = False):
	
	if input_polar:
		vert = np.array(v_in)
	else:
		vert = np.array(polarvert.getpolvert(v_in))

	k = vert.shape[0]
	d = vert.shape[1]
	J = setJ(d)
	F = setF(k)
	C = setC(vert,k,J)
	
	if verbose:
		tic = time.time()
		print 'Calculation started.'
		
	maximum = 0 
	[asub, aval] = constraints(vert,k,d)
	
	for i in range(k):
		#Objective vector
		c = [0.] * k
		c[i] = 1.
		
		#right hand side in constraints
		b = [0.] * (d + 1)
		b[d] = 1.
	
		lp.setup(c, b, asub, aval, k, d + 1)
		[statcode, optval] = lp.run()
		
		if statcode == 3 or statcode == 4:
			return 0
		
		if statcode == 1 and optval > maximum + 10**(-9):
			maximum = optval
	
	if verbose:		
		toc = time.time() - tic
		print 'Calculation terminated after ' + str(toc) + ' seconds.\n'
	
	mu = evC(C)
	lambdasum = sumEvF(F)
	ubound = mu * lambdasum * (maximum ** 2)
	
	if verbose:
		print 'The calculated upper bound is:'
		print '1/4c(C) <= ' + str(ubound)
	return ubound

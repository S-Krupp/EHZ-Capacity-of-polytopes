import sys
import mosek

# Since the value of infinity is ignored, we define it solely
# for symbolic purposes
inf = 0.0

############################################################
######################### Input ############################
############################################################

# Input SDP should have the following Form:

# max <c,x>
# s.t. Ax = b
#      x >= 0

#Here the following example is initialized:
# c = (1  0  0) ^T
# 
#     / 1 -1  0 \
# A = | 1  1 -1 | ,   b = (0  0  1)^T
#     \ 1  1  1 /


#Fixed parameters
xnum = 3  #number of variables
cnum = 3  #number of constraints

# Bound keys for constraints
bkc = [mosek.boundkey.fx] * cnum

# Bound values for constraints
blc = [0.] * cnum
blc[cnum - 1] = 1.
buc = blc[:]

# Bound keys for variables
bkx = [mosek.boundkey.lo] * xnum

# Bound values for variables
blx = [0.] * xnum
bux = [+inf] * xnum

# Objective coefficients
c = [1., 0., 0.]

# Below is the sparse representation of the A
# matrix stored by column.
asub = [[0, 1, 2],
        [0, 1, 2],
        [1, 2]]
        
aval = [[ 1., 1., 1.],
        [-1., 1., 1.],
        [-1., 1.]]

def setup(newc, newb, newasub, newaval, newxnum, newcnum):
	global c, asub, aval, xnum, cnum, bkc, blc, buc, bkx, blx, bux
	
	c, asub, aval, xnum, cnum = newc, newasub, newaval, newxnum, newcnum
	
	# Bound keys for constraints
	bkc = [mosek.boundkey.fx] * cnum

	# Bound values for constraints
	blc = newb[:]
	buc = newb[:]

	# Bound keys for variables
	bkx = [mosek.boundkey.lo] * xnum

	# Bound values for variables
	blx = [0.] * xnum
	bux = [+inf] * xnum

#############################################################
######################### Mosek #############################
#############################################################

# Define a stream printer to grab output from MOSEK
def streamprinter(text):
    sys.stdout.write(text)
    sys.stdout.flush()


def main():
    global c, b, asub, aval, xnum, cnum, bkc, blc, buc, bkx, blx, bux
    
    # Make mosek environment
    with mosek.Env() as env:
        # Create a task object
        with env.Task(0, 0) as task:
            # Attach a log stream printer to the task
            #task.set_Stream(mosek.streamtype.log, streamprinter)

            # Append 'cnum' empty constraints.
            # The constraints will initially have no bounds.
            task.appendcons(cnum)

            # Append 'xnum' variables.
            # The variables will initially be fixed at zero (x=0).
            task.appendvars(xnum)

            for j in range(xnum):
                # Set the linear term c_j in the objective.
                task.putcj(j, c[j])

                # Set the bounds on variable j
                # blx[j] <= x_j <= bux[j]
                task.putvarbound(j, bkx[j], blx[j], bux[j])

                # Input column j of A
                task.putacol(j,                  # Variable (column) index.
                             asub[j],            # Row index of non-zeros in column j.
                             aval[j])            # Non-zero Values of column j.

            # Set the bounds on constraints.
            # blc[i] <= constraint_i <= buc[i]
            for i in range(cnum):
                task.putconbound(i, bkc[i], blc[i], buc[i])

            # Input the objective sense (minimize/maximize)
            task.putobjsense(mosek.objsense.maximize)

            # Solve the problem
            task.optimize()
            # Print a summary containing information
            # about the solution for debugging purposes
            #task.solutionsummary(mosek.streamtype.msg)

            #Get status information about the solution
            solsta = task.getsolsta(mosek.soltype.bas)

            if (solsta == mosek.solsta.optimal or
                    solsta == mosek.solsta.near_optimal):
				
                xx = [0.] * xnum
                task.getxx(mosek.soltype.bas, # Request the basic solution.
                           xx)
                
                primalobj = task.getprimalobj(mosek.soltype.bas)
                
                return [1,primalobj]
                
                #print("Optimal solution: ")
                #for i in range(xnum):
                #    print("x[" + str(i) + "]=" + str(xx[i]))
            elif (solsta == mosek.solsta.dual_infeas_cer or
                  solsta == mosek.solsta.prim_infeas_cer or
                  solsta == mosek.solsta.near_dual_infeas_cer or
                  solsta == mosek.solsta.near_prim_infeas_cer):
                #print("Primal or dual infeasibility certificate found.\n")
                return [2,0]
            elif solsta == mosek.solsta.unknown:
                #print("Unknown solution status")
                return [3,0]
            else:
                #print("Other solution status")
                return [4,0]

# call the main function
def run():
	try:
	    return main()
	except mosek.Error as e:
	    print("ERROR: %s" % str(e.errno))
	    if e.msg is not None:
	        print("\t%s" % e.msg)
	        sys.exit(1)
	except:
	    import traceback
	    traceback.print_exc()
	    sys.exit(1)


#Example for use of setup:

# newc = [0., 1., 1., 0.]
# newb = [2., 3., 4., 5., 9.]
# newasub = [[0],[1],[2,4],[3,4]]
# newaval = [[1.],[1.],[1.,1.],[1.,1.]]
# newxnum = 4
# newcnum = 5
# print("Test Setup started")
# setup(newc, newb, newasub, newaval, newxnum, newcnum)
# print("Test Setup done!")
# print run()

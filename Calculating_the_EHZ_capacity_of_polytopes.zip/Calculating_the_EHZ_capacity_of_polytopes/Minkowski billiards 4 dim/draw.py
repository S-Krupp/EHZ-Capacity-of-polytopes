import numpy as np
import matplotlib.pyplot as plt

#given two vertices v, w, return hight and outer normalvector of corresponding hyperplane.
#It is necessary to input another vertex x in order to determine what 'outer' means.
#If the two vertices v, w are neighbors, it is clear what 'outer' means
def hyperplane(v, w, x = None):
	v = np.array(v)
	w = np.array(w)
	
	if x == None:
		x = np.zeros(2)
	else:
		x = np.array(x)
		
	n = np.array([w[1] - v[1], v[0] - w[0]])
	h = n.dot(v)
	
	if n.dot(x - v) > -10**(-9):
		n *= -1
		h *= -1
	
	return [n, h]

#Given vertex set, order vertices by adjacency. This function should
#only be called one in the beginning. After that a correct order
#will be maintained.
def ordering(vert):
	
	newvert = [vert[0]]
	
	current = 0
	last = 0
	
	for count in range(len(vert)-1):
		for i in range(len(vert)):
			if i == current or i == last:
				continue
			
			v = vert[i]
			w = vert[current]
			
			[n,h] = hyperplane(v,w)

			#check whether [v,w] is an edge
			sign = 0
			isedge = True
			for j in range(len(vert)):
				if j == i or j == current:
					continue
				
				z = np.array(vert[j])
				height = z.dot(n)
				
				if height > h + 10**(-9):
					if sign == 0:
						sign = 1
					elif sign == -1:
						isedge = False
						break
				elif height < h - 10**(-9):
					if sign == 0:
						sign = -1
					elif sign == 1:
						isedge = False
						break
			
			if isedge:
				newvert += [vert[i]]
				last = current
				current = i
				break
	
	return newvert

#Main routine
def main(vertK,vertT):
	
	plt.close()
	
	orderedK = ordering(vertK)
	orderedT = ordering(vertT)
	
	#plot K:
	x = []
	y = []
	
	for v in orderedK:
		x += [v[0]]
		y += [v[1]]
	
	x += [orderedK[0][0]]
	y += [orderedK[0][1]]
	
	plt.subplot(1,2,1)
	plt.plot(x,y)
	
	#plot T:
	x=[]
	y=[]
	
	for v in orderedT:
		x += [v[0]]
		y += [v[1]]
	
	x += [orderedT[0][0]]
	y += [orderedT[0][1]]
	
	plt.subplot(1,2,2)
	plt.plot(x,y)
	plt.show()


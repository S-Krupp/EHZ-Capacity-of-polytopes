import sys
import numpy as np
import draw as polyDraw
import pickle
import os
import random
import random_poly as rp
from Tkinter import *
import FindBilliards_CVXOPT as ehz

class Application(Frame):
	
	def addCoords(self, entry1, entry2, liste):
		try:
			entry1["background"] = '#ffffff'
			entry2["background"] = '#ffffff'
			e1 = float(entry1.get())
			e2 = float(entry2.get())
			
			if liste is firstList:
				firstList.append((e1, e2))
				self.listbox1.insert(END, ("X: " + entry1.get() + " Y: " + entry2.get()))
			else:
				secondList.append((e1, e2))
				self.listbox2.insert(END, ("X: " + entry1.get() + " Y: " + entry2.get()))
			
			entry1.delete(0, 'end')
			entry2.delete(0, 'end')
			
		except ValueError:
			entry1["background"] = '#ff0000'
			entry2["background"] = '#ff0000'
			print "Error: Input type: Decimal"
			
	def deleteCoords(self, liste, listbox):
		if listbox.curselection():
			index = int(listbox.curselection()[0])
			value = listbox.get(index)
		
			x = value.split(" Y: ")[0].split(' ')[1]
			y = value.split(" Y: ")[1]
			liste.remove((float(x), float(y)))
			
			listbox.delete(index)
			
			#for a in liste:
			#	print a
		else:
			print "Error: No item selected."
		
	def transform(self, liste):
		vertK = np.asarray(liste)
		#print(liste)
		return vertK
		
	def transform2(self, l):
		randomPolytop = []
		for x in l[0]:
			randomPolytop.append(x)
			
		return randomPolytop
		
	def plot(self, vertK, vertT):
		if len(vertK) > 0 and len(vertT) > 0:
			polyDraw.main(vertK, vertT)
			
	def randomPlot(self):
		p1 = self.transform2(rp.main(random.random()))
		p2 = self.transform2(rp.main(random.random()))
		self.toList(p1, p2)
		polyDraw.main(p1, p2)
		
		
	def calculate(self, vertK, vertT):
		print("\n############### Start Calculation ###################\n")
		ehz.main(vertK,vertT)
		
	
	def toList(self, kList, tList):
		global firstList
		global secondList

		firstList = []
		secondList = []
		
		self.listbox1.delete(0, 'end')
		self.listbox2.delete(0, 'end')
		
		for k in kList:
			firstList.append((k[0], k[1]))
			self.listbox1.insert(END, ("X: " + str(k[0]) + " Y: " + str(k[1])))
		for t in tList:
			secondList.append((t[0], t[1]))
			self.listbox2.insert(END, ("X: " + str(t[0]) + " Y: " + str(t[1])))
	
	
	
	def load(self):
		data = open("nodes.txt")
		[kList, tList] = pickle.load(data)
		data.close()
		self.toList(kList, tList)
		
	def save(self, vertK, vertT):
		data = open("nodes.txt", 'w')
		pickle.dump([vertK, vertT], data);
		data.close()
	
	def createWidgets(self):
		self.labelT = Label(self.text, text="Polytope K")
		self.labelT.pack(side='left', anchor='n', padx=50)
		
		self.labelK = Label(self.text, text="Polytope T")
		self.labelK.pack(side='left', anchor='n', padx=40)

		self.entryx1 = Entry(self.inputFrame, width=20)
		self.entryx1.pack(side='left', anchor='n')
		
		self.entryx2 = Entry(self.inputFrame, width=20)
		self.entryx2.pack(side='left', anchor='n')
		
		self.entryy1 = Entry(self.input2Frame, width=20)
		self.entryy1.pack(side='left', anchor='n')
		
		self.entryy2 = Entry(self.input2Frame, width=20)
		self.entryy2.pack(side='left', anchor='n')
		
		self.add1 = Button(self.buttonFrame)
		self.add1["text"] = "Add vertex"
		self.add1["command"] = lambda: self.addCoords(self.entryx1, self.entryy1, firstList)
		self.add1.pack(side='left', anchor='n', padx=30)
		
		self.add2 = Button(self.buttonFrame)
		self.add2["text"] = "Add vertex"
		self.add2["command"] = lambda: self.addCoords(self.entryx2, self.entryy2, secondList)
		self.add2.pack(side='left', anchor='n', padx=30)

		self.listbox1 = Listbox(self.listboxFrame)
		self.listbox1.pack(side='left', anchor='n')
		
		self.listbox2 = Listbox(self.listboxFrame)
		self.listbox2.pack(side='left', anchor='n')
		
		self.loadBtn = Button(self.delete1Frame, text="Load",
           command=lambda: self.load())
		self.loadBtn.pack(side='left')
		
		self.b1 = Button(self.delete1Frame, text="Delete",
           command=lambda: self.deleteCoords(firstList, self.listbox1))
		self.b1.pack(side='left', padx=20)

		self.saveBtn = Button(self.delete2Frame, text="Save",
		   command=lambda: self.save(self.transform(firstList), self.transform(secondList)))
		self.saveBtn.pack(side='right')

		self.b2 = Button(self.delete2Frame, text="Delete",
           command=lambda: self.deleteCoords(secondList, self.listbox2))
		self.b2.pack(side='right', padx=20)
			
		self.plotButton = Button(self.plotFrame, text="Plot", command=lambda: self.plot(self.transform(firstList), self.transform(secondList)))
		self.plotButton.pack(side='left')
		self.plotButton = Button(self.plotFrame, text="Random Plot", command=lambda: self.randomPlot())
		self.plotButton.pack(side='left')
		
		self.calcButton = Button(self.berechnenFrame, text="Calculate", command=lambda: self.calculate(self.transform(firstList), self.transform(secondList)))
		self.calcButton.pack(side='left')
		
		
	def __init__(self, master=None):
		Frame.__init__(self, master)
		self.pack(fill='both')
		
		self.berechnenFrame = Frame(self)
		self.berechnenFrame.pack(side='bottom', anchor='n')
		
		self.plotFrame = Frame(self)
		self.plotFrame.pack(side='bottom', anchor='n')
		
		self.deleteFrame = Frame(self)
		self.deleteFrame.pack(side='bottom', anchor='n')
		
		self.delete1Frame = Frame(self.deleteFrame)
		self.delete1Frame.pack(side='left', anchor='w')
		
		self.delete2Frame = Frame(self.deleteFrame)
		self.delete2Frame.pack(side='bottom', anchor='w')
						
		self.listboxFrame = Frame(self)
		self.listboxFrame.pack(side='bottom', anchor='w')
		
		self.buttonFrame = Frame(self)
		self.buttonFrame.pack(side='bottom', anchor='w')
		
		self.input2Frame = Frame(self)
		self.input2Frame.pack(side='bottom', anchor='w')
		
		self.inputFrame = Frame(self)
		self.inputFrame.pack(side='bottom', anchor='w')
		
		self.text = Frame(self, height=20)
		self.text.pack(side='left')

		
		self.createWidgets()
firstList = []
secondList = []
data = []

def main():
	root = Tk()
	root.title("EHZ")
	root.geometry('329x385+1400+100')
	root.resizable(False, True)
	app = Application(master=root)
	app.mainloop()
main()

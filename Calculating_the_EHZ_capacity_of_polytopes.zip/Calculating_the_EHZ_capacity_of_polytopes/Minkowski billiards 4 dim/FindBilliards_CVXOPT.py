import numpy as np
import scipy.special
import scipy.optimize
import multiprocessing as mp
import time
import cvxpy as cp
import matplotlib.pyplot as plt
import pickle

# Methoden zum Finden minimaler Billiardbahnen mit 2 oder 3 Stosspunkten

#--------------------------------------------------------------------
#------------- Aufbereitung des Polytops K x T ----------------------
#--------------------------------------------------------------------

#Gegeben alle Ecken von K (wahlweise T), finde alle Kanten
def getEdges(vert):
	vertN=vert.shape[0]
	#Anzahl der Kanten wird nach oben abgeschaetzt und spaeter zurecht gesplicet.
	Kanten=np.zeros((int(scipy.special.binom(vertN,2)),2),dtype=int)
	counter=0
	for iv in range(vertN):
		for iw in range(iv+1,vertN):
			v=vert[iv]
			w=vert[iw]
			#Normale und Hoehe der Hyperebene, die durch v,w geht
			normal=np.array([w[1]-v[1],v[0]-w[0]])
			height=normal.dot(v)
			#Check ob Seite vorliegt
			markPos=False
			markNeg=False
			for iz in range(vertN):
				z=vert[iz]
				#An dieser Stelle: Fehlertoleranz
				if not markPos and normal.dot(z)>height+10**(-9):
					markPos=True
				if not markNeg and normal.dot(z)<height-10**(-9):
					markNeg=True
				if markPos and markNeg:
					break
			else:
				#Es liegen keine zwei Ecken auf verschiedenen Seiten der Hyperebene (break wurde nicht getriggert)
				Kanten[counter,:]=[iv,iw]
				counter+=1
	Kanten=Kanten[:counter]
	return Kanten

#Gegen Alle Ecken von K (wahlweise T), unterteile (sample) die Kanten mit Abstand delta und fuege sie Samples zu den Ecken hinzu.
def sampling(vert,delta):
	vertCopy=vert.copy()
	Kanten=getEdges(vert)
	for edge in Kanten:
		v=vert[edge[0]]
		w=vert[edge[1]]
		length=np.linalg.norm(w-v)
		#samples haben Abstand von delta zueinander.
		sampleN=int(np.ceil(length/delta))
		newV=np.zeros((sampleN-1,2))
		for i in range(1,sampleN):
			newPoint=v+i*(delta/length)*(w-v)
			newV[i-1,:]=newPoint
		vertCopy=np.vstack((vertCopy,newV))
	return vertCopy


#--------------------------------------------------------------------
#------------------ Finde 2-Bounce Orbits ---------------------------
#--------------------------------------------------------------------


#Fuer gegebene Ecke finde 2 Ecken, die mit der gegebenen Ecke jeweils eine Kante induzieren.
#Mehrdeutigkeit moeglich wenn mehrere 'Ecken' auf einer Seite liegen. In diesem Setup werden urspruengliche, echte Ecken als Nachbarn gewaehlt.
#Das ist wichtig weil sonst zweimal die selbe Hyperebene gewaehlt werden koennte.
def neighbors(Kanten,iv):
	count=0
	neigh=np.zeros(2,dtype=int)
	for edge in Kanten:
		if iv in edge:
			#Nachbar gefunden, speichere seinen Index
			if iv==edge[0]:
				neigh_ind=edge[1]
			else:
				neigh_ind=edge[0]
			neigh[count]=neigh_ind
			count+=1
			if count>=2:
				break
	return neigh

#Ordne die Ecken zyklisch fuer den Plot.
def ordering(vert):
	ordered = [vert[0]]
	vertorder = [0]
	last = 0
	Kanten = getEdges(vert)
	for i in range(len(vert)-1):
		neigh = neighbors(Kanten,last)
		if neigh[0] not in vertorder:
			vertorder += [neigh[0]]
			last = neigh[0]
		else:
			vertorder += [neigh[1]]
			last = neigh[1]
		ordered += [vert[last]]
	return ordered	

#Gegeben: Ecke und Nachbar; gesucht: aeussere Normale
def outerNormal(vert,iv,i_neigh):
	neigh=vert[i_neigh]
	v=vert[iv]
	n=np.array([neigh[1]-v[1],v[0]-neigh[0]])
	height=n.dot(v)
	for vRun in vert:
		if n.dot(vRun)>height+10**(-9):
			n=-n
			break
		elif n.dot(vRun)<height-10**(-9):
			break
	return n

#Gibt Winkel des eingegebenen Vektors zurueck. (1,0) hat Winkel 0 bzw. 2*pi
def atan2(vec):
	x=float(vec[0])
	y=float(vec[1])
	if x<-10**(-9):
		return np.pi+np.arctan(y/x)
	elif x>10**(-9) and y>=-10**(-9):
		return np.arctan(y/x)
	elif x>10**(-9)  and y<-10**(-9):
		return 2.0*np.pi+np.arctan(y/x)
	elif abs(x)<=10**(-9) and y>10**(-9):
		return np.pi/2.0
	elif abs(x)<=10**(-9) and y<-10**(-9):
		return 3.0*np.pi/2.0
	else:
		print "Error while calling atan2. The input was close to (0,0) which has no angle!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
		return 0.0
		
#Gegeben Winkel, finde Vektor
def angleToVec(angle):
	xVal=np.cos(angle)
	yVal=np.sin(angle)
	return np.array([xVal,yVal])
	
#Gegeben: Ecke und zwei Nachbarn; gesucht: Normalkegel mit Winkeln beschrieben.
#Output ist ein 1x2 Array. Erster Eintrag: Winkel an dem der Kegel beginnt, 2. Eintrag: Winkel an dem er endet.
def normalcone(vert,iv,i_neigh1,i_neigh2):
	n1=outerNormal(vert,iv,i_neigh1)
	n2=outerNormal(vert,iv,i_neigh2)
	angle1=atan2(n1)
	angle2=atan2(n2)
	maxAng=max([angle1,angle2])
	minAng=min([angle1,angle2])
	#Der Normalkegel kann maximal Winkel pi haben (eigentlich < pi). 
	#Ist der Winkel > pi dann schaut man nicht auf den Kegel, sondern auf den Rest von R^2.
	if maxAng-minAng<=np.pi:
		cone=np.array([minAng,maxAng])
	else:
		cone=np.array([maxAng,minAng])
	return cone

#Hilfsfunktion, die einen Winkel um 180 Grad dreht
def turnAngle(ang):
	if ang>=np.pi:
		ang=ang-np.pi
	else:
		ang=ang+np.pi
	return ang

#Funktion die einen (Normal-)Kegel um tol in beide Richtungen erweitert.
def enlargeCone(cone,tol):
	#Bei grosser Toleranz ist der erweiterte Kegel ganz R^2
	if cone[1]>=cone[0] and cone[1]-cone[0]+2*tol>=2*np.pi:
		return np.array([0,2*np.pi])
	elif cone[1]<cone[0] and cone[1]+2*np.pi-cone[0]+2*tol>=2*np.pi:
		return np.array([0,2*np.pi])
	else:
		low=cone[0]-tol
		if low < 0:
			low=2*np.pi-low
		up=cone[1]+tol
		if up>=2*np.pi:
			up=up-2*np.pi
		return np.array([low,up])

#Gegeben zwei Normalenkegeln C1,C2 entscheide, ob der Schnitt von C1 mit -C2 nicht leer ist
def conesIntersect(coneV,coneW):
	coneW=np.array([turnAngle(coneW[0]),turnAngle(coneW[1])])
	#1.Fall: Kegel zu v geht nicht ueber den Winkel 2*pi
	if coneV[1]>=coneV[0]-10**(-9):
		#1.1.Fall: Kegel zu w geht auch nicht uber 2*pi
		if coneW[1]>=coneW[0]-10**(-9):
			#False, falls Kegel zu w vor oder hinter dem von v liegt.
			if coneW[1]<coneV[0]-10**(-9):
				return False
			elif coneW[0]>coneV[1]+10**(-9):
				return False
			else:
				return True
		#1.2.Fall: Kegel zu w geht ueber 2*pi
		else:
			if coneW[1]<coneV[0]-10**(-9) and coneW[0]>coneV[1]+10**(-9):
				return False
			else:
				return True
	#2. Fall: Kegel zu v geht ueber Winkel 2*pi. Wenn Kegel zu w auch drueber geht, dann True
	else:
		if coneV[1]<coneW[0]-10**(-9) and coneW[0]<=coneW[1]+10**(-9) and coneW[1]<coneV[0]-10**(-9):
			return False
		else:
			return True

#Berechnet den Schnitt zweier Kegel C1 und -C2. Hier wird Input und Output durch Winkel dargestellt. Zudem wird ein Boolean ausgegeben:
#Ist der Schnitt leer: False; sonst: True.
#Siehe auch: conesIntersect (Output dort ist nur der Boolean)
def coneIntersection(coneV,coneW,minus=True):
	coneOut=np.zeros((2))
	if minus:
		coneW=np.array([turnAngle(coneW[0]),turnAngle(coneW[1])])
	#1.Fall: Kegel zu v geht nicht ueber den Winkel 2*pi
	if coneV[1]>=coneV[0]-10**(-9):
		#1.1.Fall: Kegel zu w geht auch nicht uber 2*pi
		if coneW[1]>=coneW[0]-10**(-9):
			#False, falls Kegel zu w vor oder hinter dem von v liegt.
			if coneW[1]<coneV[0]-10**(-9):
				return [False,coneOut]
			elif coneW[0]>coneV[1]+10**(-9):
				return [False,coneOut]
			else:
				#Kegel schneiden sich
				coneOut[0]=max(coneV[0],coneW[0])
				coneOut[1]=min(coneV[1],coneW[1])
				return [True,coneOut]
		#1.2.Fall: Kegel zu w geht ueber 2*pi
		else:
			if coneW[1]<coneV[0]-10**(-9) and coneW[0]>coneV[1]+10**(-9):
				return False
			else:
				#Kegel schneiden sich.
				if coneV[0]<=coneW[1]+10**(-9):
					coneOut[0]=coneV[0]
					coneOut[1]=min(coneV[1],coneW[1])
					return [True,coneOut]
				else:
					coneOut[0]=max(coneV[0],coneW[0])
					coneOut[1]=coneV[1]
					return [True,coneOut]
	#2.Fall: Kegel zu v geht ueber Winkel 2*pi. Wenn Kegel zu w auch drueber geht, dann True
	else:
		if coneV[1]<coneW[0]-10**(-9) and coneW[0]<=coneW[1]+10**(-9) and coneW[1]<coneV[0]-10**(-9):
			return False
		else:
			#Kegel schneiden sich.
			#2.1.Fall: Kegel zu w beginnt vor dem zu v ...
			if coneW[0]<=coneV[0]+10**(-9) and coneW[0]>coneV[1]+10**(-9):
				coneOut[0]=coneV[0]
				#...und endet in dem Kegel zu v.
				if coneW[1]>=coneW[0]-10**(-9) or coneW[1]<=coneV[1]+10**(-9):
					coneOut[1]=coneW[1]
					return [True,coneOut]
				#...und endet nach dem Kegel zu v.
				else:
					coneOut[1]=coneV[1]
					return [True,coneOut]
			#2.2.Fall: Kegel zu w beginnt frueh nach dem zu v ...
			elif coneW[0]>coneV[0]+10**(-9):
				coneOut[0]=coneW[0]
				#...und endet in dem Kegel zu v.
				if coneW[1]>=coneW[0]-10**(-9) or coneW[1]<=coneV[1]+10**(-9):
					coneOut[1]=coneW[1]
					return [True,coneOut]
				#...und endet nach dem Kegel zu v.
				else:
					coneOut[1]=coneV[1]
					return [True,coneOut]
			#2.3.Fall: Kegel zu w beginnt spaet nach dem zu v ...
			else:
				#...und endet in dem Kegel zu v.
				if coneW[1]<=coneV[1]+10**(-9):
					coneOut[1]=coneW[1]
					return [True,coneOut]
				#...und endet nach dem Kegel zu v.
				else:
					coneOut[1]=coneV[1]
					return [True,coneOut]

#Gegeben zwei Ecken (als Indizes) von K (wahlweise T), entscheide ob sich ihre Normalkegel schneiden (dann gib True aus, sonst False)
#Setze vIsPos=False, falls man am Schnitt von -Nv mit Nw interessiert ist, sonst 1. Analog mit wIsPos.
#tol ist fuer die Toleranz. Einer der Normalkegel (welcher ist egal) wird um tol in beide Richtungen erweitert.
#Es wird nur ein Kegel erweitert um die Toleranz konsistent zu halten mit isInCone().
#def conesIntersect(vertV,vertW,iv,iw,vIsPos,wIsPos,tol):
#	KantenV=getEdges(vertV)
#	KantenW=getEdges(vertW)
#	neighV=neighbors(KantenV,iv)
#	neighW=neighbors(KantenW,iw)
#	ConeV=normalcone(vertV,iv,neighV[0],neighV[1])
#	ConeW=normalcone(vertW,iw,neighW[0],neighW[1])
#	if not vIsPos:
#		ConeV=np.array([turnAngle(ConeV[0]),turnAngle(ConeV[1])])
#	if not wIsPos:
#		ConeW=np.array([turnAngle(ConeW[0]),turnAngle(ConeW[1])])
#	ConeV=enlargeCone(ConeV,tol)
#	#1.Fall: Kegel zu v geht nicht ueber den Winkel 2*pi
#	if ConeV[1]>=ConeV[0]:
#		#1.1.Fall: Kegel zu w geht auch nicht uber 2*pi
#		if ConeW[1]>=ConeW[0]:
#			#False, falls Kegel zu w vor oder hinter dem von v liegt.
#			if ConeW[1]<ConeV[0]:
#				return False
#			elif ConeW[0]>ConeV[1]:
#				return False
#			else:
#				return True
#		#1.2.Fall: Kegel zu w geht ueber 2*pi
#		else:
#			if ConeW[1]<ConeV[0] and ConeW[0]>ConeV[1]:
#				return False
#			else:
#				return True
#	#2. Fall: Kegel zu v geht ueber Winkel 2*pi. Wenn Kegel zu w auch drueber geht, dann True
#	else:
#		if ConeV[1]<ConeW[0] and ConeW[0]<=ConeW[1] and ConeW[1]<ConeV[0]:
#			return False
#		else:
#			return True
						
#Testet ob ein Vektor im Normalenkegel liegt
def isInCone(normals,iv,vec):
	ConeV=normals[iv]
	angVec=atan2(vec)
	#1.Fall: Kegel zu v geht nicht ueber den Winkel 2*pi
	if ConeV[1]>=ConeV[0]-10**(-9):
		#False, falls Kegel zu w vor oder hinter dem von v liegt.
		if angVec<ConeV[0]-10**(-9):
			return False
		elif angVec>ConeV[1]+10**(-9):
			return False
		else:
			return True
	#2. Fall: Kegel zu v geht ueber Winkel 2*pi.
	else:
		if ConeV[1]<angVec-10**(-9) and angVec<ConeV[0]-10**(-9):
			return False
		else:
			return True
			
#def isInCone(vert,iv,vec,tol):
#	Kanten=getEdges(vert)
#	neighV=neighbors(Kanten,iv)
#	ConeV=normalcone(vert,iv,neighV[0],neighV[1])
#	angVec=atan2(vec)
#	ConeV=enlargeCone(ConeV,tol)
#	#1.Fall: Kegel zu v geht nicht ueber den Winkel 2*pi
#	if ConeV[1]>=ConeV[0]:
#		#False, falls Kegel zu w vor oder hinter dem von v liegt.
#		if angVec<ConeV[0]:
#			return False
#		elif angVec>ConeV[1]:
#			return False
#		else:
#			return True
#	#2. Fall: Kegel zu v geht ueber Winkel 2*pi.
#	else:
#		if ConeV[1]<angVec and angVec<ConeV[0]:
#			return False
#		else:
#			return True

#gegeben Kanten und Ecken, gib ein Array der Form [alle Ecken, alle Kanten] aus
def stackFaces(vert,edges,vertNum,faceNum):
	faces=np.zeros((faceNum,2))
	for i in range(vertNum):
		faces[i]=vert[i]
	for j in range(vertNum,faceNum):
		faces[j]=edges[j-vertNum]
	return faces
	
#Gegeben: Vektor auf den Rand (egal ob auf Kante oder Ecke); Gesucht: Normalkegel
def normalConeMultifunc(vert,Kanten,vec,tolerance=10**(-9)):
	#Teste ob Vektor Ecke ist
	vertNum=vert.shape[0]
	for iu in range(vertNum):
		u=vert[iu]
		if np.linalg.norm(u-vec)<10**(-9):
			#vec ist Ecke. Zugriff auf vorherige Funktionen moeglich.
			neighs=neighbors(Kanten,iu)
			return normalcone(vert,iu,neighs[0],neighs[1])
	for e in Kanten:
		n=outerNormalEdge(vert,e)
		height=n.dot(vert[e[0]])
		if abs(height-n.dot(vec))<=tolerance:
			#vec liegt auf Kante e
			angleNormal=atan2(n)
			return[angleNormal,angleNormal]
	print 'Error in normalConeMultifunc; vec seems to be an interior point!!!!!!!'
	return 0

#Konstruiert ein Array mit Normalenvektoren/-kegeln, gegeben durch Winkel. Ein Kegel fuer jede Ecke und jede Kante
def normalArray(vert,edges,vertNum,faceNum):
	normals=np.zeros((faceNum,2))
	for i in range(vertNum):
		normals[i]=normalConeMultifunc(vert,edges,vert[i])
	for j in range(vertNum,faceNum):
		v=vert[edges[j-vertNum,0]]
		w=vert[edges[j-vertNum,1]]
		normals[j]=normalConeMultifunc(vert,edges,0.5*v+0.5*w)
	return normals
	
#Konstruiert analog zu normalArray() ein Array mit den Hoehen. Ecken haben die 'Hoehe' 0 per default.
def heightsArray(vert,edges,vertNum,faceNum,normals):
	heights=np.zeros(faceNum)
	for j in range(vertNum,faceNum):
		v=vert[edges[j-vertNum,0]]
		n=angleToVec(normals[j,0])
		heights[j]=v.dot(n)
	return heights

#Gibt 1 aus, wenn die indizierte Seite eine Ecke ist und sonst 0.
def isVertex(index,vertNum):
	if index<vertNum:
		return 1
	else:
		return 0

#modelliert die Ungleichungen in find orbitFullEdge. Gegeben ineqLeft,ineqRight werden Ungleichungen zur Modellierung von 'v in K' ab Zeile rowCount und
#in Spalten columns eingefuegt. Output: ineqLeft,ineqRight,rowCount (updated), 
def modelIneqs(ineqLeft,ineqRight,normals,heights,vertNum,faceNum,avoidIndices,rowCount,columns):
	for ind in range(vertNum,faceNum):
		if ind in avoidIndices:
			continue
		nAngle=normals[ind,0]
		n=angleToVec(nAngle)
		ineqLeft[rowCount,columns]=n
		ineqRight[rowCount]=heights[ind]
		rowCount+=1
	return [ineqLeft,ineqRight,rowCount]

#Gegeben: Array von Winkeln. Jede Zeile besteht aus 2x dem selben Winkel
#Output: ein Array, dass die zugehoerigen Einheitsvektoren enthaelt.
def processAngleArray(arr):
	vectors=np.zeros(arr.shape)
	for i in range(arr.shape[0]):
		vectors[i]=angleToVec(arr[i,0])
	return vectors

#Diese Funktion findet einen Orbit mit Stosspunkten auf 4 gewaehlten Seiten (Kanten oder Ecken), je 2 pro K und T. In K und T muss je mind. eine
#Kante ausgewaehlt worden sein. Output: [True,orbit], falls Orbit gefunden and [False,...] sonst.
#Input: faceIndicesK/T = Array mit den 4 gewaehlten Seiten-Indizes (je 2x1)
#normalsK/T, heightsK/T = Arrays mit allen Normalenvektoren und Hoehen. Normalenkegel zu Ecken werden nicht benoetigt. (Haben edgeNumK/T viele Zeilen)
#vertNumK, vertNumT, facesK, facesT, edgeNumK, edgeNumT
def findOrbitFullEdge(faceIndicesK,faceIndicesT,normalsK,normalsT,heightsK,heightsT,vertNumK,vertNumT,edgeNumK,edgeNumT,facesK,facesT):
	#Equations: eqLeft*x=eqRight
	#Inequalities: ineqLeft*x<=ineqRight
	orbit=np.zeros((4,2))
	pointFound=4*[False]
	eqLeft=np.zeros((8,10))
	eqRight=np.zeros(8)
	#Ersten 2 Gleichungen: p_i-p_j=alpha*v_i, q_i-q_j=beta*w_i
	eqLeft[0:2,4:8]=np.hstack([-np.eye(2),np.eye(2)])
	eqLeft[2:4,0:4]=np.hstack([-np.eye(2),np.eye(2)])
	eqCounter=4
	ineqCounter=0
	faceNumK=vertNumK+edgeNumK
	faceNumT=vertNumT+edgeNumT
	#Man hat in dieser Funktion immer die zwei obigen Variablen alpha,beta
	variableNum=2
	for ind1 in faceIndicesK:
		if ind1>=vertNumK:
			variableNum+=2
	for ind2 in faceIndicesT:
		if ind2>=vertNumT:
			variableNum+=2
	ineqLeft=np.zeros((2*edgeNumK+2*edgeNumT,variableNum))
	ineqRight=np.zeros(2*edgeNumK+2*edgeNumT)
	#Fuer jede der gewaehlten Seiten, die eine Kante ist, wird eine Zeile hinzugefuegt. Fuer jede, die eine Ecke ist, wird eine Spalte geloescht.
	#Ausserdem sind je mind. 1 der gewaehlten Seiten von T & K eine Kante. Diese beeinflusst die ersten 4 Zeilen.
	deleteHelper=4*[False]
	#Anpassungen fuer K:
	if faceIndicesK[0]<vertNumK:
		#1. Seite von K ist Ecke => 2. ist Kante
		q1=facesK[faceIndicesK[0]]
		orbit[0,:]=q1
		pointFound[0]=True
		eqRight[2:4]=q1
		v2=angleToVec(normalsK[faceIndicesK[1],0])
		eqLeft[[0,1],9]=-v2
		deleteHelper[0]=True
		eqLeft[eqCounter,2:4]=v2
		eqRight[eqCounter]=heightsK[faceIndicesK[1]]
		eqCounter+=1
		#Ungleichungen fuer q2:
		ineqBuffer=modelIneqs(ineqLeft,ineqRight,normalsK,heightsK,vertNumK,faceNumK,[faceIndicesK[1]],ineqCounter,[0,1])
		ineqLeft=ineqBuffer[0]
		ineqRight=ineqBuffer[1]
		ineqCounter=ineqBuffer[2]
	elif faceIndicesK[1]<vertNumK:
		#2. Seite von K ist Ecke => 1. ist Kante
		q2=facesK[faceIndicesK[1]]
		orbit[1,:]=q2
		pointFound[1]=True
		eqRight[2:4]=-q2
		v1=angleToVec(normalsK[faceIndicesK[0],0])
		eqLeft[[0,1],9]=v1
		deleteHelper[1]=True
		eqLeft[eqCounter,0:2]=v1
		eqRight[eqCounter]=heightsK[faceIndicesK[0]]
		eqCounter+=1
		#Ungleichungen fuer q1:
		ineqBuffer=modelIneqs(ineqLeft,ineqRight,normalsK,heightsK,vertNumK,faceNumK,[faceIndicesK[0]],ineqCounter,[0,1])
		ineqLeft=ineqBuffer[0]
		ineqRight=ineqBuffer[1]
		ineqCounter=ineqBuffer[2]
	else:
		#Beide Seiten von K sind Kanten.
		v1=angleToVec(normalsK[faceIndicesK[0],0])
		v2=angleToVec(normalsK[faceIndicesK[1],0])
		eqLeft[[0,1],9]=v1
		eqLeft[eqCounter,0:2]=v1
		eqRight[eqCounter]=heightsK[faceIndicesK[0]]
		eqLeft[eqCounter+1,2:4]=v2
		eqRight[eqCounter+1]=heightsK[faceIndicesK[1]]
		eqCounter+=2
		#Ungleichungen fuer q1 & q2:
		for j in range(2):
			ineqBuffer=modelIneqs(ineqLeft,ineqRight,normalsK,heightsK,vertNumK,faceNumK,[faceIndicesK[j]],ineqCounter,[2*j,2*j+1])
			ineqLeft=ineqBuffer[0]
			ineqRight=ineqBuffer[1]
			ineqCounter=ineqBuffer[2]
	#Anpassungen fuer T:
	if faceIndicesT[0]<vertNumT:
		#1. Seite von T ist Ecke => 2. ist Kante
		p1=facesT[faceIndicesT[0]]
		orbit[2,:]=p1
		pointFound[2]=True
		eqRight[0:2]=p1
		w2=angleToVec(normalsT[faceIndicesT[1],0])
		eqLeft[[2,3],8]=-w2
		deleteHelper[2]=True
		eqLeft[eqCounter,6:8]=w2
		eqRight[eqCounter]=heightsT[faceIndicesT[1]]
		eqCounter+=1
		#Ungleichungen fuer p2:
		ineqBuffer=modelIneqs(ineqLeft,ineqRight,normalsT,heightsT,vertNumT,faceNumT,[faceIndicesT[1]],ineqCounter,[variableNum-4,variableNum-3])
		ineqLeft=ineqBuffer[0]
		ineqRight=ineqBuffer[1]
		ineqCounter=ineqBuffer[2]
	elif faceIndicesT[1]<vertNumT:
		#2. Seite von K ist Ecke => 1. ist Kante
		p2=facesT[faceIndicesT[1]]
		orbit[3,:]=p2
		pointFound[3]=True
		eqRight[0:2]=-p2
		w1=angleToVec(normalsT[faceIndicesT[0],0])
		eqLeft[[2,3],8]=w1
		deleteHelper[3]=True
		eqLeft[eqCounter,4:6]=w1
		eqRight[eqCounter]=heightsT[faceIndicesT[0]]
		eqCounter+=1
		#Ungleichungen fuer p2:
		ineqBuffer=modelIneqs(ineqLeft,ineqRight,normalsT,heightsT,vertNumT,faceNumT,[faceIndicesT[0]],ineqCounter,[variableNum-4,variableNum-3])
		ineqLeft=ineqBuffer[0]
		ineqRight=ineqBuffer[1]
		ineqCounter=ineqBuffer[2]
	else:
		#Beide Seiten von K sind Kanten.
		w1=angleToVec(normalsT[faceIndicesT[0],0])
		w2=angleToVec(normalsT[faceIndicesT[1],0])
		eqLeft[[2,3],8]=w1
		eqLeft[eqCounter,4:6]=w1
		eqRight[eqCounter]=heightsT[faceIndicesT[0]]
		eqLeft[eqCounter+1,6:8]=w2
		eqRight[eqCounter+1]=heightsT[faceIndicesT[1]]
		eqCounter+=2
		#Ungleichungen fuer p1 & p2:	
		for k in range(2):
			ineqBuffer=modelIneqs(ineqLeft,ineqRight,normalsT,heightsT,vertNumT,faceNumT,[faceIndicesT[k]],ineqCounter,[variableNum-4-2*k,variableNum-3-2*k])
			ineqLeft=ineqBuffer[0]
			ineqRight=ineqBuffer[1]
			ineqCounter=ineqBuffer[2]
	#loesche Spalten und ueberfluessige Zeilen
	ineqLeft=ineqLeft[:ineqCounter,:]
	ineqRight=ineqRight[:ineqCounter]
	eqLeft=eqLeft[:eqCounter,:]
	eqRight=eqRight[:eqCounter]
	deleter=0
	while deleter<len(deleteHelper):
		if deleteHelper[deleter]:
			eqLeft=np.delete(eqLeft,[2*deleter,2*deleter+1],1)
			del deleteHelper[deleter]
		else:
			deleter+=1
	bounds=((0,None),(0,None))
	for var in range(variableNum-2):
		bounds=((None,None),)+bounds
	#Finde eine Loesung, die Gleichungen und Ungleichungen erfuellt und mit alpha,beta>=0 (wobei '= 0' nie gelten kann)
	#solution=Simplex.solveOpt(np.zeros(variableNum),ineqLeft,ineqRight,eqLeft,eqRight,bounds)
	
	x=cp.Variable(variableNum)
	c=np.zeros(variableNum)
	constraints = [ineqLeft*x<=ineqRight, eqLeft*x==eqRight, x[variableNum-1]>=0, x[variableNum-2]>=0]
	obj = cp.Maximize(c*x)
	prob = cp.Problem(obj, constraints)
	prob.solve(solver=cp.CVXOPT)
	
	if prob.status!='optimal':
		return [False,orbit]
	else:
		#vervollstaendige orbit
		currentEval=0
		for i in range(4):
			if not pointFound[i]:
				orbit[i,:]=np.array([x.value[currentEval],x.value[currentEval+1]])
				currentEval+=2
		return [True,orbit]

#Berechnung der Wirkung:	
def calcAction(orbit):
	q1=orbit[0,:]
	q2=orbit[1,:]
	p1=orbit[2,:]
	p2=orbit[3,:]
	return p2.dot(q2-q1)-p1.dot(q2-q1)

#Wird gecallt wenn ueberprueft werden soll, ob 4 Ecken einen Orbit bilden. Output: True falls ja, False falls nein.
def findOrbitNoEdge(faceIndicesK,faceIndicesT,normalsK,normalsT,facesK,facesT):
	q1=facesK[faceIndicesK[0]]
	q2=facesK[faceIndicesK[1]]
	p1=facesT[faceIndicesT[0]]
	p2=facesT[faceIndicesT[1]]
	if not isInCone(normalsT,faceIndicesT[1],q2-q1):
		return False
	elif not isInCone(normalsT,faceIndicesT[0],q1-q2):
		return False
	elif not isInCone(normalsK,faceIndicesK[1],p2-p1):
		return False
	elif not isInCone(normalsK,faceIndicesK[0],p1-p2):
		return False
	else:
		return True

#Diese Funktion findet einen Orbit mit Stosspunkten auf 4 gewaehlten Seiten (Kanten oder Ecken), je 2 pro P und Q. Beide Stosspunkte in P sind Ecken.
#Output: [True,orbit], falls Orbit gefunden and [False,...] sonst.
#Input: faceIndicesP/Q = Array mit den 4 gewaehlten Seiten-Indizes (je 2x1)
#normalsP/Q, heightsP/Q = Arrays mit allen Normalenvektoren und Hoehen. Normalenkegel zu Ecken werden nicht benoetigt. (Haben edgeNumP/Q viele Zeilen)
#vertNumP/Q, facesP/Q, edgeNumP/Q
#PisK=True falls (P,Q)=(K,T) und False, falls (P,Q)=(T,K)
def findOrbitHalfEdge(faceIndicesP,faceIndicesQ,normalsP,normalsQ,heightsP,heightsQ,vertNumP,vertNumQ,edgeNumP,edgeNumQ,facesP,facesQ,PisK):
	orbit=np.zeros((4,2))
	q1=facesP[faceIndicesP[0]]
	q2=facesP[faceIndicesP[1]]
	isEdge=[False,False]
	normalvec=np.zeros((2,2))
	edgeCount=0
	for i in range(2):
		if faceIndicesQ[i]>=vertNumQ:
			#i-te Seite aus Q ist eine Kante
			isEdge[i]=True
			#normalvec enthaelt den Normalenvektor der i-ten Seite (i=0;1 bzw =1;2) aus Q, falls diese eine Kante ist.
			normalvec[i]=angleToVec(normalsQ[faceIndicesQ[i],0])
			edgeCount+=1
	#Testen, ob q1-q2 bzw q2-q1 bereits einen Orbit ausschliessen und gleichzeitig die Gleichheitsbedingungen modellieren
	eqLeft=np.zeros((edgeCount,2*edgeCount))
	eqRight=np.zeros(edgeCount)
	if isEdge[0]:
		checkAngle=atan2(q1-q2)
		w1Ang=normalsQ[faceIndicesQ[0],0]
		if abs(checkAngle-w1Ang)>10**(-9):
			#Orbit nicht moeglich.
			return [False,orbit]
		w1=angleToVec(w1Ang)
		eqLeft[0,0:2]=w1
		eqRight[0]=heightsQ[faceIndicesQ[0]]
	if isEdge[1]:
		checkAngle=atan2(q2-q1)
		w2Ang=normalsQ[faceIndicesQ[1],0]
		if abs(checkAngle-w2Ang)>10**(-9):
			#Orbit nicht moeglich.
			return [False,orbit]
		w2=angleToVec(w2Ang)
		eqLeft[edgeCount-1,2*edgeCount-2:2*edgeCount]=w2
		eqRight[edgeCount-1]=heightsQ[faceIndicesQ[1]]
	#Ungleichungen modellieren:
	ineqLeft=np.zeros((2*vertNumP+edgeCount*edgeNumQ,2*edgeCount))
	ineqRight=np.zeros(2*vertNumP+edgeCount*edgeNumQ)
	ineqCount=0
	#Durch Ecken indizierte Ungleichungen
	if edgeCount==2:
		for vertInd in range(vertNumP):
			if vertInd!=faceIndicesP[0]:
				v=facesP[vertInd]
				ineqLeft[ineqCount]=np.hstack([v-q1,q1-v])
				ineqCount+=1
			if vertInd!=faceIndicesP[1]:
				v=facesP[vertInd]
				ineqLeft[ineqCount]=np.hstack([q2-v,v-q2])
				ineqCount+=1	
	elif isEdge[0]:
		#p1 ist eine Variable, p2 aber nicht:
		p2=facesQ[faceIndicesQ[1]]
		for vertInd in range(vertNumP):
			if vertInd!=faceIndicesP[0]:
				v=facesP[vertInd]
				ineqLeft[ineqCount]=v-q1
				ineqRight[ineqCount]=p2.dot(v-q1)
				ineqCount+=1
			if vertInd!=faceIndicesP[1]:
				v=facesP[vertInd]
				ineqLeft[ineqCount]=q2-v
				ineqRight[ineqCount]=p2.dot(q2-v)
				ineqCount+=1
	else:
		#p2 ist eine Variable, p1 aber nicht:
		p1=facesQ[faceIndicesQ[0]]
		for vertInd in range(vertNumP):
			if vertInd!=faceIndicesP[0]:
				v=facesP[vertInd]
				ineqLeft[ineqCount]=q1-v
				ineqRight[ineqCount]=p1.dot(q1-v)
				ineqCount+=1
			if vertInd!=faceIndicesP[1]:
				v=facesP[vertInd]
				ineqLeft[ineqCount]=v-q2
				ineqRight[ineqCount]=p1.dot(v-q2)
				ineqCount+=1
	#Durch Kanten indizierte Ungleichungen
	if isEdge[0]:
		bufferIneqLeft=normalsQ[vertNumQ:]
		bufferIneqLeft=processAngleArray(bufferIneqLeft)
		bufferIneqRight=heightsQ[vertNumQ:]
		bufferIneqLeft=np.delete(bufferIneqLeft,faceIndicesQ[0]-vertNumQ,0)
		bufferIneqRight=np.delete(bufferIneqRight,faceIndicesQ[0]-vertNumQ)
		ineqLeft[ineqCount:ineqCount+edgeNumQ-1,0:2]=bufferIneqLeft
		ineqRight[ineqCount:ineqCount+edgeNumQ-1]=bufferIneqRight
		ineqCount+=edgeNumQ-1
	if isEdge[1]:
		bufferIneqLeft=normalsQ[vertNumQ:]
		bufferIneqLeft=processAngleArray(bufferIneqLeft)
		bufferIneqRight=heightsQ[vertNumQ:]		
		bufferIneqLeft=np.delete(bufferIneqLeft,faceIndicesQ[1]-vertNumQ,0)
		bufferIneqRight=np.delete(bufferIneqRight,faceIndicesQ[1]-vertNumQ)
		ineqLeft[ineqCount:ineqCount+edgeNumQ-1,2*edgeCount-2:2*edgeCount]=bufferIneqLeft
		ineqRight[ineqCount:ineqCount+edgeNumQ-1]=bufferIneqRight
		ineqCount+=edgeNumQ-1
	#Irrelevante Zeilen entfernen:
	ineqLeft=ineqLeft[:ineqCount]
	ineqRight=ineqRight[:ineqCount]
	#Finde eine Loesung, die Gleichungen und Ungleichungen erfuellt
	#solution=Simplex.solveOpt(np.zeros(edgeCount*2),ineqLeft,ineqRight,eqLeft,eqRight)
	
	x=cp.Variable(edgeCount*2)
	c=np.zeros(edgeCount*2)
	constraints = [ineqLeft*x<=ineqRight, eqLeft*x==eqRight]
	obj = cp.Maximize(c*x)
	prob = cp.Problem(obj, constraints)
	prob.solve(solver=cp.CVXOPT)
	
	if prob.status!='optimal':
		return [False,orbit]
	#if not solution[0]:
	#	return [False,orbit]
	else:
		#setze orbit
		orbit[0]=q1
		orbit[1]=q2
		currentEval=0
		for ind in range(2):
			if isEdge[ind]:
				orbit[ind+2]=np.array([x.value[currentEval],x.value[currentEval+1]])
				currentEval+=2
			else:
				orbit[ind+2]=facesQ[faceIndicesQ[ind]]
		if not PisK:
			bufferArray=orbit[[0,1]]
			orbit[[0,1]]=orbit[[2,3]]
			orbit[[2,3]]=bufferArray
		return [True,orbit]

#Takes p (q) on lines between v and w (x and y) and moves them in direction direc a little. 
def moveToInt(p,q,v,w,x,y,direc):
	#Find towards whitch points p and q are moving:
	moveAng=atan2(direc)
	if np.linalg.norm(atan2(w-v)-moveAng)<10**(-9):
		destP=w
	else:
		destP=v
	if np.linalg.norm(atan2(y-x)-moveAng)<10**(-9):
		destQ=y
	else:
		destQ=x
	#Calculate alpha s.th.: q+alpha*direc is a vertex. Same for p.
	if abs(direc[0])>10**(-9):
		nonzeroInd=0
	else:
		nonzeroInd=1
	alphaP=(destP[nonzeroInd]-p[nonzeroInd])/direc[nonzeroInd]
	alphaQ=(destQ[nonzeroInd]-q[nonzeroInd])/direc[nonzeroInd]
	movingFac=min(alphaP,alphaQ)/2
	return [p+movingFac*direc,q+movingFac*direc]

#Given orbit on the edges e1, e2 in K, search for similar orbit but with points in the interior of e1, e2.
#Return Boolean whether search was successful and return found orbit
def modifyOrbit(q1,q2,p1,p2,e1,e2,vertK,normalCone_p1,normalCone_p2,normalAng_q2,height_q2):
	e1_int=e1.astype(int)
	e2_int=e2.astype(int)
	q1IsVert=False
	q2IsVert=False
	#q1 lies on e1=(v,w) with q1=v if q1 is a vertex; same for q2: e2=(x,y) and q2=x if q2 is vert.
	if np.linalg.norm(q1-vertK[e1_int[0]])<10**(-9):
		v=vertK[e1_int[0]]
		w=vertK[e1_int[1]]
		q1IsVert=True
	elif np.linalg.norm(q1-vertK[e1_int[1]])<10**(-9):
		v=vertK[e1_int[1]]
		w=vertK[e1_int[0]]
		q1IsVert=True
	else:
		v=vertK[e1_int[0]]
		w=vertK[e1_int[1]]
		q1IsVert=False
	if np.linalg.norm(q2-vertK[e2_int[0]])<10**(-9):
		x=vertK[e2_int[0]]
		y=vertK[e2_int[1]]
		q2IsVert=True
	elif np.linalg.norm(q2-vertK[e2_int[1]])<10**(-9):
		x=vertK[e2_int[1]]
		y=vertK[e2_int[0]]
		q2IsVert=True
	else:
		x=vertK[e2_int[0]]
		y=vertK[e2_int[1]]
		q2IsVert=False
	#Check whether orbit is already regular:
	if not q1IsVert and not q2IsVert:
		orbit=np.vstack([q1,q2,p1,p2])
		return [True,orbit]
	#Try to move orbit by translation:
	elif q1IsVert and not q2IsVert:
		moveDirec=w-v
		movedQ=moveToInt(q1,q2,v,w,x,y,moveDirec)
		orbit=np.vstack([movedQ[0],movedQ[1],p1,p2])
		return [True,orbit]
	elif not q1IsVert and q2IsVert:
		moveDirec=y-x
		movedQ=moveToInt(q1,q2,v,w,x,y,moveDirec)
		orbit=np.vstack([movedQ[0],movedQ[1],p1,p2])
		return [True,orbit]
	else:
		moveq1=w-v
		moveq2=y-x
		if abs(atan2(moveq1)-atan2(moveq2))<10**(-9):
			movedQ=moveToInt(q1,q2,v,w,x,y,moveq1)
			orbit=np.vstack([movedQ[0],movedQ[1],p1,p2])
			return [True,orbit]
		else:
			#q1 q2 both are vertices and translation is not possible. Find new orbit (q1,q2',...) where q2 was moved.
			#Range of angles for q2'-q1 such that q2' stays on edge.
			angle1=atan2(x-v)
			angle2=atan2(y-v)
			if angle2>=angle1 and angle2-angle1<np.pi+10**(-9):
				coneW=[angle1,angle2]
			elif angle2<angle1 and 2*np.pi+angle2-angle1<np.pi+10**(-9):
				coneW=[angle1,angle2]
			else:
				coneW=[angle2,angle1]
			intersectOut=coneIntersection(coneW,normalCone_p1)
			if not intersectOut[0]:
				print 'Error in modifyOrbit(). Tried to intersect two disjoint cones. They should have nonempty intersection though!!!'
				return 0
			intersOne=intersectOut[1]
			intersectOut=coneIntersection(intersOne,normalCone_p2,False)
			if not intersectOut[0]:
				print 'Error in modifyOrbit(). Tried to intersect two disjoint cones. They should have nonempty intersection though!!!'
				return 0
			intersTwo=intersectOut[1]
			if abs(intersTwo[0]-intersTwo[1])<10**(-9):
				#Can't find another choice for q2-q1. On these two edges and with respect two p1 and p2, q1 and q2 are unique.
				orbit=np.vstack([q1,q2,p1,p2])
				return [False,orbit]
			else:
				#Can find another choice for q2-q1. Move q2 and run again in order to move q1 as well.
				normal_q2=angleToVec(normalAng_q2)
				if intersTwo[1]<intersTwo[0]-10**(-9):
					intersTwo[1]+=2*np.pi
				newAngle=(intersTwo[0]+intersTwo[1])/2
				if newAngle>2*np.pi+10**(-9):
					newAngle-=2*np.pi
				fromq1Toq2=angleToVec(newAngle)
				#Given direction q2'-q1 and face on whitch q2' should lie, find q2'
				factor=(height_q2-q1.dot(normal_q2))/(fromq1Toq2.dot(normal_q2))
				newq2=q1+factor*fromq1Toq2
				return modifyOrbit(q1,newq2,p1,p2,e1,e2,vertK,normalCone_p1,normalCone_p2,normal_q2,height_q2)

#Diese Funktion dient der Parallelisierung und wird in minTwoOrbit() aufgerufen.
def doParallel_2Bounce(bestVal,bestOrbit,regular,l,iK,faceNumK,faceNumT,normalsK,normalsT,vertNumK,vertNumT,heightsK,heightsT,facesK,facesT):
	for jK in range(faceNumK):
			#Check ob die Seitenindizes iK,jK fuer q1,q2 in Frage kommen.
			if iK==jK:
				continue
			if not conesIntersect(normalsK[iK],normalsK[jK]):
				continue
			for iT in range(faceNumT):
				for jT in range(faceNumT):
					#Check ob die Seitenindizes iT,jT fuer p1,p2 in Frage kommen.
					if iT==jT:
						continue
					if not conesIntersect(normalsT[iT],normalsT[jT]):
						continue
					#1. Fall: je mind. eine Kante in K und T gewaehlt:
					if isVertex(iK,vertNumK)*isVertex(jK,vertNumK)==0 and isVertex(iT,vertNumT)*isVertex(jT,vertNumT)==0:
						potOrbit=findOrbitFullEdge([iK,jK],[iT,jT],normalsK,normalsT,heightsK,heightsT,vertNumK,vertNumT,faceNumK-vertNumK,faceNumT-vertNumT,facesK,facesT)
						if potOrbit[0]:
							orbit=potOrbit[1]
							isRegular=False
							if isVertex(iK,vertNumK)+isVertex(jK,vertNumK)==0:	
								modificOrb=modifyOrbit(orbit[0],orbit[1],orbit[2],orbit[3],facesK[iK],facesK[jK],facesK[0:vertNumK],normalsT[iT],normalsT[jT],normalsK[jK],heightsK[jK])
								orbit=modificOrb[1]
								isRegular=modificOrb[0]
							action=calcAction(orbit)
							l.acquire()
							if action<bestVal.value-10**(-9) or (abs(action-bestVal.value)<10**(-9) and isRegular):
								bestVal.value=action
								bestOrbit[:]=orbit.flatten()
								regular.value=isRegular
							l.release()
					#2. Fall: alle gewaehlten Seiten sind Ecken:
					elif isVertex(iK,vertNumK)*isVertex(jK,vertNumK)==1 and isVertex(iT,vertNumT)*isVertex(jT,vertNumT)==1:
						q1=facesK[iK]
						q2=facesK[jK]
						p1=facesT[iT]
						p2=facesT[jT]
						if findOrbitNoEdge([iK,jK],[iT,jT],normalsK,normalsT,facesK,facesT):
							orbit=np.vstack((q1,q2,p1,p2))
							action=calcAction(orbit)
							l.acquire()
							if action<bestVal.value-10**(-9):
								bestVal.value=action
								bestOrbit[:]=orbit.flatten()
								regular.value=False
							l.release()		
					#3. Fall: beide Seiten von K oder T sind Ecken.
					else:
						#Pruefe ob fuer K oder T beide Seiten Ecken sind.
						if isVertex(iK,vertNumK)*isVertex(jK,vertNumK)==1:
							PisK=True
							normalsP=normalsK
							heightsP=heightsK
							facesP=facesK
							vertNumP=vertNumK
							edgeNumP=faceNumK-vertNumK
							faceIndicesP=[iK,jK]
							normalsQ=normalsT
							heightsQ=heightsT
							facesQ=facesT
							vertNumQ=vertNumT
							edgeNumQ=faceNumT-vertNumT
							faceIndicesQ=[iT,jT]
						else:
							PisK=False
							normalsP=normalsT
							heightsP=heightsT
							facesP=facesT
							vertNumP=vertNumT
							edgeNumP=faceNumT-vertNumT
							faceIndicesP=[iT,jT]
							normalsQ=normalsK
							heightsQ=heightsK
							facesQ=facesK
							vertNumQ=vertNumK
							edgeNumQ=faceNumK-vertNumK
							faceIndicesQ=[iK,jK]
						potOrbit=findOrbitHalfEdge(faceIndicesP,faceIndicesQ,normalsP,normalsQ,heightsP,heightsQ,vertNumP,vertNumQ,edgeNumP,edgeNumQ,facesP,facesQ,PisK)
						if potOrbit[0]:
							orbit=potOrbit[1]
							isRegular=False
							if isVertex(iK,vertNumK)+isVertex(jK,vertNumK)==0:	
								modificOrb=modifyOrbit(orbit[0],orbit[1],orbit[2],orbit[3],facesK[iK],facesK[jK],facesK[0:vertNumK],normalsT[iT],normalsT[jT],normalsK[jK],heightsK[jK])
								orbit=modificOrb[1]
								isRegular=modificOrb[0]
							action=calcAction(orbit)
							l.acquire()
							if action<bestVal.value-10**(-9) or (abs(action-bestVal.value)<10**(-9) and isRegular):
								bestVal.value=action
								bestOrbit[:]=orbit.flatten()
								regular.value=isRegular
							l.release()
								
#Finde minimalen 2-Orbit
def minTwoOrbit(vertK,vertT):
	vertNumK=vertK.shape[0]
	vertNumT=vertT.shape[0]
	edgesK=getEdges(vertK)
	edgesT=getEdges(vertT)
	faceNumK=vertNumK+edgesK.shape[0]
	faceNumT=vertNumT+edgesT.shape[0]	
	facesK=stackFaces(vertK,edgesK,vertNumK,faceNumK)
	facesT=stackFaces(vertT,edgesT,vertNumT,faceNumT)	
	normalsK=normalArray(vertK,edgesK,vertNumK,faceNumK)
	normalsT=normalArray(vertT,edgesT,vertNumT,faceNumT)
	heightsK=heightsArray(vertK,edgesK,vertNumK,faceNumK,normalsK)
	heightsT=heightsArray(vertT,edgesT,vertNumT,faceNumT,normalsT)
	bestOrbit=mp.Array('d',np.zeros((8)))
	bestVal=mp.Value('d',np.Inf)
	regular=mp.Value('b',False)
	l=mp.Lock()
	processes=[]
	#multiprocess doParallel_2Bounce
	for iK in range(faceNumK):	
		p=mp.Process(target=doParallel_2Bounce,args=(bestVal,bestOrbit,regular,l,iK,faceNumK,faceNumT,normalsK,normalsT,vertNumK,vertNumT,heightsK,heightsT,facesK,facesT))
		processes.append(p)
		p.start()
	#Warte bis alle Prozesse beendet sind:
	for q in processes:
		q.join()
	bestOrbitOut=np.vstack([bestOrbit[0:2],bestOrbit[2:4],bestOrbit[4:6],bestOrbit[6:8]])
	print '-----------------------\n-----------------------'
	print 'Minimal action and orbit (q_0,q_1,p_0,p_1):'
	print bestVal.value
	print bestOrbitOut
	if regular.value:
		print 'This orbit is regular.'
	else:
		print 'This orbit is not regular. There is no optimal regular 2-bounce orbit.'
	return [bestVal.value, bestOrbitOut]
								

#def minTwoOrbit(vertK,vertT,tol):
#	bestVal=np.Inf
#	bestOrbit=np.zeros((4,2))
#	vertKN=vertK.shape[0]
#	vertTN=vertT.shape[0]
#	for i_q1 in range(vertKN):
#		print str(i_q1+1) + " von " + str(vertKN)
#		q1=vertK[i_q1]
#		#markiere Ecke v blau, wenn sie als q2 infrage kommt
#		blueVerts=np.zeros((2))
#		blueIndices=np.array([])
#		for iv in range(vertKN):
#			#kein Punkt kommt gleichzeitig als q1 und q2 infrage. Muss wegen Toleranz ausgeschlossen werden
#			if iv==i_q1:
#				continue
#			if conesIntersect(vertK,vertK,i_q1,iv,True,False,tol):
#				insertBlue=vertK[iv]
#				blueIndices=np.append(blueIndices,[iv])
#				blueVerts=np.vstack((blueVerts,insertBlue))			
#		#Die erste Zeile diente der Initialisierung. Entfernen bzw testen ob Zeilen hinzu kamen
#		blueN=blueVerts.shape[0]-1
#		if blueN>0:
#			blueVerts=np.delete(blueVerts,0,0)
#		for i_q2 in range(blueN):	
#			q2=blueVerts[i_q2]
#			#markiere Ecke w gruen, wenn sie als p1 infrage kommt.
#			#markiere sie rot, wenn sie als p2 infrage kommt.
#			greenVerts=np.zeros((2))
#			redVerts=np.zeros((2))
#			greenIndices=np.array([])
#			redIndices=np.array([])
#			for iw in range(vertTN):	
#				if isInCone(vertT,iw,q2-q1,tol):
#					insertRed=vertT[iw]
#					redIndices=np.append(redIndices,[iw])
#					redVerts=np.vstack((redVerts,insertRed))
#				if isInCone(vertT,iw,q1-q2,tol):
#					insertGreen=vertT[iw]
#					greenIndices=np.append(greenIndices,[iw])
#					greenVerts=np.vstack((greenVerts,insertGreen))
#			greenN=greenVerts.shape[0]-1
#			if greenN>0:
#				greenVerts=np.delete(greenVerts,0,0)
#			redN=redVerts.shape[0]-1
#			if redN>0:
#				redVerts=np.delete(redVerts,0,0)
#			for i_p1 in range(greenN):
#				for i_p2 in range(redN):
#					#kein Punkt kommt gleichzeitig als p1 und p2 infrage. Muss wegen Toleranz ausgeschlossen werden
#					if greenIndices[i_p1]==redIndices[i_p2]:
#						continue
#					p2=redVerts[i_p2]
#					p1=greenVerts[i_p1]		
#					if isInCone(vertK,blueIndices[i_q2],p2-p1,tol) and isInCone(vertK,i_q1,p1-p2,tol):
#						action=p2.dot(q2-q1)-p1.dot(q2-q1)
#						if action<bestVal:
#							bestVal=action
#							bestOrbit=np.vstack((q1,q2,p1,p2))
#	print '-----------------------\n-----------------------'
#	print 'Minimale Wirkung und Bahn (q_0,q_1,p_0,p_1):'
#	print bestVal
#	print bestOrbit


#--------------------------------------------------------------------
#------------------ Finde 3-Bounce Orbits ---------------------------
#--------------------------------------------------------------------

#Gegeben: Kante; gesucht: aeussere Normale
def outerNormalEdge(vert,edge):
	v=vert[edge[0]]
	w=vert[edge[1]]
	n=np.array([v[1]-w[1],w[0]-v[0]])
	height=n.dot(v)
	for vRun in vert:
		if n.dot(vRun)>height+10**(-9):
			n=-n
			break
		elif n.dot(vRun)<height-10**(-9):
			break
	return n
	
#Routine, die einen Normalkegel diskretisiert. Dazu werden aequidistante Winkel gefunden,
#Sodass diese einen Abstand von hoechstens accu zueinander haben.
def discreteCone(cone,accu):
	if abs(cone[0]-cone[1])<10**(-9):
		return np.array([cone[0]])
	if cone[1]>cone[0]:
		totalAngle=cone[1]-cone[0]
	else:
		totalAngle=2*np.pi+cone[1]-cone[0]
	disNum=int(np.ceil(totalAngle/accu))
	disCone=np.zeros((disNum+1))
	for i in range(disNum+1):
		disCone[i]=cone[0]+i*totalAngle/disNum
	return disCone

#Gegeben: 3 Normalen mit Hoehe; Gesucht: Ecken des ausgeschnittenen Dreiecks
def triangleVerts(n1,n2,n3,h1,h2,h3):
	normals=np.array([n1,n2,n3])
	heights=np.array([h1,h2,h3])
	triangle=np.zeros([3,2])
	count=0
	for i in range(3):
		for j in range(i+1,3):
			coeffMat=np.array([normals[i],normals[j]])
			#Falls 2 Seiten parallel sind, ist kein Dreieck konstruierbar. Gib 0 zurueck.
			if np.linalg.matrix_rank(coeffMat,tol=10**(-9))<2:
					return np.zeros([3,2])
			rightSide=np.array([heights[i],heights[j]])
			newVert=np.linalg.solve(coeffMat,rightSide)
			triangle[count]=newVert
			count+=1
	return triangle
	
#Gegeben: Kante (v,w) mit Normale und Hoehe, zu ueberpruefende Vektoren. Output: True wenn einer der Vektoren auf der Kante liegt
def checkBoundary(v,w,n,h,checkVerts):
	for u in checkVerts:
		if abs(n.dot(u)-h)<10**(-9):
			#relevanter Vektor. Berechne m=Normale zur Normalen
			m=w-v
			mark1=m.dot(w)
			mark2=m.dot(v)
			if mark1>mark2:
				temp=mark1
				mark1=mark2
				mark2=temp
			markU=m.dot(u)
			if mark1-10**(-9)<markU and markU<mark2+10**(-9):
				return True
	return False
	
#Gegeben: Richtungen u,v,w aus denen Dreieck gebildet werden soll; Gesucht: Ecken eines geeigneten Dreiecks.
def constrTriangle(u,v,w):
	triangle=np.zeros([3,2])
	#1. Ecke: 0
	#2. Ecke: 0+u=u
	#3. Ecke: liegt auf dem Schnitt zweier Strecken (lin. Gleichungssys.)
	linSysMat=np.transpose(np.array([(-1)*v,w]))
	linSysRight=u
	if np.linalg.matrix_rank(linSysMat,tol=10**(-9))<2:
		#Dreieck ist nicht konstruierbar. Gib 0 als default aus
		return triangle
	solution=np.linalg.solve(linSysMat,linSysRight)
	if solution[0]>=0 and solution[1]<=0:
		triangle[1]=u
		triangle[2]=solution[1]*w
		return triangle
	else:
		#Dreieck ist nicht konstruierbar. Gib 0 als default aus
		return triangle

#Gegeben: Normalenkegel nc1,nc2,nc3. Gib zurueck, ob die Vereinigung der Normalkegel in unterschiedl. Halbraeumen liegt, also ob
#die Methode constrTriangle erfolgreich sein wird.
def triangleConstructable(nc1,nc2,nc3):
	allCones=np.vstack([nc1,nc2,nc3])
	#Normalkegel werden im Uhrzeigersinn nummeriert.
	sortedCones=np.zeros((3,2))
	#Suche den Kegel, der mit dem kleinsten Winkel anfaengt. Update wenn aktueller Kegel beginnt mit kleinerem Winkel;
	#oder aktueller Kegel beginnt mit gleichem Winkel und es wurde noch kein Kegel vorher betrachtet; oder aktueller Kegel
	#beginnt mit gleichem Winkel und ist ein einzelner Vektor.
	for i in range(2):
		minimumAngle=2*np.pi
		minimumIndex=-1
		minimumCone=np.array([0,0])
		index=0
		for c in allCones:
			if c[0]<minimumAngle-10**(-9):
				minimumAngle=c[0]
				minimumIndex=index
				minimumCone=c
			elif abs(c[0]-minimumAngle)<=10**(-9):
				if np.linalg.norm(minimumCone-np.array([0,0]))<=10**(-9):
					minimumAngle=c[0]
					minimumIndex=index
					minimumCone=c
				else:
					if abs(c[1]-c[0])<=10**(-9):
						minimumAngle=c[0]
						minimumIndex=index
						minimumCone=c
			index+=1
		sortedCones[i]=minimumCone
		allCones=np.delete(allCones,minimumIndex,0)
	sortedCones[2]=allCones[0]
	#Ueberpruefe Winkel aufeinander folgender Kegel. Nur der 3. Kegel kann ueber Winkel 0 gehen.
	if sortedCones[1,0]-sortedCones[0,1]>=np.pi-10**(-9):
		return False
	if sortedCones[2,0]-sortedCones[1,1]>=np.pi-10**(-9):
		return False
	if sortedCones[2,0]>sortedCones[2,1]+10**(-9):
		if sortedCones[0,0]-sortedCones[2,1]>=np.pi-10**(-9):
			return False
	else:
		if 2*np.pi+sortedCones[0,0]-sortedCones[2,1]>=np.pi-10**(-9):
			return False
	#Winkel sind alle hinreichend klein.
	return True

#Geg.: Kanten eines Polytops, Ecken eines Dreiecks. Ziel: Finde groesste Version des Dreiecks im Polytop
#und falls eine Ecke im Inneren liegt, gib 'False' und die Kantenindizes zurueck, die fuer findInbody in Frage kommen.
#Liegen alle 3 Ecken auf dem Rand, gib statt dessen 'True' und die gefundenen Ecken des Dreiecks wieder.
def findInbodyPrecond(Kanten,edgeNum,vertP,vertTria,leftSide,rightSide):
	relevantE=np.zeros(edgeNum,dtype=int)
	#Loese lin. Prog. um groesste Version vom Dreieck im Polytop zu finden 
	#optimOut=Simplex.solveOpt(np.array([0,0,-1]),leftSide,rightSide,None,None,((None,None),(None,None),(0,None)))
	
	x=cp.Variable(3)
	c=np.array([0,0,1])
	constraints = [leftSide*x<=rightSide, x[2]>=0]
	obj = cp.Maximize(c*x)
	prob = cp.Problem(obj, constraints)
	prob.solve(solver=cp.CVXOPT)
	
	if prob.status!='optimal':
		print 'Error in findInbodyPrecond(). Could not fit Triangle into polytope' 
		return [False,[range(edgeNum)]]
	
	scaleFac=x.value[2]
	translate=x.value[0:2]
	bigTria=scaleFac*vertTria+np.vstack(3*[translate])
	#Ist im i-ten Drittel mind. eine der Ungleichungen mit Gleichheit erfuellt, dann liegt v_i auf dem Rand.
	isOnBoundary=[False,False,False]
	slack=rightSide-leftSide.dot(x.value)
	for i in range(3):
		for j in range(edgeNum):
			if abs(slack[i*edgeNum+j])<10**(-6):
				isOnBoundary[i]=True
				break
	#Alle Ecken sind auf dem Rand. Preconditioning hat keine Aussagekraft.
	if isOnBoundary[0] and isOnBoundary[1] and isOnBoundary[2]:
		return [True,bigTria]
	trueInd=np.where(np.array([isOnBoundary])==True)[0]
	falseInd=np.where(np.array([isOnBoundary])==False)[0]
	#Ermitteln der Kanten, auf denen die Ecken des Dreiecks liegen.
	#Es gibt immer mindestens 2 solcher Kanten. Werden keine 2 Kanten gefunden
	#(wegen geringerer Genauigkeit des Solvers) wird Preconditioning abgebrochen.
	try:
		vBound1=bigTria[trueInd[0]]
		vBound2=bigTria[trueInd[1]]
	except IndexError:
		return [False,[range(edgeNum)]]
	vInt=bigTria[falseInd[0]]
	intersectNormal=np.array([vBound1[1]-vBound2[1],vBound2[0]-vBound1[0]])
	intersectHeight=intersectNormal.dot(vBound1)
	#Frage: welche Seite der Hypereben enthaelt die relevanten Kanten?
	#Antwort: Wenn isLow=True, dann H^- sonst H^+
	if vInt.dot(intersectNormal)<intersectHeight:
		isLower=True
	else:
		isLower=False
	counter=0
	for eInd in range(edgeNum):
		edgeIsLow=[False,False]
		v=vertP[Kanten[eInd,0]]
		w=vertP[Kanten[eInd,1]]
		if isLower:
			if v.dot(intersectNormal)<=intersectHeight+10**(-6) or w.dot(intersectNormal)<=intersectHeight+10**(-6):
				relevantE[counter]=eInd
				counter+=1
		else:
			if v.dot(intersectNormal)>=intersectHeight-10**(-6) or w.dot(intersectNormal)>=intersectHeight-10**(-6):
				relevantE[counter]=eInd
				counter+=1
	return [False,relevantE[0:counter]]
		
#Geg.: Ecken eines Dreiecks, Polytop (Ecken, Kanten, Normalen, Hoehe). Ges.: Skaliertes, translatiertes Dreieck, dass seine Ecken auf dem Rand hat
#Ist das Polytop beschrieben durch Ax<=b, mit Zeilen von A=aeussere Normalen, dann enthaelt b die Hoehen
#Zudem wird getestet, ob die Normalkegel der gefundenen Kanten ein neues Dreieck bilden, i.e. ob der Algorithmus damit weiter laeuft
def findInbody(Kanten,vert,edgeNum,normalP,heightP,vertTria):
	leftSide=np.zeros([3*edgeNum,3])
	rightSide=np.hstack(3*[heightP])
	inbody=np.zeros([3,2])
	#linke Seite des Ungleichungssystems A(\lambda*v_i+u)<=b
	for i in range(3):
		for j in range(edgeNum):
			leftSide[j+i*edgeNum]=np.array([normalP[j,0],normalP[j,1],normalP[j].dot(vertTria[i])])
	#Fixiere 3 Seiten, auf denen je mind. eine Ecke des Dreiecks liegen soll.
	precond=findInbodyPrecond(Kanten,edgeNum,vert,vertTria,leftSide,rightSide)
	if precond[0]:
		possEdges=range(edgeNum)
	else:
		possEdges=precond[1]
	for e1Ind in possEdges:
		for e2Ind in possEdges:
			if e1Ind==e2Ind:
				continue
			for e3Ind in possEdges:
				if e1Ind==e3Ind or e2Ind==e3Ind:
					continue
				#e1,e2,e3 paarweise verschieden
				a1=normalP[e1Ind]
				a2=normalP[e2Ind]
				a3=normalP[e3Ind]
				#Stelle 3x3-LGS auf und loese es
				leftEqu=np.array([[a1[0],a1[1],a1.dot(vertTria[0])],[a2[0],a2[1],a2.dot(vertTria[1])],[a3[0],a3[1],a3.dot(vertTria[2])]])
				rightEqu=np.array([heightP[e1Ind],heightP[e2Ind],heightP[e3Ind]])
				if np.linalg.matrix_rank(leftEqu,tol=10**(-9))<3:
					continue
				solution=np.linalg.solve(leftEqu,rightEqu)
				#Check ob der Skalierungsfaktor nichtnegativ ist. Falls negativ: Gibt kein geeignetes Dreieck. Naechster Schleifendurchlauf.
				scale=solution[2]
				if scale<10**(-6):
					continue
				#Check ob die Loesung alle Ungleichungen erfuellt.
				checkVec=leftSide.dot(solution)-np.ones(3*edgeNum)*(10**(-6))
				booleVec=np.less_equal(checkVec,rightSide)
				stopThisLoop=False
				for passedTest in booleVec:
					if not passedTest:
						stopThisLoop=True
						break
				if stopThisLoop:
					continue
				#Loesung gefunden
				translate=solution[0:2]
				scale=solution[2]
				for k in range(3):
					inbody[k]=scale*vertTria[k]+translate
				#Pruefe, ob die Normalenkegel ein Dreieck definieren koennen. Falls nein wuerde ein gefundenes Dreieck im darauf
				#folgenden Schritt zu einem verfruehten Abbruch fuehren.
				normalTest1=normalConeMultifunc(vert,Kanten,inbody[0],10**(-6))
				normalTest2=normalConeMultifunc(vert,Kanten,inbody[1],10**(-6))
				normalTest3=normalConeMultifunc(vert,Kanten,inbody[2],10**(-6))
				if not triangleConstructable(normalTest1,normalTest2,normalTest3):
					continue
				return inbody	
	#Default: Return [[0,0],[0,0],[0,0]] (wenn kein Dreieck gefunden wurde.)
	return np.zeros([3,2])
	
#Diese Funktion wird in der Hauptschleife in minThreeOrbit() aufgerufen.
#Auf diesen Teil wird multiprocessing angewandt.
def doParallel(bestVal,minOrbit,l,i1,KantenK,KantenT,edgeNumK,edgeNumT,outernormalsT,heightsT,vertK,vertT,accu):
	for i2 in range(i1+1,edgeNumK):
			for i3 in range(i2+1,edgeNumK):
				e1_ind=i1
				e2_ind=i2
				e3_ind=i3				
				#mache folgendes fuer (e1,e2,e3) und (e1,e3,e2)
				switched=False
				while True:
					e1=KantenK[e1_ind]
					e2=KantenK[e2_ind]
					e3=KantenK[e3_ind]
					#aeussere Normalen des Dreiecks A(=triangle)
					n1=outerNormalEdge(vertK,e1)
					h1=n1.dot(vertK[e1[0]])
					n2=outerNormalEdge(vertK,e2)
					h2=n2.dot(vertK[e2[0]])
					n3=outerNormalEdge(vertK,e3)
					h3=n3.dot(vertK[e3[0]])
					triangle=triangleVerts(n1,n2,n3,h1,h2,h3)
					if np.allclose(triangle,np.zeros([3,2])):
						#Zwei der gewaehlten Seiten sind parallel.
						if switched:
							break
						tempo=e2_ind
						e2_ind=e3_ind
						e3_ind=tempo
						switched=True
						continue
					triangToScale=constrTriangle(n1,n2,n3)
					if np.allclose(triangToScale,np.zeros([3,2])):
						#Es gibt kein geeignetes Dreieck
						if switched:
							break
						tempo=e2_ind
						e2_ind=e3_ind
						e3_ind=tempo
						switched=True
						continue
					#Finde 3 Punkte auf dem Rand von T sodass triangToScale sie nach verschieben/skalieren mit den Ecken beruehrt
					#Werden die Punkte [[0,0],[0,0],[0,0]] gefunden, gibt es kein solches Dreieck.
					inbodyInT=findInbody(KantenT,vertT,edgeNumT,outernormalsT,heightsT,triangToScale)
					p1=inbodyInT[0]
					p2=inbodyInT[1]
					p3=inbodyInT[2]
					if np.allclose(p1,np.zeros(2)) and np.allclose(p2,np.zeros(2)) and np.allclose(p3,np.zeros(2)):
						if switched:
							break
						tempo=e2_ind
						e2_ind=e3_ind
						e3_ind=tempo
						switched=True
						continue
					nc1=normalConeMultifunc(vertT,KantenT,p1)
					nc2=normalConeMultifunc(vertT,KantenT,p2)
					nc3=normalConeMultifunc(vertT,KantenT,p3)
					#Falls eine Ecke des Inbody zufaelligerweise auch eine Ecke von T ist, dann sollte man in Betracht ziehen eine Ecke von K
					#leicht abzuaendern, sodass der Inbody sich leicht aendert und dieser Fall nicht mehr eintritt.
					if abs(nc1[0]-nc1[1])>10**(-9) or abs(nc2[0]-nc2[1])>10**(-9) or abs(nc3[0]-nc3[1])>10**(-9):
						l.acquire()
						print 'A calculated inbody shares a vertex with T. Consider perturbing K. I chose the following edges of K:'
						print '( ' + str(vertK[KantenK[e1_ind,0]]) + ' , ' + str(vertK[KantenK[e1_ind,1]]) + ' )'
						print '( ' + str(vertK[KantenK[e2_ind,0]]) + ' , ' + str(vertK[KantenK[e2_ind,1]]) + ' )'
						print '( ' + str(vertK[KantenK[e3_ind,0]]) + ' , ' + str(vertK[KantenK[e3_ind,1]]) + ' )'
						print '---'
						l.release()
					#Diskretisiere:
					disCone1=discreteCone(nc1,accu)
					disCone2=discreteCone(nc2,accu)
					disCone3=discreteCone(nc3,accu)
					#Fuer jede moegliche Kombination von Normalenvektoren, bildet erneut einen Kegel
					for ang1 in disCone1:
						for ang2 in disCone2:
							for ang3 in disCone3:
								direc1=(-1)*angleToVec(ang1)
								direc2=(-1)*angleToVec(ang2)
								direc3=(-1)*angleToVec(ang3)
								triangToScale2=constrTriangle(direc1,direc2,direc3)
								if np.allclose(triangToScale2,np.zeros([3,2])):
									#Es gibt kein geeignetes Dreieck
									continue
								#Finde drei Punkte auf dem Rand von triangle, sodass triangToScale2 sie nach verschieben/skalieren mit den Ecken beruehrt
								#Wieder: [[0,0],[0,0],[0,0]] heisst keine solchen Punkte existieren.
								inbodyInK=findInbody(np.array([[0,1],[0,2],[1,2]]),triangle,3,np.array([n1,n2,n3]),np.array([h1,h2,h3]),triangToScale2)
								q1=inbodyInK[0]
								q2=inbodyInK[1]
								q3=inbodyInK[2]
								if np.allclose(q1,np.zeros(2)) and np.allclose(q2,np.zeros(2)) and np.allclose(q3,np.zeros(2)):
									continue
								Q=np.array([q1,q2,q3])
								#Teste ob y1,y2,y3 auch auf dem Rand von K liegen
								check1=checkBoundary(vertK[e1[0]],vertK[e1[1]],n1,h1,Q)
								check2=checkBoundary(vertK[e2[0]],vertK[e2[1]],n2,h2,Q)
								check3=checkBoundary(vertK[e3[0]],vertK[e3[1]],n3,h3,Q)
								if check1 and check2 and check3:
									#Bahn gefunden, berechne Wirkung
									action=p3.dot(q3-q1)+p1.dot(q1-q2)+p2.dot(q2-q3)
									l.acquire()
									if action<bestVal.value:
										bestVal.value=action
										minOrbit[:]=np.hstack((q1,q2,q3,p1,p2,p3))
									l.release()
					if switched:
						break
					tempo=e2_ind
					e2_ind=e3_ind
					e3_ind=tempo
					switched=True

#Hauptroutine zum Finden minimaler 3-Bounce Orbits
def minThreeOrbit(vertK,vertT,accu):
	KantenK=getEdges(vertK)
	KantenT=getEdges(vertT)
	edgeNumK=KantenK.shape[0]
	edgeNumT=KantenT.shape[0]
	outernormalsT=np.zeros([edgeNumT,2])
	heightsT=np.zeros(edgeNumT)
	for i in range(edgeNumT):
		outNo=outerNormalEdge(vertT,KantenT[i])
		outernormalsT[i]=outNo
		heightsT[i]=outNo.dot(vertT[KantenT[i,0]])
	minOrbit=mp.Array('d',np.zeros((12)))
	bestVal=mp.Value('d',np.Inf)
	l=mp.Lock()
	processes=[]
	#multiprocess doParallel
	for i1 in range(edgeNumK):
		p=mp.Process(target=doParallel,args=(bestVal,minOrbit,l,i1,KantenK,KantenT,edgeNumK,edgeNumT,outernormalsT,heightsT,vertK,vertT,accu))
		processes.append(p)
		p.start()
	#Warte bis alle Prozesse beendet sind:
	for q in processes:
		q.join()
	minOrbitOut=np.vstack([minOrbit[0:2],minOrbit[2:4],minOrbit[4:6],minOrbit[6:8],minOrbit[8:10],minOrbit[10:12]])
	print '-----------------------\n-----------------------'
	print 'Minimal action and orbit (q_0,q_1,q_2,p_0,p_1,p_2):'
	print bestVal.value
	print minOrbitOut
	return [bestVal.value, minOrbitOut]


#-----------------------------------------------------------------------
#-------------   Random polytope - For testing   -----------------------
#-----------------------------------------------------------------------	
def H_To_V(normals,heights):
	rowNum=np.shape(normals)[0]
	vert=np.zeros((rowNum,2))
	vertCount=0
	for i in range(rowNum):
		for j in range(i+1,rowNum):
			eqLeft=normals[[i,j]]
			eqRight=heights[[i,j]]
			if np.linalg.matrix_rank(eqLeft,tol=10**(-9))==2:
				potVert=np.linalg.solve(eqLeft,eqRight)
				if fullfillsConstrains(potVert,normals,heights):
					vert[vertCount]=potVert
					vertCount+=1
	return vert[0:vertCount]

def fullfillsConstrains(potVert,normals,heights):
	for i in range(np.shape(normals)[0]):
		if normals[i].dot(potVert)>heights[i]+10**(-9):
			return False
	return True
	
def generatePoly(hyperPlaneNum):
	angles=np.random.rand(hyperPlaneNum)*2*np.pi
	normals=np.zeros((hyperPlaneNum,2))
	#heights=np.random.rand(hyperPlaneNum)*0.5+0.5
	heights=10*np.ones(hyperPlaneNum)
	for j in range(hyperPlaneNum):
		normals[j]=angleToVec(angles[j])
	return H_To_V(normals,heights)

#-----------------------------------------------------------------------
def refineRandChoice(vert):
	deleteArr=[]
	vertNum=vert.shape[0]
	for vInd in range(vertNum):
		foundFace=False
		for wInd in range(vertNum):
			if vInd==wInd:
				continue
			v=vert[vInd]
			w=vert[wInd]
			n=np.array([v[1]-w[1],w[0]-v[0]])
			h=v.dot(n)
			sign=0
			wFailed=False
			for xInd in range(vertNum):
				x=vert[xInd]				
				if xInd==vInd or xInd==wInd:
					continue
				if abs(n.dot(x)-h)<10**(-9):
					print 'Bad seed!'
				elif n.dot(x)<h-10**(-9):
					if sign==0:
						sign=-1
						continue
					elif sign==1:
						wFailed=True
						break
				else:
					if sign==0:
						sign=1
						continue
					elif sign==-1:
						wFailed=True
						break
			if not wFailed:
				foundFace=True
				break
		if not foundFace:
			deleteArr+=[vInd]
	vert=np.delete(vert,deleteArr,0)
	return vert

def pointCloud(m):
	out=np.zeros((m,2))
	for i in range(m):
		ang=np.random.random()*2*np.pi
		length=0+np.random.random()*2   #Adjust point cloud here!!!!!!!!!!!!!!
		out[i]=length*angleToVec(ang)
	return out

def randomPoly(m):
	vert=pointCloud(m)
	refVert=refineRandChoice(vert)
	print 'Found ' + str(refVert.shape[0]) + ' vertices.'
	return refVert

def randomCentralsymPoly(m):
	vertHalf=pointCloud(m)
	vert=np.vstack([vertHalf,-vertHalf])
	refVert=refineRandChoice(vert)
	vertNum=refVert.shape[0]
	middle=np.zeros((2))
	for v in refVert:
		middle+=v/vertNum
	for i in range(vertNum):
		refVert[i]-=middle
	print 'Found ' + str(vertNum) + ' vertices.'
	return refVert

def hannerPoly(m):
	vertK=randomPoly(m)
	heights=np.ones((vertK.shape[0]))
	vertT=H_To_V(vertK,heights)
	return [vertK,vertT]

def ngon(n):
	out=np.zeros((n,2))
	angles=np.linspace(0,2*np.pi,n+1)[0:n]
	for i in range(n):
		out[i]=angleToVec(angles[i])
	return out

def addAngles(ang,angToAdd):
	newAng=ang+angToAdd
	if newAng>2*np.pi+10**(-9):
		newAng-=2*np.pi
	elif newAng<-10**(-9):
		newAng+=2*np.pi
	return newAng

def acuteTria():
	refVert=np.zeros((3,2))
	for i in range(2):
		ang=np.random.random()*2*np.pi
		length=0+np.random.random()*2
		refVert[i]=length*angleToVec(ang)
	x=refVert[0]
	y=refVert[1]
	alphaAdd=np.random.random()*np.pi/2
	alphaCurr=atan2(y-x)
	betaAdd=(np.pi/2)-alphaAdd+np.random.random()*alphaAdd
	betaCurr=atan2(x-y)
	alpha=addAngles(alphaCurr,alphaAdd)
	beta=addAngles(betaCurr,-betaAdd)
	dx=angleToVec(alpha)
	dy=angleToVec(beta)
	left=np.transpose(np.vstack([dx,-dy]))
	right=y-x
	sol=np.linalg.solve(left,right)
	refVert[2]=x+sol[0]*dx
	middle=np.zeros((2))
	for v in refVert:
		middle+=v/3
	for j in range(3):
		refVert[j]-=middle
	return refVert

#check whether some of the 'vertices' are in fact inner points.
#If yes, return these points. 
def checkInner(vert):
	#initially, every point is potentially not a vertex. Remove an index
	#once the corresponding point is confirmed to be a vertex.
	nonvert = range(np.shape(vert)[0])
	
	for i in range(np.shape(vert)[0]):		
		v = vert[i]
		
		for j in range(np.shape(vert)[0]):
			if i == j:
				continue
			
			w =vert[j]
			n = np.array([v[1] - w[1], w[0] - v[0]])
			h = n.dot(v)
			sign = 0
			
			violate = False
			
			for k in range(np.shape(vert)[0]):
				if k == i or k == j:
					continue
				
				s = n.dot(vert[k])
				
				if abs(s - h) < 10 ** (-9):
					#At least 3 vertices lie on a straight line.
					print 'Warning: Some of the vertices of a polytope lie on a straight line. Hence, unneccesarily many vertices are considered.'
					continue
				
				if sign == 0:
					if s > h + 10 ** (-9):
						sign = 1
					else:
						sign = -1
					
				elif sign > 0 and s < h - 10**(-9):
					violate = True
				
				elif sign < 0 and s > h - 10**(-9):
					violate = True
			
			if not violate:
				#[v,w] is an edge (or at least part of an edge).
				nonvert.remove(i)
				break #no more w have to be considered.
	out = []
	for ind in nonvert:
		out += [list(vert[ind])]
		
	return out				

#main routine
def main(vertK,vertT,verbose = True):
	
	innerK = checkInner(vertK)
	innerT = checkInner(vertT)
	
	stop = False
	if len(innerK) > 0:
		stop = True
		print 'Error: The following vertices of K are in fact interior points:\n'
		for v in innerK:
			print v
		print '\nPlease remove these points from the input for K and try again.'
	
	if len(innerT) > 0:
		stop = True
		print 'Error: The following vertices of T are in fact interior points:\n'
		for v in innerT:
			print v
		print '\nPlease remove these points from the input for T and try again.'
	
	if stop:
		return

	if verbose:
		print 'Nr. of vertices in K: ' + str(np.shape(vertK)[0])
		print '---'
		print 'Nr. of vertices in T: ' + str(np.shape(vertT)[0])

	tic=time.time()
	[two, twoOrbit] = minTwoOrbit(vertK,vertT)
	toc1=time.time()-tic

	if verbose:
		print '-------------------------------'
		print 'Calculation time for 2-Bounce: ' + str(toc1)

	accu=0.2
	tic=time.time()
	[three, threeOrbit] = minThreeOrbit(vertK,vertT,accu)
	toc2=time.time()-tic

	if verbose:
		print '-------------------------------'
		print 'Calculation time for 3-Bounce: ' + str(toc2)

		print '-----------------------\n-----------------------'
		print 'c(KxT) = ' + str(min(two,three))

		print '-----------------------\n-----------------------'
		print 'Total running time: ' + str(toc1+toc2)
	
		#ordering vertices for plot:
		orderedK = ordering(vertK)
		orderedT = ordering(vertT)
		
		plt.close()
		
		#plot K:
		x = []
		y = []
		
		for v in orderedK:
			x += [v[0]]
			y += [v[1]]
		
		x += [orderedK[0][0]]
		y += [orderedK[0][1]]
		
		plt.subplot(1,2,1)
		plt.plot(x,y)
		
		#plot orbit in K:
		x = []
		y = []
		
		if two < three:
			for i in range(2):
				x += [twoOrbit[i][0]]
				y += [twoOrbit[i][1]]
		
		else:
			for i in range(3):
				x += [threeOrbit[i][0]]
				y += [threeOrbit[i][1]]
			
			x += [threeOrbit[0][0]]
			y += [threeOrbit[0][1]]
		
		plt.plot(x,y)
		plt.title('K with minimal closed polygonal line')
		
		#plot T:
		x=[]
		y=[]
		
		for v in orderedT:
			x += [v[0]]
			y += [v[1]]
		
		x += [orderedT[0][0]]
		y += [orderedT[0][1]]
		
		plt.subplot(1,2,2)
		plt.plot(x,y)
		
		#plot orbit in T:
		x = []
		y = []
		
		if two < three:
			for i in range(2):
				x += [twoOrbit[2+i][0]]
				y += [twoOrbit[2+i][1]]
		
		else:
			for i in range(3):
				x += [threeOrbit[3+i][0]]
				y += [threeOrbit[3+i][1]]
			
			x += [threeOrbit[3][0]]
			y += [threeOrbit[3][1]]
		
		plt.plot(x,y)
		plt.title('T with minimal closed polygonal line')
		plt.show()
	
	return min(two,three)

import sys
import mosek

# Since the actual value of Infinity is ignores, we define it solely
# for symbolic purposes:
inf = 0.0

#Example:
#in_c = [1.0, 1.0]
#in_A = [[1.0, 0.0],
#     [0.0, 1.0]]
#in_B = [[-1.0, 1.0]]

#Extract input as needed for mosek from coefficient matrix.
def constraintdata(M):
	
	sub = [[]]
	val = [[]]
	for j in range(len(M[0])):
		newsub = []
		newval = []
		for i in range(len(M)):
			if abs(M[i][j]) > 10**(-9):
				newsub += [i]
				newval += [M[i][j]]
		sub += [newsub]
		val += [newval]
	
	return [sub, val]
				
			

# Define a stream printer to grab output from MOSEK
def streamprinter(text):
    sys.stdout.write(text)
    sys.stdout.flush()


#Solve an SOCP of the following form:
#
#   max <in_c, x>
#       in_A * x >= 0
#       in_B * x = 0
#       ||x|| <= 1
#
def main(in_c,in_A,in_B):
    # Make a MOSEK environment
    with mosek.Env() as env:
        # Attach a printer to the environment
        env.set_Stream(mosek.streamtype.log, streamprinter)

        # Create a task
        with env.Task(0, 0) as task:
            # Attach a printer to the task
            #task.set_Stream(mosek.streamtype.log, streamprinter)
            
            d = len(in_c)
            mA = len(in_A)
            mB = len(in_B)
            
			#right hand side and type of linear constraint (>=, <=, =)
            bkc = [mosek.boundkey.lo] * mA + [mosek.boundkey.fx] * mB
            blc = [0.0] * (mA + mB)
            buc = [inf] * mA + [0.0] * mB
            
            #Objective, linear term
            c = [0.0] + in_c
            
            #Upper/lower bounds on variables
            bkx = [mosek.boundkey.up] + [mosek.boundkey.fr] * d
            blx = [-inf] + [-inf] * d
            bux = [1.0] + [inf] * d

			#Linear Constraints
            [asub, aval] = constraintdata(in_A + in_B)
            #asub = [[],[0,1],[0]]
            #aval = [[],[1.0,1.0],[1.0]]

            numvar = len(bkx)
            numcon = len(bkc)

            # Append 'numcon' empty constraints.
            # The constraints will initially have no bounds.
            task.appendcons(numcon)

            #Append 'numvar' variables.
            # The variables will initially be fixed at zero (x=0).
            task.appendvars(numvar)

            for j in range(numvar):
              # Set the linear term c_j in the objective.
                task.putcj(j, c[j])
              # Set the bounds on variable j
              # blx[j] <= x_j <= bux[j]
                task.putvarbound(j, bkx[j], blx[j], bux[j])

            for j in range(len(aval)):
              # Input column j of A
                task.putacol(j,                  # Variable (column) index.
                             # Row index of non-zeros in column j.
                             asub[j],
                             aval[j])            # Non-zero Values of column j.


            for i in range(numcon):
                task.putconbound(i, bkc[i], blc[i], buc[i])

                # Input the cones
            task.appendcone(mosek.conetype.quad,
                            0.0,
                            [0, 1, 2])

            # Input the objective sense (minimize/maximize)
            task.putobjsense(mosek.objsense.maximize)

            # Optimize the task
            task.optimize()
            # Print a summary containing information
            # about the solution for debugging purposes
            #task.solutionsummary(mosek.streamtype.msg)
            prosta = task.getprosta(mosek.soltype.itr)
            solsta = task.getsolsta(mosek.soltype.itr)

            # Output a solution
            xx = [0.] * numvar
            task.getxx(mosek.soltype.itr,
                       xx)
            primalobj = task.getprimalobj(mosek.soltype.itr)

            if solsta == mosek.solsta.optimal:
                return [1,primalobj,xx[1:]]
            elif solsta == mosek.solsta.dual_infeas_cer:
                #print("Primal or dual infeasibility.\n")
                return [2,0,[]]
            elif solsta == mosek.solsta.prim_infeas_cer:
                #print("Primal or dual infeasibility.\n")
                return [3,0,[]]
            elif mosek.solsta.unknown:
                #print("Unknown solution status")
                return [4,0,[]]
            else:
                #print("Other solution status")
                return [5,0,[]]

# call the main function
# try:
    # main([1.0, 1.0],[[1.0, 0.0],[0.0, 1.0]],[[-1.0, 1.0]])
# except mosek.MosekException as e:
    # print("ERROR: %s" % str(e.errno))
    # print("\t%s" % e.msg)
    # sys.exit(1)
# except:
    # import traceback
    # traceback.print_exc()
    # sys.exit(1)
 
# c = [3.6955181299615107, -2.0]
# A = [[-0.0, -2.0], [1.8477590649807552, -0.7653668648311384], [1.8477590649807558, 0.7653668648311384]]
# B = [[-1.0000000002185538, -1.0000000000000004], [-1.0000000000000004, -0.9999999997814459]]
 
# print main(c,A,B)

import sys
import mosek

# Since the value of infinity is ignored, we define it solely
# for symbolic purposes
inf = 0.0

# Define a stream printer to grab output from MOSEK
def streamprinter(text):
    sys.stdout.write(text)
    sys.stdout.flush()


#Extract input as needed for mosek from coefficient matrix.
def constraintdata(M):
	
	sub = []
	val = []
	for j in range(len(M[0])):
		newsub = []
		newval = []
		for i in range(len(M)):
			if abs(M[i][j]) > 10**(-9):
				newsub += [i]
				newval += [M[i][j]]
		sub += [newsub]
		val += [newval]
	
	return [sub, val]

#Solve a linear program of the following form:
#
#   max <c,x>
#       A_eq x = b_eq
#       A_up x <= b_up
#       x_1, x_2 >= 0 
#
def main(c, A_eq, b_eq, A_up, b_up):
    # Make mosek environment
    with mosek.Env() as env:
        # Create a task object
        with env.Task(0, 0) as task:
            # Attach a log stream printer to the task
            #task.set_Stream(mosek.streamtype.log, streamprinter)
            
            d = len(c)
            mA = len(A_eq)
            mB = len(A_up)

            # Bound keys for constraints
            bkc = [mosek.boundkey.fx] * mA + [mosek.boundkey.up] * mB

            # Bound values for constraints
            blc = b_eq + [-inf] * mB
            buc = b_eq + b_up

            # Bound keys for variables
            bkx = [mosek.boundkey.lo, mosek.boundkey.lo] + [mosek.boundkey.fr] * (d-2)

            # Bound values for variables
            blx = [0.0, 0.0] + [-inf] * (d-2)
            bux = [+inf] * d

            # Objective coefficients
            # Given by c

            # Below is the sparse representation of the A
            # matrix stored by column.
            [asub, aval] = constraintdata(A_eq + A_up)

            numvar = len(bkx)
            numcon = len(bkc)

            # Append 'numcon' empty constraints.
            # The constraints will initially have no bounds.
            task.appendcons(numcon)

            # Append 'numvar' variables.
            # The variables will initially be fixed at zero (x=0).
            task.appendvars(numvar)

            for j in range(numvar):
                # Set the linear term c_j in the objective.
                task.putcj(j, c[j])

                # Set the bounds on variable j
                # blx[j] <= x_j <= bux[j]
                task.putvarbound(j, bkx[j], blx[j], bux[j])

                # Input column j of A
                task.putacol(j,                  # Variable (column) index.
                             asub[j],            # Row index of non-zeros in column j.
                             aval[j])            # Non-zero Values of column j.

            # Set the bounds on constraints.
             # blc[i] <= constraint_i <= buc[i]
            for i in range(numcon):
                task.putconbound(i, bkc[i], blc[i], buc[i])

            # Input the objective sense (minimize/maximize)
            task.putobjsense(mosek.objsense.maximize)

            # Solve the problem
            task.optimize()
            # Print a summary containing information
            # about the solution for debugging purposes
            #task.solutionsummary(mosek.streamtype.msg)

            # Get status information about the solution
            solsta = task.getsolsta(mosek.soltype.bas)

            if (solsta == mosek.solsta.optimal):
				#print("Optimal solution: ")
                xx = [0.] * numvar
                task.getxx(mosek.soltype.bas, # Request the basic solution.
                           xx)
                primalobj = task.getprimalobj(mosek.soltype.bas)              
                return [1,primalobj,xx]
            elif (solsta == mosek.solsta.dual_infeas_cer or
                  solsta == mosek.solsta.prim_infeas_cer):
                #print("Primal or dual infeasibility certificate found.\n")
                return [2,0,[]]
            elif solsta == mosek.solsta.unknown:
                #print("Unknown solution status")
                return [3,0,[]]
            else:
                #print("Other solution status")
                return [4,0,[]]

# call the main function
# try:
    # main()
# except mosek.Error as e:
    # print("ERROR: %s" % str(e.errno))
    # if e.msg is not None:
        # print("\t%s" % e.msg)
        # sys.exit(1)
# except:
    # import traceback
    # traceback.print_exc()
    # sys.exit(1)


#Example:
# c = [1.0,1.0,0.0]
# A_eq = [[1.0,0.0,0.0],
        # [0.0,1.0,1.0]]
# A_up = [[0.0, 1.0, 0.0]]
# b_up = [5.0]   
# b_eq =[3.0,2.0]
# print main(c,A_eq,b_eq,A_up,b_up)

import random_poly_nDim as rp
import Billiard_Polytope as billiard
import random
import numpy as np

#######################################################################
############################# INPUT ###################################
#######################################################################

seed = round(random.random(),10)
dim = 2
samplesize = 10
lenrange = [1,3]

K = rp.main(seed, dim, samplesize, lenrange)

#######################################################################
#######################################################################


billiard.main(K)

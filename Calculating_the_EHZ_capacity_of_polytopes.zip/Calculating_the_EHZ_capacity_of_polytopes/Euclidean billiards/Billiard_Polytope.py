import numpy as np
import multiprocessing as mp
from scipy import special
import ownSOCP as socp
import ownLP as lp
import time
import scipy.special
import matplotlib.pyplot as plt


permid = []
subset = []
ordset = []
success = True


#Given an index set (i.e. a set consisting of n distinct numbers from range(n))
#find its successor. These sets are ordered as follows:
#(0,1,...,k-2,k-1), (0,1,...,k-2,k), ..., (0,1,...,k-2,n-1), (0,1,...,k-3,k-1,k), ..., (n-k,...,n-1)
#Return value is True iff there is a successor. The predecessor is overwritten
def nextkSubset(subset, k, n):
	copy = subset[:]
	i = k-1
	while True:
		if i == k-1 and subset[i] == n-1:
			i -= 1
		elif i < k-1 and subset[i] == subset[i+1]-1:
			i -= 1
		else:
			j = i
			break
	if i < 0:
		return [copy,False]
		
	copy[j] += 1
	for r in range(j+1,k):
		copy[r] = copy[r-1] + 1
		
	return [copy,True]


# HOW TO USE nextkSubset:
#
# x = [range(3),True]
# while x[1]:
#	print x[0]
#	x = nextkSubset(x[0],3,5)


#Returns the k-th canonic unit vector in R^n.
def dirac(n, k):
	e = np.zeros(n)
	e[k] = 1
	return e


#Given a list of lists (collection) a list of numbers (subset), check
#whether subset is contained in any list in collection
def subsetIn(collection,subset):
	for l in collection:
		if set(subset).issubset(set(l)):
			return True
	return False


#Get all facets of a polytope T. Need to store normals and heights.
def getnormals(T):
	[vnum,d] = np.shape(T)
	maxf = int(special.binom(vnum,d))
	normals = np.zeros((maxf,d))
	heights = np.zeros(maxf)
	setdata = [range(d),True]
	fnum = 0  #number of found facets. fnum <= special.binom(n,d)
	taboo = []
	while setdata[1]:
		subset = setdata[0]
		#Skip an iteration if subset leads to a facet which has already been found
		if subsetIn(taboo,subset):
			setdata = nextkSubset(subset,d,vnum)
			continue
		
		#Choose reference point.
		w = T[subset[0]]
		
		#Define system of equations such that the solution is a normal vector of the facet
		V = np.zeros((d,d))
		b = np.zeros(d)
		
		count = 0
		for j in range(1,d):
			V[count] = T[subset[j]] - T[subset[0]]
			count += 1
		
		#The last row ensures that the solution is nonzero
		V[d-1] = dirac(d,0)
		r = 0
		while np.linalg.matrix_rank(V,10**(-9)) < d:
			r += 1
			V[d-1] = dirac(d,r)
		
		b[d-1] = 1
		
		#Solve system
		n = np.linalg.solve(V,b)
		
		#Check whether we found a facet. We don't need to check the indices in subset.
		h = n.dot(T[subset[0]])
		checkNum = 0
		failed = False
		newtaboo = subset[:]
		
		for l in [index for index in range(vnum) if index not in subset]:
			temp = n.dot(T[l])
			if temp < h - 10**(-9):
				if checkNum == 0:
					checkNum = 1
				elif checkNum == -1:
					#No facet
					failed = True
					setdata = nextkSubset(subset,d,vnum)
					break
			
			elif temp > h + 10**(-9):
				if checkNum == 0:
					checkNum = -1
				elif checkNum == 1:
					#No facet
					failed = True
					setdata = nextkSubset(subset,d,vnum)
					break
			
			else:
				newtaboo += [l]
		
		if not failed:
			#Facet found. Normalize n and change the sign if necessary (by multiplication with checkNum). 
			#Note that cheCkNum is 1 or -1 if T is full-dimensional
			n = np.transpose(checkNum * n / np.linalg.norm(n))
			normals[fnum] = n
			heights[fnum] = n.dot(w)
			fnum += 1
			if len(newtaboo) > d:
				taboo += [newtaboo]
			
		setdata = nextkSubset(subset,d,vnum)
			
	return [normals[0:fnum], heights[0:fnum],fnum]


#get next permutation encoded by indexset permid
def nextpermid(permid):
	d = len(permid)
	copy = permid[:] #Since permid is accessed by all processes be careful not to change it prematurely
	j = -1
	for i in range(d):
		s = d-i-1
		if copy[s] < i:
			j = s		
			break
	if j == -1:
		return [copy, False]
	copy[j] += 1
	for r in range(j+1,d):
		copy[r] = 0
	return [copy, True]


#decode indexset and give corresponding permutation
def decind(permid):
	d = len(permid)
	viable = range(d)
	ind = []
	for i in range(d):
		ind += [viable.pop(permid[i])]
	return ind


#x=[[0]*d,True]
#while x[1]:
#	print decind(x[0])+[d]
#	x=nextpermid(x[0])


#Feed this the initial Input of nextSubset and nextpermid. This merges
#these two functions.
def nextordksubset(subset,k,n,permid):
	nextset = [0] * k
	[newpi,pisuc] = nextpermid(permid)
	if pisuc:
		perm = decind(newpi) + [k-1]
		for i in range(k):
			nextset[i] = subset[perm[i]]
		
		return [nextset, subset, newpi, True]
	
	else:
		[newsub,subsuc] = nextkSubset(subset,k,n)
		if subsuc:
			return [newsub[:],newsub[:],[0]*(k-1),True]
		
		else:
			return [[0]*k, subset, permid, False]

# #HOW TO USE:
# k = 4
# n = 7
# subset = range(k)
# permid = [0] * (k-1)
# x = [range(k), subset, permid, True]
# while x[3]:
	# print x[0]
	# x = nextordksubset(x[1],k,n,x[2])


#check whether an array consists of nonnegative numbers
def ispos(A,tol):
	for a in A:
		if a < tol:
			return False
	return True
	

#calculate length of a billiard trajectory X
def calclength(X):
	d = len(X)
	buf = 0
	for i in range(d-1):
		buf += np.linalg.norm(X[i] - X[i+1])
	buf += np.linalg.norm(X[d-1] - X[0])
	return buf

#Check whether x is a solution of Ax = b
def issolution(x,A,b):
	if np.linalg.norm(b - A.dot(x)) < 10**(-9):
		return True
	else:
		return False


##########################################################################
### The following methods are used to draw the solution in dimension 2 ###
##########################################################################

def getEdges(vert):
	vertN=vert.shape[0]
	#Anzahl der Kanten wird nach oben abgeschaetzt und spaeter zurecht gesplicet.
	Kanten=np.zeros((int(scipy.special.binom(vertN,2)),2),dtype=int)
	counter=0
	for iv in range(vertN):
		for iw in range(iv+1,vertN):
			v=vert[iv]
			w=vert[iw]
			#Normale und Hoehe der Hyperebene, die durch v,w geht
			normal=np.array([w[1]-v[1],v[0]-w[0]])
			height=normal.dot(v)
			#Check ob Seite vorliegt
			markPos=False
			markNeg=False
			for iz in range(vertN):
				z=vert[iz]
				#An dieser Stelle: Fehlertoleranz
				if not markPos and normal.dot(z)>height+10**(-9):
					markPos=True
				if not markNeg and normal.dot(z)<height-10**(-9):
					markNeg=True
				if markPos and markNeg:
					break
			else:
				#Es liegen keine zwei Ecken auf verschiedenen Seiten der Hyperebene (break wurde nicht getriggert)
				Kanten[counter,:]=[iv,iw]
				counter+=1
	Kanten=Kanten[:counter]
	return Kanten


def neighbors(Kanten,iv):
	count=0
	neigh=np.zeros(2,dtype=int)
	for edge in Kanten:
		if iv in edge:
			#Nachbar gefunden, speichere seinen Index
			if iv==edge[0]:
				neigh_ind=edge[1]
			else:
				neigh_ind=edge[0]
			neigh[count]=neigh_ind
			count+=1
			if count>=2:
				break
	return neigh


def ordering(vert):
	ordered = [vert[0]]
	vertorder = [0]
	last = 0
	Kanten = getEdges(vert)
	for i in range(len(vert)-1):
		neigh = neighbors(Kanten,last)
		if neigh[0] not in vertorder:
			vertorder += [neigh[0]]
			last = neigh[0]
		else:
			vertorder += [neigh[1]]
			last = neigh[1]
		ordered += [vert[last]]
	return ordered


def ball(n):
	V = np.zeros((n,2))
	alpha = 2.0 * np.pi / n
	for i in range(n):
		xval = np.cos(alpha * i)
		yval = np.sin(alpha * i)
		V[i] = [xval,yval]
	return V


##########################################################################

def nextTrajectory(T, d, normals, heights, fnum, loc, trajectory, dualtraj, bestVal, k):
	
	global permid, subset, ordset, success
	
	while True:
		
		loc.acquire()
		mypermid = permid[:]
		mysubset = subset[:]
		myordset = ordset[:]
		mysuccess = success.value
		
		if mysuccess:
			[neword, newsub, newpermid, newsuccess] = nextordksubset(mysubset, k, fnum, mypermid)
			permid[:] = newpermid
			subset[:] = newsub
			ordset[:] = neword
			success.value = newsuccess 
		
		loc.release()
		
		if not mysuccess:
			break
		
		#From here, work with myordset.
		#Check whether the rank of the corresponding normals is k-1			
	
		#Fit polygonal line in unit ball
		u = np.zeros((k,d))
		h = np.zeros(k)
		for i in range(k):
			u[i] = -normals[myordset[i]]
			h[i] = heights[myordset[i]]
		
		#Check whether u_i allow polygonal line:
		if np.linalg.matrix_rank(u,10**(-9)) != k-1:
			continue
		else:
			uscale = np.zeros((d+1,k))
			uscale[:d,:] = np.transpose(u)
			uscale[d,0] = 1
			rightSide = np.zeros(d+1)
			rightSide[d] = 1
			mu = np.linalg.lstsq(uscale,rightSide,rcond = None)[0]
			#Check whether mu_1 = 1 (i.e. mu_1 positive) is possible.
			if not issolution(mu,uscale,rightSide):
				continue
			#Check whether all mu_j are positive.
			elif not ispos(mu,10**(-6)):
				continue
		
		A = np.zeros((k,d))
		B = np.zeros((d,d))
		c = np.zeros(d)
		
		M = np.eye(d)
		for i in range(k):
			summand = -2 * np.matmul(np.transpose(u[i]),M)
			A[i] = np.copy(summand)
			c += summand
			fac = np.eye(d) - 2 * np.outer(u[i],u[i])
			M = np.matmul(M,fac)
		
		B = M - np.eye(d)
		
		x0data = socp.main(c.tolist(),A.tolist(),B.tolist())
		
		#If SOCP is infeasible, there is no trajectory.
		
		if x0data[0] != 1:
			continue
		
		x0 = x0data[2]
		
		#If the solution is 0, then the polygonal line cannot be
		#constructed using only positive multiples of u_i.
		if np.linalg.norm(x0) < 10**(-9):
			continue
			
		#Scale x0
		x0 = x0/np.linalg.norm(x0)
		
		gamma = np.zeros((k,d))
		gamma[0] = x0[:]
		
		stop = False
		for i in range(1,k):
			
			x = gamma[i-1]
			ui = u[i-1]
			step = - 2 * x.dot(ui)
			if step < 10**(-6):
				stop = True
				break
			gamma[i] = x + step * ui
		
		#Fitting polygonal line in unit ball cannot be done with only positive multiples.
		if stop:
			continue
		
		#Construct closed polygonal line to fit into the simplex.
		#First, check whether gamma_1,...,gamma_k lie within a k-1 dim hyperplane
		if np.linalg.matrix_rank(gamma,10**(-6)) != k - 1:
			continue
		
		
		#Now, we have a 1-dimensional kernel and are interestet in a positive member
		#of this kernel. Intersect it with the hyperplane given by [1,0,...,0] * x = 1,
		#by adding a row to gamma. If this matrix has rank k, it can be solved uniquely.
		#Otherwise, there is no solution.
		A2 = np.zeros((d+1,k))
		b2 = np.zeros(d+1)
		
		A2[0:d] = np.transpose(gamma)
		A2[d] = dirac(k,0)
		b2[d] = 1
		
		lamb = np.linalg.lstsq(A2,b2,rcond = None)[0]
		#lamb possibly contains nonpositive components. In this case no billiard trajectory exists
		
		#Check whether lambda_1 = 1 (i.e. lambda_1 positive) is possible.
		if not issolution(lamb,A2,b2):
				continue
		#Check whether all lambda_j are positive.
		elif not ispos(lamb,10**(-6)):
			continue
		
		xi = np.zeros((k,d))
		for i in range(1,k):
			
			xi[i] = xi[i-1] + lamb[i] * gamma[i]
			
		#Find bouncing points in P
		c3 = [1] + [0] * (d+1)
		A3 = np.zeros((k,d+2))
		b3 = np.zeros(k)
		
		#Number of facets:
		f = normals.shape[0]
		A_up = np.zeros((k*(f-1),d+2))
		b_up = np.zeros(k*(f-1))
		counter = 0
		
		for i in range(k):
			#Model: bouncing points lie on correct facets.
			A3[i,1] = -u[i].dot(xi[i])
			A3[i,2:] = -u[i]
			b3[i] = h[i]
			
			#Model: bouncing points are members of the polytope.
			for j in range(f):
				if j == myordset[i]:
					#This constraints is already covert due to A3*x <= b3
					continue
				
				A_up[counter,0] = 1
				A_up[counter,1] = normals[j].dot(xi[i])
				A_up[counter,2:] = normals[j]
				b_up[counter] = heights[j]
				counter += 1
		
		soldata = lp.main(c3,A3.tolist(),b3.tolist(),A_up.tolist(),b_up.tolist())
		
		#Continue with next iteration if there is no solution.
		if soldata[0] != 1:
			continue 
		
		#Continue with next iteration if an inequality constraint yields
		#nonpositive slack. The solution does not encode a REGULAR billiard trajectory.
		if soldata[1] < 10**(-6):
			continue		
		
		sol = soldata[2]
		scalefac = sol[1]
		translation = sol[2:]
		
		bpoints = np.zeros((k,d))
		for i in range(k):
			bpoints[i] = scalefac * xi[i] + translation
		
		leng = calclength(bpoints)
		
		loc.acquire()
		if leng < bestVal.value:
				bestVal.value = leng
				trajectory[:] = bpoints.flatten()
				dualtraj[:] = gamma.flatten()
		loc.release()
		

def printTrajectory(traj, d, k):
	for i in range(k):
		print traj[i*d:(i+1)*d]
		


def main(T, verbose = True):
	global permid, subset, ordset, success
	
	d = np.shape(T)[1]
	[normals, heights, fnum] = getnormals(T)
	
	minAction = np.Inf
	mink = 0
	totaltime = 0.0
	minOrbitTwo = np.zeros((8))
	minDualTwo = np.zeros((8))
	minOrbitThree = np.zeros((12))
	minDualThree = np.zeros((12))
	
	if verbose:
		print '\n----------------------------------------------------------------------'
		print 'Start calculation. T has ' + str(normals.shape[0]) + ' facets.'
	
	for k in range(2,d+2):
		tic = time.time()
		
		permid = mp.Array('i', [0] * (k-1))	
		subset = mp.Array('i', range(k))
		ordset = mp.Array('i', range(k))
		success = mp.Value('i',True)
		
		dualtraj = mp.Array('d', np.zeros(k*d))
		trajectory = mp.Array('d', np.zeros(k*d))
		bestVal = mp.Value('d', np.Inf)
		loc = mp.Lock()
		processes = []
		procnum = 4
		
		for i in range(procnum):
			
			p = mp.Process(target = nextTrajectory, args = (T, d, normals, heights, fnum, loc, trajectory, dualtraj, bestVal, k))
			processes.append(p)
			p.start()
	
		#Wait for all process to terminate.
		for q in processes:
			q.join()
		
		toc = time.time() - tic
		
		if verbose:
			print '----------------------------------------------------------------------\n'
			print 'Shortest trajectory with ' + str(k) + ' bouncing points:\n'
			
		if bestVal.value == np.Inf:
			if verbose:
				print 'No trajectory with ' + str(k) + ' bouncing points has been found.'
		else:
			if verbose:
				printTrajectory(trajectory[:], d, k)
				print '\nIt has length ' + str(bestVal.value)
		
			if minAction > bestVal.value:
				minAction = bestVal.value
				mink = k
				if d == 2 and k == 2:
					minOrbitTwo = trajectory[:]
					minDualTwo = dualtraj[:]
				elif d == 2 and k == 3:
					minOrbitThree = trajectory[:]
					minDualThree = dualtraj[:]
		
		if verbose:
			print '\nThis computation took ' + str(int(toc/60)) + ' minutes and ' + str(round(toc%60,3)) + ' seconds.\n'
			
		totaltime += toc
	
	if verbose:
		print '\n----------------------------------------------------------------------'
		print '----------------------------------------------------------------------\n'
		print '\nResult:\n'
	
	if verbose:
		if minAction == np.Inf:
			print 'No trajectory has been found.'
		else:
			print 'There is a shortest classical billiard trajectory with ' + str(mink) + ' bouncing points and length:'
			print minAction 
		print '\nIn total, the computation took ' + str(int(totaltime/60)) + ' minutes and ' + str(round(totaltime%60,3)) + ' seconds.'
		
		#print solution in dimension 2:
		
		if d == 2 and minAction != np.Inf:
			#ordering vertices for plot:
			orderedK = ordering(T)
			orderedT = ball(500)
			
			plt.close()
			
			#plot K:
			x = []
			y = []
			
			for v in orderedK:
				x += [v[0]]
				y += [v[1]]
			
			x += [orderedK[0][0]]
			y += [orderedK[0][1]]
			
			plt.subplot(1,2,1)
			plt.plot(x,y)
			
			#plot orbit in K:
			x = []
			y = []
			
			if mink == 2:
				for i in range(2):
					x += [minOrbitTwo[2*i]]
					y += [minOrbitTwo[2*i + 1]]
			
			else:
				for i in range(3):
					x += [minOrbitThree[2*i]]
					y += [minOrbitThree[2*i + 1]]
				
				x += [minOrbitThree[0]]
				y += [minOrbitThree[1]]
			
			plt.plot(x,y)
			plt.title('K with minimal closed polygonal line')
			
			#plot T:
			x=[]
			y=[]
			
			for v in orderedT:
				x += [v[0]]
				y += [v[1]]
			
			x += [orderedT[0][0]]
			y += [orderedT[0][1]]
			
			plt.subplot(1,2,2)
			plt.plot(x,y)
			
			#plot orbit in T:
			x = []
			y = []
			
			if mink == 2:
				for i in range(2):
					x += [minDualTwo[2*i]]
					y += [minDualTwo[2*i + 1]]
			
			else:
				for i in range(3):
					x += [minDualThree[2*i]]
					y += [minDualThree[2*i + 1]]
				
				x += [minDualThree[0]]
				y += [minDualThree[1]]
			
			plt.plot(x,y)
			plt.title('T with minimal closed polygonal line')
			plt.show()
	
	return minAction
	

#----------------------------------------------------------------------------------------------------------------------------------------------

#Example for usage:

#T= np.array([[1,1,1],[-1,1,1],[1,-1,1],[1,1,-1],[-1,-1,1],[-1,1,-1],[1,-1,-1],[-1,-1,-1]])
#main(T)

